package com.wordloop.app.domain.usecase

import com.wordloop.app.domain.model.Word
import com.wordloop.app.domain.repository.ReviewRepository
import com.wordloop.app.domain.repository.WordRepository
import java.time.Instant
import java.time.temporal.ChronoUnit
import javax.inject.Inject

class AddWordUseCase @Inject constructor(private val repository: WordRepository, private val reviewRepository: ReviewRepository) {
    suspend operator fun invoke(word: String, meaning: String, example: String?, audioPath: String?, audioPaths: List<String> = emptyList(), folderIds: List<Long> = emptyList()): Long {
        require(word.isNotBlank() && meaning.isNotBlank())
        val minutes = reviewRepository.getDefaultReviewAfterMinutes().coerceAtLeast(1)
        val now = Instant.now()
        return repository.addWord(Word(word=word.trim(), meaning=meaning.trim(), example=example?.trim()?.takeIf { it.isNotEmpty() }, audioPath=audioPaths.firstOrNull() ?: audioPath, audioPaths=if(audioPaths.isNotEmpty()) audioPaths else listOfNotNull(audioPath), folderIds=folderIds, createdAt=now, lastReviewedAt=null, nextReviewAt=now.plus(minutes, ChronoUnit.MINUTES), reviewCount=0, currentIntervalHours=(minutes+59)/60, currentIntervalMinutes=minutes))
    }
}
