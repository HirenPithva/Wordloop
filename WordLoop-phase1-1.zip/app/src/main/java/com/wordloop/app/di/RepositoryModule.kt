package com.wordloop.app.di

import com.wordloop.app.data.repository.FolderRepositoryImpl
import com.wordloop.app.data.repository.ReviewRepositoryImpl
import com.wordloop.app.data.repository.WordRepositoryImpl
import com.wordloop.app.domain.repository.FolderRepository
import com.wordloop.app.domain.repository.ReviewRepository
import com.wordloop.app.domain.repository.WordRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {
    @Binds @Singleton abstract fun bindWordRepository(impl: WordRepositoryImpl): WordRepository
    @Binds @Singleton abstract fun bindReviewRepository(impl: ReviewRepositoryImpl): ReviewRepository
    @Binds @Singleton abstract fun bindFolderRepository(impl: FolderRepositoryImpl): FolderRepository
}
