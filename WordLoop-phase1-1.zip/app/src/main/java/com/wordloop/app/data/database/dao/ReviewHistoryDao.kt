package com.wordloop.app.data.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.wordloop.app.data.database.entities.ReviewHistoryEntity

@Dao
interface ReviewHistoryDao {
    @Insert suspend fun insert(item: ReviewHistoryEntity): Long

    @Query("SELECT * FROM review_history ORDER BY id ASC")
    suspend fun getAll(): List<ReviewHistoryEntity>
    @Query("SELECT * FROM review_history WHERE wordId = :wordId ORDER BY reviewedAt DESC")
    suspend fun forWord(wordId: Long): List<ReviewHistoryEntity>
}
