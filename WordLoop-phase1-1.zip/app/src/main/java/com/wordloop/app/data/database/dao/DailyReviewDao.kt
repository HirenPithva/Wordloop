package com.wordloop.app.data.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.wordloop.app.data.database.entities.DailyReviewEntity

@Dao
interface DailyReviewDao {
    @Query("SELECT reviewCount FROM daily_review WHERE date = :date") suspend fun count(date: String): Int?
    @Query("SELECT * FROM daily_review ORDER BY date ASC") suspend fun getAll(): List<DailyReviewEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun save(item: DailyReviewEntity)
}
