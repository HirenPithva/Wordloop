package com.wordloop.app.ui.folders

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wordloop.app.data.database.entities.FolderEntity
import com.wordloop.app.domain.repository.FolderRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel class AddFolderViewModel @Inject constructor(private val repo:FolderRepository):ViewModel(){val folders=repo.observeFolders().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList());private val _parent=MutableStateFlow<Long?>(null);val parent=_parent.asStateFlow();fun select(id:Long?){_parent.value=id};fun save(name:String,done:()->Unit){if(name.isBlank()||name.equals("All",true))return;viewModelScope.launch{repo.addFolder(name.trim(),_parent.value);done()}}}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun AddFolderScreen(onSaved:()->Unit,onBack:()->Unit,vm:AddFolderViewModel=hiltViewModel()){
 val folders by vm.folders.collectAsState();val parent by vm.parent.collectAsState();var name by remember{mutableStateOf("")}
 Scaffold(topBar={TopAppBar(title={Text("Add Folder")},navigationIcon={TextButton(onClick=onBack){Text("Back")}})}){p->Column(Modifier.padding(p).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  OutlinedTextField(name,{name=it},label={Text("Folder name")},singleLine=true,modifier=Modifier.fillMaxWidth());Text("Choose parent folder (optional)",style=MaterialTheme.typography.titleMedium)
  LazyColumn(verticalArrangement=Arrangement.spacedBy(2.dp)){items(folders.size){i->val f=folders[i];Row(Modifier.fillMaxWidth(),verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){Checkbox(checked=parent==f.id,onCheckedChange={checked->if(checked)vm.select(f.id) else vm.select(null)});Text(folderPath(f,folders))}}}
  Text("The folder will be created under the selected parent. 'All' is reserved and cannot be created.",style=MaterialTheme.typography.bodySmall)
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick=onBack){Text("Cancel")};Button(onClick={vm.save(name,onSaved)}){Text("Save")}}
 }}
}

private fun folderPath(folder:FolderEntity,all:List<FolderEntity>):String{val names=mutableListOf<String>();var cur:FolderEntity?=folder;while(cur!=null){names.add(cur.name);cur=cur.parentId?.let{id->all.firstOrNull{it.id==id}}};return names.asReversed().joinToString(" / ")}
