package com.wordloop.app.data.repository

import com.wordloop.app.data.database.dao.FolderDao
import com.wordloop.app.data.database.entities.FolderEntity
import com.wordloop.app.domain.repository.FolderRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class FolderRepositoryImpl @Inject constructor(private val dao: FolderDao): FolderRepository {
    override fun observeFolders(): Flow<List<FolderEntity>> = dao.observeAll()
    override suspend fun addFolder(name: String, parentId: Long?): Long = dao.insert(FolderEntity(name=name.trim(), parentId=parentId))
    override suspend fun deleteFolder(folder: FolderEntity) = dao.delete(folder)
    override suspend fun children(parentId: Long?): List<FolderEntity> = dao.children(parentId)
}
