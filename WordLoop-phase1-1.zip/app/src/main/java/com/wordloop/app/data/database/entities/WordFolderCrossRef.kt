package com.wordloop.app.data.database.entities

import androidx.room.Entity

@Entity(tableName = "word_folder_cross_ref", primaryKeys = ["wordId", "folderId"])
data class WordFolderCrossRef(val wordId: Long, val folderId: Long)
