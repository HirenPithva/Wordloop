package com.wordloop.app.ui.folders

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wordloop.app.domain.repository.FolderRepository
import com.wordloop.app.domain.repository.WordRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import javax.inject.Inject

@HiltViewModel
class FoldersViewModel @Inject constructor(folderRepo: FolderRepository, wordRepo: WordRepository) : ViewModel() {
    val folders = folderRepo.observeFolders().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val words = wordRepo.observeAllWords().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    private val _selected = MutableStateFlow<Long?>(null)
    val selected = _selected.asStateFlow()
    fun select(id: Long?) { _selected.value = id }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FoldersScreen(onAddFolder: () -> Unit, vm: FoldersViewModel = hiltViewModel()) {
    val folders by vm.folders.collectAsState()
    val words by vm.words.collectAsState()
    val selected by vm.selected.collectAsState()
    val selectedFolder = folders.firstOrNull { it.id == selected }
    val visibleWords = if (selected == null) words else words.filter { selected in it.folderIds }

    val rootFolders = folders.filter { it.parentId == null }
    val chain = remember(folders, selected) {
        buildList {
            var id = selected
            while (id != null) {
                add(id)
                id = folders.firstOrNull { it.id == id }?.parentId
            }
            reverse()
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Folders") }) },
        floatingActionButton = { FloatingActionButton(onClick = onAddFolder) { Text("+") } }
    ) { p ->
        Column(Modifier.padding(p).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            // All is deliberately outside the horizontal scroller so it remains fixed.
            Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                FilterChip(selected = selected == null, onClick = { vm.select(null) }, label = { Text("All") })
                Row(
                    Modifier.weight(1f).horizontalScroll(rememberScrollState()).padding(start = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val rootVisible = if (selected == null) rootFolders else rootFolders.filter { it.id == chain.firstOrNull() }
                    rootVisible.forEach { folder ->
                        FilterChip(selected = selected == folder.id, onClick = { vm.select(folder.id) }, label = { Text(folder.name) })
                    }
                }
            }

            // Each selected folder exposes only its direct children. There is no
            // repeated All chip at nested levels.
            chain.forEach { parentId ->
                val children = folders.filter { it.parentId == parentId }
                if (children.isNotEmpty()) {
                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        children.forEach { child ->
                            FilterChip(selected = selected == child.id, onClick = { vm.select(child.id) }, label = { Text(child.name) })
                        }
                    }
                }
            }

            Text(
                if (selected == null) "All words" else "Words in ${selectedFolder?.name.orEmpty()}",
                style = MaterialTheme.typography.titleMedium
            )
            LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                items(visibleWords.size) { i ->
                    val w = visibleWords[i]
                    ListItem(
                        headlineContent = { Text(w.word) },
                        supportingContent = { Text(w.meaning) },
                        trailingContent = { Text(nextText(w.nextReviewAt)) }
                    )
                }
            }
        }
    }
}

private fun nextText(i: java.time.Instant): String {
    val m = java.time.Duration.between(java.time.Instant.now(), i).toMinutes()
    if (m <= 0) return "Due"
    val d = m / 1440
    val h = (m % 1440) / 60
    val min = m % 60
    return if (d > 0) "Next in $d day${if (d == 1L) "" else "s"}"
    else if (h > 0) "Next in $h hour${if (h == 1L) "" else "s"}"
    else "Next in $min min"
}
