package com.wordloop.app.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.wordloop.app.data.database.WordLoopDatabase
import com.wordloop.app.data.database.entities.WordEntity
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import java.time.*
import javax.inject.Inject

class ReminderScheduler @Inject constructor(@ApplicationContext private val context:Context) {
 companion object { private const val BASE=30000; private const val DAYS=14 }
 fun rescheduleUpcoming(){CoroutineScope(SupervisorJob()+Dispatchers.IO).launch{val db=WordLoopDatabase.open(context);try{val goal=db.appSettingsDao().get()?.dailyGoal?.coerceAtLeast(1)?:10;schedule(goal,db.wordDao().getAllWordsOnce())}finally{db.close()}}}
 private fun schedule(goal:Int,words:List<WordEntity>){
  val alarm=context.getSystemService(AlarmManager::class.java)
  for(i in BASE until BASE+1000){val pi=PendingIntent.getBroadcast(context,i,Intent(context,ReminderReceiver::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);alarm.cancel(pi)}
  val zone=ZoneId.systemDefault();val today=LocalDate.now(zone);val sent=context.getSharedPreferences("review_notifications",Context.MODE_PRIVATE);var request=BASE
  for(offset in 0 until DAYS){val day=today.plusDays(offset.toLong());val selected=words.filter{val dueDate=it.nextReviewAt.atZone(zone).toLocalDate(); val due=if(day==today) dueDate<=today else dueDate==day; val key="sent_${day}_${it.id}"; due && (day!=today || !sent.getBoolean(key,false))}.sortedWith(compareBy<WordEntity>{it.nextReviewAt}.thenBy{it.createdAt}).take(goal)
   for(word in selected){val key="sent_${day}_${word.id}";if(request>=BASE+1000)return;val millis=word.nextReviewAt.toEpochMilli().coerceAtLeast(System.currentTimeMillis()+1000);val intent=Intent(context,ReminderReceiver::class.java).apply{putExtra(ReminderReceiver.EXTRA_WORD_ID,word.id);putExtra(ReminderReceiver.EXTRA_NOTIFICATION_ID,request)};val pi=PendingIntent.getBroadcast(context,request,intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    if(Build.VERSION.SDK_INT>=31 && alarm.canScheduleExactAlarms()) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,millis,pi) else alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,millis,pi);request++
   }
  }
 }
}
