package com.wordloop.app.data.repository

import com.wordloop.app.data.database.dao.FolderDao
import com.wordloop.app.data.database.dao.WordDao
import com.wordloop.app.data.database.entities.WordEntity
import com.wordloop.app.data.database.entities.WordFolderCrossRef
import com.wordloop.app.domain.model.Word
import com.wordloop.app.domain.repository.WordRepository
import com.wordloop.app.notifications.ReminderScheduler
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.combine
import java.time.Instant
import javax.inject.Inject

class WordRepositoryImpl @Inject constructor(private val wordDao: WordDao, private val folderDao: FolderDao, private val reminderScheduler: ReminderScheduler) : WordRepository {
    override fun observeAllWords(): Flow<List<Word>> = combine(wordDao.observeAllWords(), folderDao.observeAllRefs()) { entities, refs -> val grouped=refs.groupBy{it.wordId}.mapValues{it.value.map(WordFolderCrossRef::folderId)}; entities.map{it.toDomain(grouped[it.id].orEmpty())} }
    override fun observeWordCount(): Flow<Int> = wordDao.observeWordCount()
    override suspend fun getWordById(id: Long): Word? = wordDao.getWordById(id)?.let { it.toDomain(folderDao.folderIdsForWord(id)) }
    override suspend fun addWord(word: Word): Long { val id = wordDao.insert(word.toEntity()); setFolders(id, word.folderIds); reminderScheduler.rescheduleUpcoming(); return id }
    override suspend fun updateWord(word: Word) { wordDao.update(word.toEntity()); setFolders(word.id, word.folderIds); reminderScheduler.rescheduleUpcoming() }
    override suspend fun deleteWord(word: Word) { wordDao.delete(word.toEntity()); folderDao.clearWordFolders(word.id); reminderScheduler.rescheduleUpcoming() }
    override suspend fun getDueWords(now: Instant): List<Word> = wordDao.getDueWords(now).map { it.toDomain(folderDao.folderIdsForWord(it.id)) }
    override suspend fun setWordFolders(wordId: Long, folderIds: List<Long>) = setFolders(wordId, folderIds)
    override suspend fun getAllFolderRefs(): List<WordFolderCrossRef> = folderDao.getAllRefs()
    private suspend fun setFolders(wordId: Long, ids: List<Long>) { folderDao.clearWordFolders(wordId); ids.distinct().forEach { folderDao.addWordFolder(WordFolderCrossRef(wordId, it)) } }
}

private fun WordEntity.toDomain(folderIds: List<Long>) = Word(id, word, meaning, example, audioPath, if (audioPaths.isNotEmpty()) audioPaths else listOfNotNull(audioPath), folderIds, createdAt, lastReviewedAt, nextReviewAt, reviewCount, currentIntervalHours, currentIntervalMinutes)
private fun Word.toEntity() = WordEntity(id, word, meaning, example, audioPaths.firstOrNull(), audioPaths, createdAt, lastReviewedAt, nextReviewAt, reviewCount, currentIntervalHours, currentIntervalMinutes)
