package com.wordloop.app.ui.configuration
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wordloop.app.data.backup.BackupManager
import com.wordloop.app.data.database.entities.ReviewScheduleEntity
import com.wordloop.app.domain.repository.ReviewRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject
@HiltViewModel class ConfigurationViewModel @Inject constructor(private val repo:ReviewRepository,private val backup:BackupManager):ViewModel(){
 val schedule=repo.observeSchedule().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList());val goal=repo.observeDailyGoal().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),10);val defaultAfter=repo.observeDefaultReviewAfterMinutes().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),1440L)
 fun export(uri:Uri,done:(Boolean,String?)->Unit)=viewModelScope.launch{val r=backup.export(uri);done(r.isSuccess,r.exceptionOrNull()?.message)}
 fun import(uri:Uri,done:(Boolean,String?)->Unit)=viewModelScope.launch{val r=backup.import(uri);done(r.isSuccess,r.exceptionOrNull()?.message)}
 fun save(rows:List<Pair<String,String>>,daily:String,default:String){val parsed=rows.mapNotNull{val a=it.first.toIntOrNull();val m=it.second.toLongOrNull();if(a!=null&&m!=null&&a>0&&m>0)ReviewScheduleEntity(afterReviews=a,remindAfterHours=(m+59)/60,remindAfterMinutes=m)else null};viewModelScope.launch{repo.saveSchedule(parsed);repo.saveDailyGoal(daily.toIntOrNull()?:10);repo.saveDefaultReviewAfterMinutes(default.toLongOrNull()?:1440)}}
}
