package com.wordloop.app.ui.configuration

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

private enum class IntervalUnit(val label: String, val minutes: Long) {
    MINUTES("Minutes", 1), HOURS("Hours", 60), DAYS("Days", 1440)
}

private data class IntervalInput(var value: String, var unit: IntervalUnit) {
    fun toMinutes(): Long? = value.toLongOrNull()?.takeIf { it > 0 }?.times(unit.minutes)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConfigurationScreen(vm: ConfigurationViewModel = hiltViewModel()) {
    val saved by vm.schedule.collectAsState()
    val goal by vm.goal.collectAsState()
    val defaultAfter by vm.defaultAfter.collectAsState()
    var daily by remember(goal) { mutableStateOf(goal.toString()) }
    var defaultInput by remember(defaultAfter) { mutableStateOf(minutesToInput(defaultAfter)) }
    var rows by remember(saved) {
        mutableStateOf(saved.map { minutesToInput(it.remindAfterMinutes) to it.afterReviews }
            .ifEmpty { listOf(IntervalInput("1", IntervalUnit.DAYS) to 1) })
    }
    var message by remember { mutableStateOf<String?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) vm.export(uri) { ok, error -> message = if (ok) "Backup exported successfully." else "Export failed: ${error ?: "unknown error"}" }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.import(uri) { ok, error -> message = if (ok) "Backup imported successfully." else "Import failed: ${error ?: "unknown error"}" }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Configuration") }) }) { p ->
        LazyColumn(Modifier.padding(p).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Text("Default review", style = MaterialTheme.typography.titleLarge)
                Text("New words with 0 completed reviews use this interval before their first review. Default is 24 hours.")
                IntervalEditor("Default Review After", defaultInput) { defaultInput = it }
            }
            item {
                Text("Review cycles", style = MaterialTheme.typography.titleLarge)
                Text("Each cycle can use minutes, hours, or days. The highest matching review count determines the next interval.")
            }
            rows.forEachIndexed { i, row ->
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = row.second.toString(),
                            onValueChange = { v -> rows = rows.toMutableList().also { it[i] = row.first to (v.toIntOrNull() ?: row.second) } },
                            label = { Text("After reviews") }, modifier = Modifier.weight(1f)
                        )
                        IntervalEditor("Review after", row.first, modifier = Modifier.weight(2f)) { v ->
                            rows = rows.toMutableList().also { it[i] = v to row.second }
                        }
                        if (rows.size > 1) TextButton(onClick = { rows = rows.filterIndexed { j, _ -> j != i } }) { Text("Remove") }
                    }
                }
            }
            item { OutlinedButton(onClick = { rows = rows + (IntervalInput("1", IntervalUnit.DAYS) to ((rows.maxOfOrNull { it.second } ?: 0) + 1)) }) { Text("Add review cycle") } }
            item {
                Text("Daily review goal", style = MaterialTheme.typography.titleLarge)
                OutlinedTextField(daily, { daily = it }, label = { Text("Words per day") })
                Text("This controls which due words receive review notifications first. It is not a hard limit on reviewing.", style = MaterialTheme.typography.bodySmall)
            }
            item {
                Button(onClick = {
                    vm.save(rows.map { it.second.toString() to (it.first.toMinutes()?.toString() ?: "") }, daily, defaultInput.toMinutes()?.toString() ?: "1440")
                }) { Text("Save") }
            }
            item { Text("Saved cycles", style = MaterialTheme.typography.titleMedium) }
            saved.forEach { item { Text("After ${it.afterReviews} reviews → ${formatMinutes(it.remindAfterMinutes)}") } }
            item {
                HorizontalDivider()
                Text("Backup & restore", style = MaterialTheme.typography.titleLarge)
                Text("Export includes words, review schedules/history, daily review counts, folders, folder relationships, settings, and all available audio files.")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { exportLauncher.launch("WordLoop-backup.wordloop") }) { Text("Export data") }
                    OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }) { Text("Import data") }
                }
                Text("Import adds the exported words and history to the current database. Existing folders with the same name and parent are reused.", style = MaterialTheme.typography.bodySmall)
                message?.let { Text(it, color = if (it.startsWith("Backup")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun IntervalEditor(label: String, input: IntervalInput, modifier: Modifier = Modifier, onChange: (IntervalInput) -> Unit) {
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        OutlinedTextField(input.value, { onChange(input.copy(value = it.filter(Char::isDigit))) }, label = { Text(label) }, modifier = Modifier.weight(1f), singleLine = true)
        var expanded by remember { mutableStateOf(false) }
        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }, modifier = Modifier.weight(1f)) {
            OutlinedTextField(input.unit.label, {}, readOnly = true, label = { Text("Unit") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                IntervalUnit.entries.forEach { unit -> DropdownMenuItem(text = { Text(unit.label) }, onClick = { onChange(input.copy(unit = unit)); expanded = false }) }
            }
        }
    }
}

private fun minutesToInput(minutes: Long): IntervalInput = when {
    minutes > 0 && minutes % 1440L == 0L -> IntervalInput((minutes / 1440L).toString(), IntervalUnit.DAYS)
    minutes > 0 && minutes % 60L == 0L -> IntervalInput((minutes / 60L).toString(), IntervalUnit.HOURS)
    else -> IntervalInput(minutes.coerceAtLeast(1).toString(), IntervalUnit.MINUTES)
}

private fun formatMinutes(minutes: Long) = when {
    minutes % 1440L == 0L -> "${minutes / 1440L} day(s)"
    minutes % 60L == 0L -> "${minutes / 60L} hour(s)"
    else -> "$minutes minutes"
}
