package com.wordloop.app.domain.model

import java.time.Instant

data class Word(
    val id: Long = 0,
    val word: String,
    val meaning: String,
    val example: String?,
    val audioPath: String?,
    val audioPaths: List<String> = emptyList(),
    val folderIds: List<Long> = emptyList(),
    val createdAt: Instant,
    val lastReviewedAt: Instant?,
    val nextReviewAt: Instant,
    val reviewCount: Int,
    val currentIntervalHours: Long,
    val currentIntervalMinutes: Long = currentIntervalHours * 60L
) { fun isDue(now: Instant = Instant.now()) = !nextReviewAt.isAfter(now) }
