package com.wordloop.app.data.backup

import android.content.Context
import android.net.Uri
import androidx.room.withTransaction
import com.wordloop.app.data.database.WordLoopDatabase
import com.wordloop.app.data.database.entities.*
import com.wordloop.app.notifications.ReminderScheduler
import dagger.hilt.android.qualifiers.ApplicationContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.inject.Inject

class BackupManager @Inject constructor(@ApplicationContext private val context:Context){
 companion object{private const val VERSION=2}
 suspend fun export(uri:Uri):Result<Unit> = runCatching{
  val db=WordLoopDatabase.open(context);try{val words=db.wordDao().getAllWordsOnce();val history=db.reviewHistoryDao().getAll();val daily=db.dailyReviewDao().getAll();val schedules=db.reviewScheduleDao().getAll();val settings=db.appSettingsDao().get();val folders=db.folderDao().getAll();val refs=db.folderDao().getAllRefs();context.contentResolver.openOutputStream(uri)?.use{out->ZipOutputStream(out).use{zip->
   val audioEntries=mutableMapOf<String,String>();words.forEach{w->(w.audioPaths.ifEmpty{listOfNotNull(w.audioPath)}).forEachIndexed{idx,path->val f=File(path);if(f.exists()){val entry="audio/${w.id}_${idx}_${f.name}";audioEntries["${w.id}:$idx"]=entry;zip.putNextEntry(ZipEntry(entry));f.inputStream().use{it.copyTo(zip)};zip.closeEntry()}}}
   val root=JSONObject().put("formatVersion",VERSION).put("exportedAt",System.currentTimeMillis())
   root.put("words",JSONArray().also{a->words.forEach{w->a.put(JSONObject().put("id",w.id).put("word",w.word).put("meaning",w.meaning).put("example",w.example).put("createdAt",w.createdAt.toEpochMilli()).put("lastReviewedAt",w.lastReviewedAt?.toEpochMilli()).put("nextReviewAt",w.nextReviewAt.toEpochMilli()).put("reviewCount",w.reviewCount).put("currentIntervalMinutes",w.currentIntervalMinutes).put("currentIntervalHours",w.currentIntervalHours).put("audioFiles",JSONArray().also{aa->(w.audioPaths.ifEmpty{listOfNotNull(w.audioPath)}).indices.forEach{idx->audioEntries["${w.id}:$idx"]?.let(aa::put)}}))}})
   root.put("folders",JSONArray().also{a->folders.forEach{f->a.put(JSONObject().put("id",f.id).put("name",f.name).put("parentId",f.parentId))}})
   root.put("wordFolders",JSONArray().also{a->refs.forEach{r->a.put(JSONObject().put("wordId",r.wordId).put("folderId",r.folderId))}})
   root.put("reviewHistory",JSONArray().also{a->history.forEach{h->a.put(JSONObject().put("id",h.id).put("wordId",h.wordId).put("reviewedAt",h.reviewedAt.toEpochMilli()).put("reviewNumber",h.reviewNumber).put("intervalBeforeReviewHours",h.intervalBeforeReviewHours).put("userMeaningAnswer",h.userMeaningAnswer).put("userSentence",h.userSentence).put("meaningResult",h.meaningResult).put("sentenceResult",h.sentenceResult))}})
   root.put("dailyReview",JSONArray().also{a->daily.forEach{d->a.put(JSONObject().put("date",d.date).put("reviewCount",d.reviewCount))}})
   root.put("reviewSchedule",JSONArray().also{a->schedules.forEach{s->a.put(JSONObject().put("afterReviews",s.afterReviews).put("remindAfterMinutes",s.remindAfterMinutes).put("remindAfterHours",s.remindAfterHours))}})
   settings?.let{s->root.put("appSettings",JSONObject().put("dailyGoal",s.dailyGoal).put("defaultReviewAfterMinutes",s.defaultReviewAfterMinutes).put("defaultReviewAfterHours",s.defaultReviewAfterHours))}
   zip.putNextEntry(ZipEntry("database.json"));zip.write(root.toString().toByteArray());zip.closeEntry()
  }}?:error("Unable to open export destination") }finally{db.close()}
 }
 suspend fun import(uri:Uri):Result<Unit> = runCatching{
  val temp=File(context.cacheDir,"wordloop-import-${System.currentTimeMillis()}").apply{mkdirs()};try{var json:JSONObject?=null;context.contentResolver.openInputStream(uri)?.use{input->ZipInputStream(input).use{zip->while(true){val e=zip.nextEntry?:break;if(e.isDirectory)continue;if(e.name=="database.json")json=JSONObject(zip.readBytes().toString(Charsets.UTF_8))else if(e.name.startsWith("audio/")&&!e.name.contains("..")){File(temp,e.name.removePrefix("audio/").replace('/','_')).outputStream().use{zip.copyTo(it)}};zip.closeEntry()}}}?:error("Unable to open import file");val root=json?:error("database.json missing");require(root.optInt("formatVersion",-1)==VERSION){"Unsupported backup format"};val db=WordLoopDatabase.open(context);try{db.withTransaction{
    val folderMap=mutableMapOf<Long,Long>();val folders=root.optJSONArray("folders")?:JSONArray();var pending=(0 until folders.length()).map{folders.getJSONObject(it)}.toMutableList();while(pending.isNotEmpty()){var progress=false;val iterator=pending.iterator();while(iterator.hasNext()){val it=iterator.next();val parentOld=if(it.isNull("parentId"))null else it.getLong("parentId");if(parentOld==null||folderMap.containsKey(parentOld)){val parentNew=parentOld?.let{folderMap[it]};val existing=db.folderDao().getAll().firstOrNull{f->f.parentId==parentNew&&f.name.equals(it.getString("name"),true)};folderMap[it.getLong("id")]=existing?.id?:db.folderDao().insert(FolderEntity(name=it.getString("name"),parentId=parentNew));iterator.remove();progress=true}};if(!progress)error("Invalid folder hierarchy in backup")}
    val idMap=mutableMapOf<Long,Long>();val words=root.getJSONArray("words");for(i in 0 until words.length()){val w=words.getJSONObject(i);val paths=mutableListOf<String>();val aud=w.optJSONArray("audioFiles")?:JSONArray();for(a in 0 until aud.length()){val src=File(temp,aud.getString(a).removePrefix("audio/").replace('/','_'));if(src.exists()){val target=File(context.filesDir,"word_audio_import_${System.currentTimeMillis()}_${i}_$a.${src.extension.ifBlank{"m4a"}}");src.copyTo(target,true);paths+=target.absolutePath}};val old=w.getLong("id");val minutes=w.optLong("currentIntervalMinutes",w.optLong("currentIntervalHours",24)*60);idMap[old]=db.wordDao().insert(WordEntity(word=w.getString("word"),meaning=w.getString("meaning"),example=if(w.isNull("example"))null else w.getString("example"),audioPath=paths.firstOrNull(),audioPaths=paths,createdAt=java.time.Instant.ofEpochMilli(w.getLong("createdAt")),lastReviewedAt=if(w.isNull("lastReviewedAt"))null else java.time.Instant.ofEpochMilli(w.getLong("lastReviewedAt")),nextReviewAt=java.time.Instant.ofEpochMilli(w.getLong("nextReviewAt")),reviewCount=w.getInt("reviewCount"),currentIntervalHours=(minutes+59)/60,currentIntervalMinutes=minutes))}
    val refs=root.optJSONArray("wordFolders")?:JSONArray();for(i in 0 until refs.length()){val r=refs.getJSONObject(i);val wid=idMap[r.getLong("wordId")]?:continue;val fid=folderMap[r.getLong("folderId")]?:continue;db.folderDao().addWordFolder(WordFolderCrossRef(wid,fid))}
    val history=root.optJSONArray("reviewHistory")?:JSONArray();for(i in 0 until history.length()){val h=history.getJSONObject(i);val wid=idMap[h.getLong("wordId")]?:continue;db.reviewHistoryDao().insert(ReviewHistoryEntity(wordId=wid,reviewedAt=java.time.Instant.ofEpochMilli(h.getLong("reviewedAt")),reviewNumber=h.getInt("reviewNumber"),intervalBeforeReviewHours=h.optLong("intervalBeforeReviewHours",24),userMeaningAnswer=h.optString("userMeaningAnswer",""),userSentence=h.optString("userSentence",""),meaningResult=h.optBoolean("meaningResult",true),sentenceResult=h.optBoolean("sentenceResult",true)))}
    val daily=root.optJSONArray("dailyReview")?:JSONArray();for(i in 0 until daily.length()){val d=daily.getJSONObject(i);db.dailyReviewDao().save(DailyReviewEntity(d.getString("date"),d.getInt("reviewCount")))}
    val schedule=root.optJSONArray("reviewSchedule")?:JSONArray();for(i in 0 until schedule.length()){val q=schedule.getJSONObject(i);val m=q.optLong("remindAfterMinutes",q.optLong("remindAfterHours",24)*60);db.reviewScheduleDao().insert(ReviewScheduleEntity(afterReviews=q.getInt("afterReviews"),remindAfterHours=(m+59)/60,remindAfterMinutes=m))}
    root.optJSONObject("appSettings")?.let{s->db.appSettingsDao().save(AppSettingsEntity(1,s.optInt("dailyGoal",10),s.optLong("defaultReviewAfterHours",24),s.optLong("defaultReviewAfterMinutes",1440)))}
  }}finally{db.close()};ReminderScheduler(context).rescheduleUpcoming()}finally{temp.deleteRecursively()}
 }
}
