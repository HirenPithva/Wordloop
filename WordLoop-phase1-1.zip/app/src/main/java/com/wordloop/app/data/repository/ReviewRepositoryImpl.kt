package com.wordloop.app.data.repository

import com.wordloop.app.data.database.dao.*
import com.wordloop.app.data.database.entities.*
import com.wordloop.app.domain.repository.ReviewRepository
import com.wordloop.app.notifications.ReminderScheduler
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit
import javax.inject.Inject

class ReviewRepositoryImpl @Inject constructor(private val wordDao: WordDao, private val historyDao: ReviewHistoryDao, private val dailyDao: DailyReviewDao, private val scheduleDao: ReviewScheduleDao, private val settingsDao: AppSettingsDao, private val scheduler: ReminderScheduler): ReviewRepository {
    override fun observeSchedule(): Flow<List<ReviewScheduleEntity>> = scheduleDao.observeAll()
    override fun observeDailyGoal(): Flow<Int> = settingsDao.observe().map { it?.dailyGoal ?: 10 }
    override fun observeDefaultReviewAfterMinutes(): Flow<Long> = settingsDao.observe().map { it?.defaultReviewAfterMinutes ?: 1440L }
    override suspend fun getDefaultReviewAfterMinutes(): Long = settingsDao.get()?.defaultReviewAfterMinutes ?: 1440L
    override suspend fun saveSchedule(items: List<ReviewScheduleEntity>) { scheduleDao.deleteAll(); items.sortedBy{it.afterReviews}.forEach { scheduleDao.insert(it.copy(id=0, remindAfterHours=(it.remindAfterMinutes+59)/60)) }; scheduler.rescheduleUpcoming() }
    override suspend fun saveDailyGoal(goal: Int) { val s=settingsDao.get(); settingsDao.save(AppSettingsEntity(1, goal.coerceAtLeast(1), s?.defaultReviewAfterHours ?: 24, s?.defaultReviewAfterMinutes ?: 1440)); scheduler.rescheduleUpcoming() }
    override suspend fun saveDefaultReviewAfterMinutes(minutes: Long) { val s=settingsDao.get(); val m=minutes.coerceAtLeast(1); settingsDao.save(AppSettingsEntity(1,s?.dailyGoal ?: 10,(m+59)/60,m)); scheduler.rescheduleUpcoming() }
    override suspend fun getTodayCount(): Int = dailyDao.count(todayKey()) ?: 0
    override suspend fun completeReview(wordId: Long) {
        val word=wordDao.getWordById(wordId) ?: return; val now=Instant.now(); val count=word.reviewCount+1
        val configured=scheduleDao.findApplicable(count); val minutes=configured?.remindAfterMinutes ?: ReviewIntervalPolicyMinutes.select(count)
        wordDao.update(word.copy(lastReviewedAt=now,nextReviewAt=now.plus(minutes,ChronoUnit.MINUTES),reviewCount=count,currentIntervalHours=(minutes+59)/60,currentIntervalMinutes=minutes))
        historyDao.insert(ReviewHistoryEntity(wordId,now,count,word.currentIntervalHours,"","",true,true))
        val key=todayKey(); dailyDao.save(DailyReviewEntity(key,(dailyDao.count(key)?:0)+1)); scheduler.rescheduleUpcoming()
    }
    private fun todayKey()=LocalDate.now(ZoneId.systemDefault()).toString()
}
private object ReviewIntervalPolicyMinutes { fun select(count:Int)=when { count<=10->1440L; count<=20->4320L; else->12960L } }
