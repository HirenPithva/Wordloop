package com.wordloop.app

import android.app.Application
import com.wordloop.app.notifications.ReminderReceiver
import com.wordloop.app.notifications.ReminderScheduler
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class WordLoopApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        ReminderScheduler(this).rescheduleUpcoming()
        ReminderReceiver.notifyDueGoal(this)
    }
}
