package com.wordloop.app.data.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "review_schedule")
data class ReviewScheduleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val afterReviews: Int,
    val remindAfterHours: Long,
    val remindAfterMinutes: Long = remindAfterHours * 60L
)
