package com.wordloop.app.ui.details

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wordloop.app.domain.audio.AudioPlayer
import com.wordloop.app.domain.model.Word
import com.wordloop.app.domain.repository.WordRepository
import com.wordloop.app.ui.audio.AudioPlayerControl
import com.wordloop.app.ui.audio.AudioPlaybackCoordinator
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import java.time.Duration
import java.time.Instant
import javax.inject.Inject

@HiltViewModel class WordDetailsViewModel @Inject constructor(private val repo:WordRepository):ViewModel(){var word by mutableStateOf<Word?>(null);private set;fun load(id:Long)=viewModelScope.launch{word=repo.getWordById(id)};fun delete(onDone:()->Unit)=viewModelScope.launch{word?.let{repo.deleteWord(it)};onDone()}}
private fun nextReviewText(next:Instant,now:Instant=Instant.now()):String{if(!next.isAfter(now))return "Due now";val m=Duration.between(now,next).toMinutes().coerceAtLeast(1);val d=m/1440;val h=(m%1440)/60;val min=m%60;return buildList{if(d>0)add("$d day${if(d==1L)"" else "s"}");if(h>0)add("$h hour${if(h==1L)"" else "s"}");if(d==0L&&h==0L)add("$min minute${if(min==1L)"" else "s"}")}.joinToString(" ")}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun WordDetailsScreen(id:Long,onEdit:()->Unit,onBack:()->Unit,vm:WordDetailsViewModel=hiltViewModel()){
 LaunchedEffect(id){vm.load(id)};val w=vm.word;val coordinator=remember{AudioPlaybackCoordinator()};var confirm by remember{mutableStateOf(false)}
 Scaffold(topBar={TopAppBar(title={Text("Word Details")},navigationIcon={TextButton(onClick=onBack){Text("Back")}})}){p->Column(Modifier.padding(p).padding(20.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){if(w==null)Text("Word not found")else{Text(w.word,style=MaterialTheme.typography.headlineMedium);Text(w.meaning,style=MaterialTheme.typography.titleLarge);w.example?.let{Text("Example: $it")};Text("Reviews: ${w.reviewCount}");Text("Next review: ${nextReviewText(w.nextReviewAt)}");(w.audioPaths.ifEmpty{listOfNotNull(w.audioPath)}).forEachIndexed{i,path->AudioPlayerControl(path,"Audio ${i+1}",coordinator=coordinator)};Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick=onEdit){Text("Edit")};Button(onClick={confirm=true}){Text("Delete")}}}}}
 if(confirm)AlertDialog(onDismissRequest={confirm=false},title={Text("Delete word?")},text={Text("This permanently deletes the word and its audio.")},confirmButton={TextButton(onClick={vm.delete(onBack);confirm=false}){Text("Delete")}},dismissButton={TextButton(onClick={confirm=false}){Text("Cancel")}})
}
