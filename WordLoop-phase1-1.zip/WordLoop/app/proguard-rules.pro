# Add project specific ProGuard rules here.
# Minification is off for this phase (see buildTypes.release in build.gradle.kts),
# so these rules aren't exercised yet, but are ready for when Phase 6 (Polish)
# turns on code shrinking for release builds.

-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
