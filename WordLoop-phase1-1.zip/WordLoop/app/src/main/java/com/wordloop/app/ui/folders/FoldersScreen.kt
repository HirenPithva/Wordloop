package com.wordloop.app.ui.folders

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wordloop.app.data.database.entities.FolderEntity
import com.wordloop.app.domain.repository.FolderRepository
import com.wordloop.app.domain.repository.WordRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class FoldersViewModel @Inject constructor(private val folderRepo: FolderRepository, wordRepo: WordRepository) : ViewModel() {
    val folders = folderRepo.observeFolders().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val words = wordRepo.observeAllWords().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    private val _selected = MutableStateFlow<Long?>(null)
    val selected = _selected.asStateFlow()
    fun select(id: Long?) { _selected.value = id }
    fun delete(folder: FolderEntity, done: () -> Unit) { viewModelScope.launch { folderRepo.deleteFolderTree(folder); _selected.value = null; done() } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FoldersScreen(onAddFolder: () -> Unit, vm: FoldersViewModel = hiltViewModel()) {
    val folders by vm.folders.collectAsState()
    val words by vm.words.collectAsState()
    val selected by vm.selected.collectAsState()
    var pendingDelete by remember { mutableStateOf<FolderEntity?>(null) }
    val selectedFolder = folders.firstOrNull { it.id == selected }
    val visibleWords = if (selected == null) words else words.filter { selected in it.folderIds }
    val rows = remember(folders) { flattenFolderTree(folders) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Folders") }) },
        floatingActionButton = { FloatingActionButton(onClick = onAddFolder) { Text("+") } }
    ) { padding ->
        Column(Modifier.padding(padding).padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Folder hierarchy", style = MaterialTheme.typography.titleMedium)
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                item {
                    OutlinedButton(onClick = { vm.select(null) }, modifier = Modifier.fillMaxWidth()) { Text(if (selected == null) "✓  All — all words" else "All — all words") }
                }
                items(rows, key = { it.folder.id }) { row ->
                    val folder = row.folder
                    Row(
                        Modifier.fillMaxWidth().padding(start = (row.depth * 28).dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Button(onClick = { vm.select(folder.id) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = if (selected == folder.id) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)) {
                            Text(if (row.depth > 0) "└─ ${folder.name}" else folder.name, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { pendingDelete = folder }) { Text("🗑") }
                    }
                }
            }
            Text(if (selected == null) "All words" else "Words in ${selectedFolder?.name.orEmpty()}", style = MaterialTheme.typography.titleMedium)
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                items(visibleWords, key = { it.id }) { w -> ListItem(headlineContent = { Text(w.word) }, supportingContent = { Text(w.meaning) }, trailingContent = { Text(nextText(w.nextReviewAt)) }) }
            }
        }
    }

    pendingDelete?.let { folder ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Delete ${folder.name}?") },
            text = { Text("This deletes this folder, all child folders, and words assigned to any folder in this subtree. This cannot be undone.") },
            confirmButton = { TextButton(onClick = { pendingDelete = null; vm.delete(folder) {} }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Cancel") } }
        )
    }
}

private fun nextText(i: java.time.Instant): String {
    val m = java.time.Duration.between(java.time.Instant.now(), i).toMinutes()
    if (m <= 0) return "Due"
    val d = m / 1440
    val h = (m % 1440) / 60
    val min = m % 60
    return if (d > 0) "Next in $d day${if (d == 1L) "" else "s"}" else if (h > 0) "Next in $h hour${if (h == 1L) "" else "s"}" else "Next in $min min"
}
