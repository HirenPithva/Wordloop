package com.wordloop.app.data.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "app_settings")
data class AppSettingsEntity(
    @PrimaryKey val id: Int = 1,
    val dailyGoal: Int = 10,
    val defaultReviewAfterMinutes: Long = 1440L
)
