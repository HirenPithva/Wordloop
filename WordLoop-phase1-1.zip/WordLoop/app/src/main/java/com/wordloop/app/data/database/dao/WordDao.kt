package com.wordloop.app.data.database.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.wordloop.app.data.database.entities.WordEntity
import kotlinx.coroutines.flow.Flow
import java.time.Instant

@Dao
interface WordDao {

    @Insert
    suspend fun insert(word: WordEntity): Long

    @Update
    suspend fun update(word: WordEntity)

    @Delete
    suspend fun delete(word: WordEntity)

    @Query("SELECT * FROM words ORDER BY createdAt DESC")
    fun observeAllWords(): Flow<List<WordEntity>>

    @Query("SELECT COUNT(*) FROM words")
    fun observeWordCount(): Flow<Int>

    @Query("SELECT * FROM words WHERE id = :id")
    suspend fun getWordById(id: Long): WordEntity?

    // Ordering matches the queue priority rule (Section 5): oldest due first,
    // ties broken by oldest created. Room applies the registered Instant
    // TypeConverter to the :now bind parameter automatically.
    @Query("SELECT * FROM words WHERE nextReviewAt <= :now ORDER BY nextReviewAt ASC, createdAt ASC")
    suspend fun getDueWords(now: Instant): List<WordEntity>
}
