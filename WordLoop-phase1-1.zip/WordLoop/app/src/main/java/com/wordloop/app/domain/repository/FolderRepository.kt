package com.wordloop.app.domain.repository

import com.wordloop.app.data.database.entities.FolderEntity
import kotlinx.coroutines.flow.Flow

interface FolderRepository {
    fun observeFolders(): Flow<List<FolderEntity>>
    suspend fun addFolder(name: String, parentId: Long?): Long
    suspend fun deleteFolder(folder: FolderEntity)
    suspend fun children(parentId: Long?): List<FolderEntity>
    suspend fun deleteFolderTree(folder: FolderEntity)
}
