package com.wordloop.app.data.repository

import com.wordloop.app.data.database.dao.AppSettingsDao
import com.wordloop.app.data.database.dao.DailyReviewDao
import com.wordloop.app.data.database.dao.ReviewHistoryDao
import com.wordloop.app.data.database.dao.ReviewScheduleDao
import com.wordloop.app.data.database.dao.WordDao
import com.wordloop.app.data.database.entities.AppSettingsEntity
import com.wordloop.app.data.database.entities.DailyReviewEntity
import com.wordloop.app.data.database.entities.ReviewHistoryEntity
import com.wordloop.app.data.database.entities.ReviewScheduleEntity
import com.wordloop.app.data.database.entities.WordEntity
import com.wordloop.app.domain.repository.ReviewRepository
import com.wordloop.app.domain.usecase.ReviewIntervalPolicy
import com.wordloop.app.notifications.ReminderScheduler
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit
import javax.inject.Inject

class ReviewRepositoryImpl @Inject constructor(
    private val wordDao: WordDao,
    private val reviewHistoryDao: ReviewHistoryDao,
    private val dailyReviewDao: DailyReviewDao,
    private val reviewScheduleDao: ReviewScheduleDao,
    private val appSettingsDao: AppSettingsDao,
    private val reminderScheduler: ReminderScheduler
) : ReviewRepository {

    override fun observeSchedule(): Flow<List<ReviewScheduleEntity>> =
        reviewScheduleDao.observeAll()

    override fun observeDailyGoal(): Flow<Int> =
        appSettingsDao.observe().map { it?.dailyGoal ?: 10 }

    override fun observeDefaultReviewAfterMinutes(): Flow<Long> =
        appSettingsDao.observe().map { it?.defaultReviewAfterMinutes ?: 1440L }

    override suspend fun getDefaultReviewAfterMinutes(): Long =
        appSettingsDao.get()?.defaultReviewAfterMinutes ?: 1440L

    override suspend fun saveSchedule(items: List<ReviewScheduleEntity>) {
        reviewScheduleDao.deleteAll()
        items.sortedBy { it.afterReviews }.forEach { item ->
            reviewScheduleDao.insert(item.copy(id = 0))
        }
        reminderScheduler.rescheduleUpcoming()
    }

    override suspend fun saveDailyGoal(goal: Int) {
        val current = appSettingsDao.get()
        appSettingsDao.save(AppSettingsEntity(
            id = 1,
            dailyGoal = goal.coerceAtLeast(1),
            defaultReviewAfterMinutes = current?.defaultReviewAfterMinutes ?: 1440L
        ))
        reminderScheduler.rescheduleUpcoming()
    }

    override suspend fun saveDefaultReviewAfterMinutes(minutes: Long) {
        val current = appSettingsDao.get()
        appSettingsDao.save(AppSettingsEntity(
            id = 1,
            dailyGoal = current?.dailyGoal ?: 10,
            defaultReviewAfterMinutes = minutes.coerceAtLeast(1L)
        ))
        reminderScheduler.rescheduleUpcoming()
    }

    override suspend fun getTodayCount(): Int =
        dailyReviewDao.count(todayKey()) ?: 0

    override suspend fun completeReview(wordId: Long) {
        val word = wordDao.getWordById(wordId) ?: return
        val now = Instant.now()
        val newReviewCount = word.reviewCount + 1
        val configured = reviewScheduleDao.findApplicable(newReviewCount)
        val intervalMinutes = configured?.remindAfterMinutes
            ?: ReviewIntervalPolicy.select(newReviewCount, emptyList())

        val updated = word.copy(
            lastReviewedAt = now,
            nextReviewAt = now.plus(intervalMinutes, ChronoUnit.MINUTES),
            reviewCount = newReviewCount,
            currentIntervalMinutes = intervalMinutes
        )
        wordDao.update(updated)

        reviewHistoryDao.insert(
            ReviewHistoryEntity(
                wordId = wordId,
                reviewedAt = now,
                reviewNumber = newReviewCount,
                intervalBeforeReviewMinutes = word.currentIntervalMinutes,
                userMeaningAnswer = "",
                userSentence = "",
                meaningResult = true,
                sentenceResult = true
            )
        )

        val key = todayKey()
        val current = dailyReviewDao.count(key) ?: 0
        dailyReviewDao.save(DailyReviewEntity(key, current + 1))
        reminderScheduler.rescheduleUpcoming()
    }

    private fun todayKey(): String =
        LocalDate.now(ZoneId.systemDefault()).toString()
}
