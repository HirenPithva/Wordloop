package com.wordloop.app.data.repository

import com.wordloop.app.data.database.dao.FolderDao
import com.wordloop.app.data.database.dao.WordDao
import com.wordloop.app.data.database.entities.FolderEntity
import com.wordloop.app.domain.repository.FolderRepository
import kotlinx.coroutines.flow.Flow
import java.io.File
import javax.inject.Inject

class FolderRepositoryImpl @Inject constructor(
    private val dao: FolderDao,
    private val wordDao: WordDao
): FolderRepository {
    override fun observeFolders(): Flow<List<FolderEntity>> = dao.observeAll()
    override suspend fun addFolder(name: String, parentId: Long?): Long = dao.insert(FolderEntity(name=name.trim(), parentId=parentId))
    override suspend fun deleteFolder(folder: FolderEntity) = dao.delete(folder)
    override suspend fun children(parentId: Long?): List<FolderEntity> = dao.children(parentId)

    override suspend fun deleteFolderTree(folder: FolderEntity) {
        val all = dao.getAll()
        val subtree = mutableListOf<FolderEntity>()
        val pending = ArrayDeque<Long>()
        pending.add(folder.id)
        while (pending.isNotEmpty()) {
            val id = pending.removeFirst()
            val current = all.firstOrNull { it.id == id } ?: continue
            subtree += current
            all.filter { it.parentId == id }.forEach { pending.addLast(it.id) }
        }

        // The requested behavior is destructive: words assigned to the deleted
        // folder tree are deleted as well. WordFolder refs are cleared first.
        val wordIds = subtree.flatMap { dao.wordIdsInFolder(it.id) }.distinct()
        for (wordId in wordIds) {
            val entity = wordDao.getWordById(wordId)
            entity?.audioPaths?.forEach { path -> runCatching { File(path).delete() } }
            entity?.audioPath?.let { path -> runCatching { File(path).delete() } }
            dao.clearWordFolders(wordId)
            wordDao.deleteById(wordId)
        }
        subtree.asReversed().forEach { child ->
            dao.clearFolderRefs(child.id)
            dao.delete(child)
        }
    }
}
