package com.wordloop.app.domain.repository

import com.wordloop.app.data.database.entities.ReviewScheduleEntity
import kotlinx.coroutines.flow.Flow

interface ReviewRepository {
    fun observeSchedule(): Flow<List<ReviewScheduleEntity>>
    fun observeDailyGoal(): Flow<Int>
    suspend fun saveSchedule(items: List<ReviewScheduleEntity>)
    suspend fun saveDailyGoal(goal: Int)
    suspend fun getTodayCount(): Int
    suspend fun completeReview(wordId: Long)
}
