package com.wordloop.app.di

import com.wordloop.app.data.repository.WordRepositoryImpl
import com.wordloop.app.data.repository.ReviewRepositoryImpl
import com.wordloop.app.domain.repository.WordRepository
import com.wordloop.app.domain.repository.ReviewRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    abstract fun bindWordRepository(impl: WordRepositoryImpl): WordRepository

    @Binds
    abstract fun bindReviewRepository(impl: ReviewRepositoryImpl): ReviewRepository
}
