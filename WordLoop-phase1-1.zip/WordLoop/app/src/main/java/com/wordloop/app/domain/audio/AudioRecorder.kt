package com.wordloop.app.domain.audio

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import java.io.File

/**
 * Thin wrapper around MediaRecorder for the Add Word screen's voice note
 * (Section 11). One recorder instance records to one file at a time.
 */
class AudioRecorder(private val context: Context) {

    private var recorder: MediaRecorder? = null
    private var outputPath: String? = null

    /** Starts recording to a new file under the app's private storage, and returns its path. */
    fun startRecording(): String {
        val file = File(context.filesDir, "word_audio_${System.currentTimeMillis()}.m4a")
        outputPath = file.absolutePath

        val newRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(context)
        } else {
            @Suppress("DEPRECATION")
            MediaRecorder()
        }

        newRecorder.apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setOutputFile(outputPath)
            prepare()
            start()
        }
        recorder = newRecorder
        return outputPath!!
    }

    /** Stops the current recording and returns the file path, or null if nothing was recording. */
    fun stopRecording(): String? {
        val path = try {
            recorder?.apply {
                stop()
                release()
            }
            outputPath
        } catch (e: RuntimeException) {
            // stop() can throw if start() never produced any data.
            recorder?.release()
            outputPath?.let { File(it).delete() }
            null
        }
        recorder = null
        return path
    }

    /** Aborts the current recording and deletes the partial file. */
    fun cancelRecording() {
        try {
            recorder?.apply {
                stop()
                release()
            }
        } catch (e: RuntimeException) {
            recorder?.release()
        }
        recorder = null
        outputPath?.let { File(it).delete() }
        outputPath = null
    }
}
