package com.wordloop.app.data.database.entities

/**
 * Tracks how many of the day's 10-review cap have been used (spec Section 13
 * / Section 4). date is the local ISO date ("2026-09-21") so there is
 * exactly one row per day. Not yet read from or written to — arrives with
 * the daily-limit logic in Phase 2.
 */
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "daily_review")
data class DailyReviewEntity(
    @PrimaryKey val date: String,
    val reviewCount: Int
)
