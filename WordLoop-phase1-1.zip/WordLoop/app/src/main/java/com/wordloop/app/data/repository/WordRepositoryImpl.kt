package com.wordloop.app.data.repository

import com.wordloop.app.data.database.dao.WordDao
import com.wordloop.app.data.database.entities.WordEntity
import com.wordloop.app.domain.model.Word
import com.wordloop.app.domain.repository.WordRepository
import com.wordloop.app.notifications.ReminderScheduler
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.Instant
import javax.inject.Inject

class WordRepositoryImpl @Inject constructor(
    private val wordDao: WordDao,
    private val reminderScheduler: ReminderScheduler
) : WordRepository {

    override fun observeAllWords(): Flow<List<Word>> =
        wordDao.observeAllWords().map { entities -> entities.map { it.toDomain() } }

    override fun observeWordCount(): Flow<Int> = wordDao.observeWordCount()

    override suspend fun getWordById(id: Long): Word? =
        wordDao.getWordById(id)?.toDomain()

    override suspend fun addWord(word: Word): Long {
        val id = wordDao.insert(word.toEntity())
        reminderScheduler.rescheduleUpcoming()
        return id
    }

    override suspend fun updateWord(word: Word) {
        wordDao.update(word.toEntity())
        reminderScheduler.rescheduleUpcoming()
    }

    override suspend fun deleteWord(word: Word) {
        wordDao.delete(word.toEntity())
        reminderScheduler.rescheduleUpcoming()
    }

    override suspend fun getDueWords(now: Instant): List<Word> =
        wordDao.getDueWords(now).map { it.toDomain() }
}

private fun WordEntity.toDomain() = Word(
    id = id,
    word = word,
    meaning = meaning,
    example = example,
    audioPath = audioPath,
    audioPaths = if (audioPaths.isNotEmpty()) audioPaths else listOfNotNull(audioPath),
    createdAt = createdAt,
    lastReviewedAt = lastReviewedAt,
    nextReviewAt = nextReviewAt,
    reviewCount = reviewCount,
    currentIntervalMinutes = currentIntervalMinutes
)

private fun Word.toEntity() = WordEntity(
    id = id,
    word = word,
    meaning = meaning,
    example = example,
    audioPath = audioPaths.firstOrNull(),
    audioPaths = audioPaths,
    createdAt = createdAt,
    lastReviewedAt = lastReviewedAt,
    nextReviewAt = nextReviewAt,
    reviewCount = reviewCount,
    currentIntervalMinutes = currentIntervalMinutes
)
