package com.wordloop.app.ui.folders

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wordloop.app.data.database.entities.FolderEntity
import com.wordloop.app.domain.repository.FolderRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AddFolderViewModel @Inject constructor(private val repo: FolderRepository): ViewModel() {
    val folders = repo.observeFolders().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    private val _parent = MutableStateFlow<Long?>(null)
    val parent = _parent.asStateFlow()
    fun select(id: Long?) { _parent.value = if (_parent.value == id) null else id }
    fun save(name: String, done: () -> Unit) {
        if (name.isBlank() || name.trim().equals("All", true)) return
        viewModelScope.launch { repo.addFolder(name.trim(), _parent.value); done() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddFolderScreen(onSaved: () -> Unit, onBack: () -> Unit, vm: AddFolderViewModel = hiltViewModel()) {
    val folders by vm.folders.collectAsState()
    val parent by vm.parent.collectAsState()
    var name by remember { mutableStateOf("") }
    Scaffold(
        topBar = { TopAppBar(title = { Text("Add Folder") }, navigationIcon = { TextButton(onClick = onBack) { Text("Back") } }) }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("Folder name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Text("Choose parent folder", style = MaterialTheme.typography.titleMedium)
            Text("Select one folder to create this folder underneath it. Leave all unchecked for a root folder.", style = MaterialTheme.typography.bodySmall)
            FolderTreeCheckboxes(
                folders = folders,
                selectedIds = parent?.let { setOf(it) } ?: emptySet(),
                onToggle = vm::select,
                modifier = Modifier.weight(1f)
            )
            Button(onClick = { vm.save(name, onSaved) }, modifier = Modifier.fillMaxWidth(), enabled = name.isNotBlank() && !name.trim().equals("All", true)) { Text("Save") }
        }
    }
}
