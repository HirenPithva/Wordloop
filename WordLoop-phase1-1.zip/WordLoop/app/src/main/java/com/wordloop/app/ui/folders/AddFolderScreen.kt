package com.wordloop.app.ui.folders
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.wordloop.app.data.database.entities.FolderEntity
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun AddFolderScreen(onBack:()->Unit,vm:FolderViewModel=hiltViewModel()){
 val folders by vm.folders.collectAsState(); var name by remember{mutableStateOf("")}; var parent by remember{mutableStateOf<Long?>(null)}
 Scaffold(topBar={TopAppBar(title={Text("Add Folder")},navigationIcon={TextButton(onClick=onBack){Text("Back")}})}){p->Column(Modifier.padding(p).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
 OutlinedTextField(name,{name=it},label={Text("Folder name")},singleLine=true,modifier=Modifier.fillMaxWidth());Text("Parent folder (optional)",style=MaterialTheme.typography.titleMedium)
 LazyColumn(Modifier.weight(1f)){items(folders,key={it.id}){f->Row(Modifier.fillMaxWidth().padding(start=(depth(f,folders)*20).dp),horizontalArrangement=Arrangement.SpaceBetween){Text(f.name);Checkbox(parent==f.id,{if(it)parent=f.id else parent=null})}}}
 Text("'All' is reserved and cannot be created.",style=MaterialTheme.typography.bodySmall);Button(enabled=name.isNotBlank()&&!name.equals("All",true),onClick={vm.create(name,parent,onBack)},modifier=Modifier.fillMaxWidth()){Text("Save")}
 }}
}
private fun depth(f:FolderEntity,all:List<FolderEntity>):Int{var d=0;var p=f.parentId;while(p!=null){d++;p=all.firstOrNull{it.id==p}?.parentId};return d}
