package com.wordloop.app.ui.configuration
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wordloop.app.data.database.entities.ReviewScheduleEntity
import com.wordloop.app.domain.repository.ReviewRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject
@HiltViewModel class ConfigurationViewModel @Inject constructor(private val repo: ReviewRepository):ViewModel(){
 val schedule=repo.observeSchedule().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList()); val goal=repo.observeDailyGoal().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),10); val defaultReviewAfterHours=repo.observeDefaultReviewAfterHours().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),24L)
 fun save(items:List<Pair<String,String>>, daily:String, defaultAfter:String){ val parsed=items.mapNotNull{a-> val r=a.first.toIntOrNull(); val h=a.second.toLongOrNull(); if(r!=null&&h!=null&&r>0&&h>0) ReviewScheduleEntity(afterReviews=r,remindAfterHours=h) else null}; viewModelScope.launch{repo.saveSchedule(parsed); repo.saveDailyGoal(daily.toIntOrNull()?.coerceAtLeast(1)?:10); repo.saveDefaultReviewAfterHours(defaultAfter.toLongOrNull()?.coerceAtLeast(1L)?:24L)} }
}
