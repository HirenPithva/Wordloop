package com.wordloop.app.notifications

import android.content.BroadcastReceiver
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import com.wordloop.app.data.database.WordLoopDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

class ReminderReceiver : BroadcastReceiver() {
    companion object {
        const val EXTRA_WORD_ID = "word_id"
        const val EXTRA_NOTIFICATION_ID = "notification_id"
        private const val PREFS = "review_notifications"
        private const val SENT_PREFIX = "sent_"

        fun notifyDueGoal(context: Context) {
            CoroutineScope(Dispatchers.IO).launch {
                val db = WordLoopDatabase.open(context)
                try {
                    val goal = db.appSettingsDao().get()?.dailyGoal?.coerceAtLeast(1) ?: 10
                    val today = LocalDate.now(ZoneId.systemDefault()).toString()
                    val sent = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    val due = db.wordDao().getDueWords(Instant.now()).take(goal)
                    val nm = context.getSystemService(NotificationManager::class.java)
                    val channelId = "review"
                    nm.createNotificationChannel(NotificationChannel(channelId, "Review reminders", NotificationManager.IMPORTANCE_DEFAULT))
                    due.forEachIndexed { index, word ->
                        val key = SENT_PREFIX + today + "_" + word.id
                        if (!sent.getBoolean(key, false)) {
                            val n = Notification.Builder(context, channelId)
                                .setSmallIcon(com.wordloop.app.R.drawable.ic_launcher_foreground)
                                .setContentTitle("WordLoop review")
                                .setContentText("${word.word} is due for review.")
                                .setAutoCancel(true)
                                .build()
                            nm.notify(40000 + index, n)
                            sent.edit().putBoolean(key, true).apply()
                        }
                    }
                } finally { db.close() }
            }
        }
    }

    override fun onReceive(context: Context, intent: Intent?) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = WordLoopDatabase.open(context)
                try {
                    val wordId = intent?.getLongExtra(EXTRA_WORD_ID, -1L) ?: -1L
                    val notificationId = intent?.getIntExtra(EXTRA_NOTIFICATION_ID, 2001) ?: 2001
                    val word = if (wordId > 0) db.wordDao().getWordById(wordId) else null
                    if (word != null && !word.nextReviewAt.isAfter(Instant.now())) {
                        val nm = context.getSystemService(NotificationManager::class.java)
                        val channelId = "review"
                        nm.createNotificationChannel(NotificationChannel(channelId, "Review reminders", NotificationManager.IMPORTANCE_DEFAULT))
                        val n = Notification.Builder(context, channelId)
                            .setSmallIcon(com.wordloop.app.R.drawable.ic_launcher_foreground)
                            .setContentTitle("WordLoop review")
                            .setContentText("${word.word} is due for review.")
                            .setAutoCancel(true)
                            .build()
                        nm.notify(notificationId, n)
                        val today = LocalDate.now(ZoneId.systemDefault()).toString()
                        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(SENT_PREFIX + today + "_" + word.id, true).apply()
                    }
                } finally { db.close() }
                ReminderScheduler(context).rescheduleUpcoming()
            } finally { pending.finish() }
        }
    }
}
