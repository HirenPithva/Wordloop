package com.wordloop.app.notifications
import android.app.*
import android.content.*
import androidx.room.Room
import com.wordloop.app.data.database.WordLoopDatabase
import kotlinx.coroutines.*
import java.time.Instant
class ReminderReceiver:BroadcastReceiver(){
 override fun onReceive(context:Context,intent:Intent?){val pending=goAsync(); CoroutineScope(Dispatchers.IO).launch{try{val db=Room.databaseBuilder(context,WordLoopDatabase::class.java,"wordloop.db").addMigrations(WordLoopDatabase.MIGRATION_1_2,WordLoopDatabase.MIGRATION_2_3).build();val count=db.wordDao().getDueWords(Instant.now()).size;if(count>0){val channel="review";val nm=context.getSystemService(NotificationManager::class.java);nm.createNotificationChannel(NotificationChannel(channel,"Review reminders",NotificationManager.IMPORTANCE_DEFAULT));val n=Notification.Builder(context,channel).setSmallIcon(com.wordloop.app.R.drawable.ic_launcher_foreground).setContentTitle("WordLoop review").setContentText("$count word${if(count==1)" is" else "s are"} due for review.").setAutoCancel(true).build();nm.notify(2001,n)};db.close()}finally{pending.finish()}}}
}
