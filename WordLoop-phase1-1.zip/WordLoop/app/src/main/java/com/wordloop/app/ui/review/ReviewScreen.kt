package com.wordloop.app.ui.review

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun ReviewScreen(onAddWord: () -> Unit, viewModel: ReviewViewModel = hiltViewModel()) {
    val state by viewModel.state.collectAsState(); val word = state.due.getOrNull(state.index)
    Scaffold(topBar={ TopAppBar(title={Text("Review")}) }) { p ->
        Column(Modifier.padding(p).padding(20.dp).fillMaxSize(), verticalArrangement=Arrangement.spacedBy(16.dp)) {
            Text("Today: ${state.completedToday} / ${state.goal} goal", style=MaterialTheme.typography.titleMedium)
            if (word == null) { Text("No words are due right now."); Text("Due words stay due until you review them."); Button(onClick=onAddWord){Text("Add a word")} }
            else {
                Text("Due word ${state.index + 1}", style=MaterialTheme.typography.labelLarge)
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                    Text(word.word, style=MaterialTheme.typography.headlineMedium)
                    if (state.revealed) { Text(word.meaning, style=MaterialTheme.typography.titleLarge); word.example?.let{Text("Example: $it")} }
                }}
                if (!state.revealed) Button(onClick=viewModel::reveal){Text("Show meaning")}
                else Button(onClick={viewModel.complete()}){Text("Complete review")}
                Text("Review count: ${word.reviewCount} • Next interval: ${formatInterval(word.currentIntervalHours)}")
                Text("You can review more than your daily goal. The goal is a recommendation, not a limit.", style=MaterialTheme.typography.bodySmall)
            }
        }
    }
}
private fun formatInterval(h: Long)=when { h%720L==0L -> "${h/720} month(s)"; h%24L==0L -> "${h/24} day(s)"; else -> "${h} hours" }
