package com.wordloop.app.ui.audio

import android.media.MediaPlayer
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.io.File

/** Ensures only one row in a word's audio list can be actively playing. */
class AudioPlaybackCoordinator {
    private var activeStop: (() -> Unit)? = null
    fun activate(stop: () -> Unit) { activeStop?.invoke(); activeStop = stop }
    fun clear(stop: () -> Unit) { if (activeStop === stop) activeStop = null }
}

@Composable
fun AudioPlayerControl(
    path: String,
    label: String,
    onRemove: (() -> Unit)? = null,
    coordinator: AudioPlaybackCoordinator = remember { AudioPlaybackCoordinator() }
) {
    var player by remember(path) { mutableStateOf<MediaPlayer?>(null) }
    var playing by remember(path) { mutableStateOf(false) }
    var position by remember(path) { mutableFloatStateOf(0f) }
    var duration by remember(path) { mutableIntStateOf(0) }
    var error by remember(path) { mutableStateOf(false) }

    fun stopAndRelease() {
        val p = player
        player = null
        playing = false
        position = 0f
        runCatching { p?.stop() }
        runCatching { p?.release() }
    }

    DisposableEffect(path) {
        onDispose {
            stopAndRelease()
        }
    }

    LaunchedEffect(playing) {
        while (playing) {
            val p = player
            if (p == null || !p.isPlaying || duration <= 0) break
            position = p.currentPosition.toFloat() / duration.toFloat()
            delay(100)
        }
    }

    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Button(enabled = File(path).exists(), onClick = {
                try {
                    if (player == null) {
                        player = MediaPlayer().apply {
                            setDataSource(path)
                            setOnCompletionListener { completed ->
                                playing = false
                                position = 0f
                                player = null
                                runCatching { completed.release() }
                            }
                            prepare()
                            duration = this.duration
                        }
                    }
                    val p = player ?: return@Button
                    if (p.isPlaying) {
                        p.pause()
                        playing = false
                    } else {
                        val stop: () -> Unit = {
                            runCatching { p.pause() }
                            playing = false
                        }
                        coordinator.activate(stop)
                        p.start()
                        playing = true
                    }
                } catch (_: Exception) {
                    error = true
                    stopAndRelease()
                }
            }) { Text(if (playing) "Pause" else "Play") }
            Text(if (playing) "Playing" else label, Modifier.weight(1f))
            onRemove?.let { TextButton(onClick = { stopAndRelease(); it() }) { Text("Remove") } }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(enabled = duration > 0, onClick = { player?.let { it.seekTo((it.currentPosition - 10_000).coerceAtLeast(0)) } }) { Text("-10s") }
            OutlinedButton(enabled = duration > 0, onClick = { player?.let { it.seekTo((it.currentPosition + 10_000).coerceAtMost(it.duration)) } }) { Text("+10s") }
        }
        Slider(
            value = position,
            onValueChange = { value -> position = value; player?.let { p -> if (duration > 0) p.seekTo((duration * value).toInt()) } },
            enabled = duration > 0,
            modifier = Modifier.fillMaxWidth()
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime((position * duration).toInt()))
            Text(formatTime(duration))
        }
        if (!File(path).exists()) Text("Audio file is missing.", color = MaterialTheme.colorScheme.error)
        if (error) Text("Unable to play this audio file.", color = MaterialTheme.colorScheme.error)
    }
}

private fun formatTime(ms: Int): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}
