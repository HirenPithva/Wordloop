package com.wordloop.app.notifications
import android.app.*
import android.content.*
import java.util.*
class ReminderScheduler(private val context:Context){
 fun scheduleDaily(){
  val alarm=context.getSystemService(AlarmManager::class.java); val intent=Intent(context,ReminderReceiver::class.java); val pi=PendingIntent.getBroadcast(context,1001,intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE); val c=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,9);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0);if(timeInMillis<=System.currentTimeMillis())add(Calendar.DAY_OF_YEAR,1)}
  alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP,c.timeInMillis,AlarmManager.INTERVAL_DAY,pi)
 }
}
