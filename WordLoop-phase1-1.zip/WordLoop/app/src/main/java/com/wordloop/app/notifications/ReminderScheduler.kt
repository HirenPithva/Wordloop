package com.wordloop.app.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.wordloop.app.data.database.WordLoopDatabase
import com.wordloop.app.data.database.entities.WordEntity
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import java.time.Instant
import javax.inject.Inject

/** Schedules the daily-goal number of earliest due/upcoming words individually. */
class ReminderScheduler @Inject constructor(@ApplicationContext private val context: Context) {
    companion object { private const val REQUEST_BASE = 30000; private const val REQUEST_MAX = 10000; private const val PREFS="review_notifications"; private const val SENT_PREFIX="sent_" }
    fun rescheduleUpcoming() { CoroutineScope(SupervisorJob()+Dispatchers.IO).launch { val db=WordLoopDatabase.open(context); try { val goal=db.appSettingsDao().get()?.dailyGoal?.coerceAtLeast(1)?:10; schedule(goal,db.wordDao().getAllWordsOnce()) } finally { db.close() } } }
    private fun schedule(goal:Int, words:List<WordEntity>) {
        val alarm=context.getSystemService(AlarmManager::class.java)
        for(rc in REQUEST_BASE until REQUEST_BASE+REQUEST_MAX){ val pi=PendingIntent.getBroadcast(context,rc,Intent(context,ReminderReceiver::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE); alarm.cancel(pi) }
        val now=Instant.now(); val zone=java.time.ZoneId.systemDefault(); val today=java.time.LocalDate.now(zone); val sent=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE)
        val grouped=words.groupBy{val d=it.nextReviewAt.atZone(zone).toLocalDate(); if(d.isBefore(today)) today else d}
        var rc=REQUEST_BASE
        grouped.toSortedMap().filterKeys { !it.isAfter(today.plusDays(30)) }.forEach { (date,dayWords) ->
            val sentCount=dayWords.count{sent.getBoolean(SENT_PREFIX+date+"_"+it.id,false)}
            val remaining=(goal-sentCount).coerceAtLeast(0)
            dayWords.filter{!sent.getBoolean(SENT_PREFIX+date+"_"+it.id,false)}
                .sortedWith(compareBy<WordEntity>{it.nextReviewAt}.thenBy{it.createdAt})
                .take(remaining)
                .forEach { word ->
                    if(rc>=REQUEST_BASE+REQUEST_MAX)return@forEach
                    val millis=word.nextReviewAt.toEpochMilli().coerceAtLeast(System.currentTimeMillis()+1000)
                    val intent=Intent(context,ReminderReceiver::class.java).apply{putExtra(ReminderReceiver.EXTRA_WORD_ID,word.id);putExtra(ReminderReceiver.EXTRA_NOTIFICATION_ID,rc)}
                    val pi=PendingIntent.getBroadcast(context,rc,intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                    if(Build.VERSION.SDK_INT>=31 && alarm.canScheduleExactAlarms()) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,millis,pi) else alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,millis,pi)
                    rc++
                }
        }
    }
}
