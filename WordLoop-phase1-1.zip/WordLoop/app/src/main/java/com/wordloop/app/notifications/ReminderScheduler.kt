package com.wordloop.app.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.wordloop.app.data.database.WordLoopDatabase
import com.wordloop.app.data.database.entities.WordEntity
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import java.time.*
import java.time.temporal.ChronoUnit
import javax.inject.Inject

class ReminderScheduler @Inject constructor(@ApplicationContext private val context: Context) {
    companion object { private const val REQUEST_BASE = 30000; private const val MAX = 10000; private const val DAYS = 14L }

    fun rescheduleUpcoming() {
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            val db = WordLoopDatabase.open(context)
            try { schedule(db.appSettingsDao().get()?.dailyGoal?.coerceAtLeast(1) ?: 10, db.wordDao().getAllWordsOnce()) }
            finally { db.close() }
        }
    }

    private fun schedule(goal: Int, words: List<WordEntity>) {
        val alarm = context.getSystemService(AlarmManager::class.java)
        for (code in REQUEST_BASE until REQUEST_BASE + MAX) {
            val pi = PendingIntent.getBroadcast(context, code, Intent(context, ReminderReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            alarm.cancel(pi)
        }
        val now = Instant.now(); val zone = ZoneId.systemDefault(); val today = LocalDate.now(zone); val last = today.plusDays(DAYS)
        val eligible = words.filter { !it.nextReviewAt.isAfter(now.plus(DAYS, ChronoUnit.DAYS)) }
        val byDay = eligible.groupBy { w ->
            val d = w.nextReviewAt.atZone(zone).toLocalDate()
            if (d.isBefore(today)) today else d
        }
        var code = REQUEST_BASE
        byDay.toSortedMap().forEach { (day, dayWords) ->
            dayWords.sortedWith(compareBy<WordEntity> { it.nextReviewAt }.thenBy { it.createdAt }).take(goal).forEach { word ->
                if (code >= REQUEST_BASE + MAX) return@forEach
                val whenMillis = if (day == today && word.nextReviewAt.isBefore(now)) System.currentTimeMillis() + 1000 else word.nextReviewAt.toEpochMilli()
                val intent = Intent(context, ReminderReceiver::class.java).apply { putExtra(ReminderReceiver.EXTRA_WORD_ID, word.id); putExtra(ReminderReceiver.EXTRA_NOTIFICATION_ID, code) }
                val pi = PendingIntent.getBroadcast(context, code, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                if (android.os.Build.VERSION.SDK_INT >= 23) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMillis, pi) else alarm.set(AlarmManager.RTC_WAKEUP, whenMillis, pi)
                code++
            }
        }
    }
}
