package com.wordloop.app.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.wordloop.app.data.database.WordLoopDatabase
import com.wordloop.app.data.database.entities.WordEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.temporal.ChronoUnit

/** Schedules notifications for the daily-goal slice of the review queue. */
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

class ReminderScheduler @Inject constructor(@ApplicationContext private val context: Context) {
    companion object {
        private const val REQUEST_BASE = 30000
        private const val DAYS_TO_SCHEDULE = 14L
    }

    fun rescheduleUpcoming() {
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            val db = WordLoopDatabase.open(context)
            try {
                val goal = db.appSettingsDao().get()?.dailyGoal?.coerceAtLeast(1) ?: 10
                val words = db.wordDao().getAllWordsOnce()
                schedule(goal, words)
            } finally {
                db.close()
            }
        }
    }

    private fun schedule(goal: Int, words: List<WordEntity>) {
        val alarm = context.getSystemService(AlarmManager::class.java)
        for (requestCode in REQUEST_BASE until REQUEST_BASE + 10000) {
            val pi = PendingIntent.getBroadcast(
                context,
                requestCode,
                Intent(context, ReminderReceiver::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            alarm.cancel(pi)
        }

        val now = Instant.now()
        val end = now.plus(DAYS_TO_SCHEDULE, ChronoUnit.DAYS)

        // The daily goal limits the number of notifications that are active at a time.
        // Overdue words are eligible immediately; future words are scheduled at nextReviewAt.
        val eligible = words
            .filter { !it.nextReviewAt.isAfter(end) }
            .sortedWith(compareBy<WordEntity> { it.nextReviewAt }.thenBy { it.createdAt })
            .take(goal)

        var requestCode = REQUEST_BASE
        eligible.forEach { word ->
            if (requestCode >= REQUEST_BASE + 10000) return@forEach
            val millis = word.nextReviewAt.toEpochMilli().coerceAtLeast(System.currentTimeMillis() + 1000)
            val intent = Intent(context, ReminderReceiver::class.java).apply {
                putExtra(ReminderReceiver.EXTRA_WORD_ID, word.id)
                putExtra(ReminderReceiver.EXTRA_NOTIFICATION_ID, requestCode)
            }
            val pi = PendingIntent.getBroadcast(
                context,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, millis, pi)
            requestCode++
        }
    }
}
