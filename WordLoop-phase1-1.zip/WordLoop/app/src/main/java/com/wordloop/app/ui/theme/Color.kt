package com.wordloop.app.ui.theme

import androidx.compose.ui.graphics.Color

// Light scheme — teal for focus/growth, warm amber as the encouraging accent.
val TealPrimary = Color(0xFF00796B)
val TealPrimaryContainer = Color(0xFFB2DFDB)
val OnTealPrimary = Color(0xFFFFFFFF)
val AmberSecondary = Color(0xFFFFA000)
val AmberSecondaryContainer = Color(0xFFFFECB3)
val OnAmberSecondary = Color(0xFF3E2723)
val LightBackground = Color(0xFFFBFDFB)
val LightSurface = Color(0xFFFFFFFF)
val LightOnSurface = Color(0xFF1B1F1E)
val ErrorRed = Color(0xFFB3261E)

// Dark scheme
val TealPrimaryDark = Color(0xFF80CBC4)
val TealPrimaryContainerDark = Color(0xFF00504A)
val OnTealPrimaryDark = Color(0xFF00382F)
val AmberSecondaryDark = Color(0xFFFFCC80)
val AmberSecondaryContainerDark = Color(0xFF5C4200)
val OnAmberSecondaryDark = Color(0xFF3E2723)
val DarkBackground = Color(0xFF10130F)
val DarkSurface = Color(0xFF1B1F1E)
val DarkOnSurface = Color(0xFFE2E3E1)
val ErrorRedDark = Color(0xFFF2B8B5)
