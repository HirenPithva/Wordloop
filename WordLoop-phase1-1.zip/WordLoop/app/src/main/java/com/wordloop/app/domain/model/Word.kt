package com.wordloop.app.domain.model

import java.time.Instant

/**
 * A single vocabulary word and its spaced-repetition state.
 *
 * currentIntervalHours tracks the interval that produced nextReviewAt, using
 * the schedule from the spec: 24h for reviews 1-10, 72h (3 days) for 11-20,
 * 216h (9 days) from 21 onward. isDue is deliberately NOT stored — it is
 * always derived from nextReviewAt so it can never drift out of sync.
 */
data class Word(
    val id: Long = 0,
    val word: String,
    val meaning: String,
    val example: String?,
    val audioPath: String?,
    val audioPaths: List<String> = emptyList(),
    val createdAt: Instant,
    val lastReviewedAt: Instant?,
    val nextReviewAt: Instant,
    val reviewCount: Int,
    val currentIntervalHours: Long
) {
    fun isDue(now: Instant = Instant.now()): Boolean = !nextReviewAt.isAfter(now)
}
