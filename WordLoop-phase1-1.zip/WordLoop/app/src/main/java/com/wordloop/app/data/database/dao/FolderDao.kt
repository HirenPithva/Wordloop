package com.wordloop.app.data.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Delete
import com.wordloop.app.data.database.entities.FolderEntity
import com.wordloop.app.data.database.entities.WordFolderCrossRef
import kotlinx.coroutines.flow.Flow

@Dao
interface FolderDao {
    @Query("SELECT * FROM folders ORDER BY parentId IS NOT NULL, name COLLATE NOCASE")
    fun observeAll(): Flow<List<FolderEntity>>
    @Query("SELECT * FROM folders ORDER BY name COLLATE NOCASE")
    suspend fun getAll(): List<FolderEntity>
    @Query("SELECT * FROM folders WHERE id = :id") suspend fun get(id: Long): FolderEntity?
    @Insert(onConflict = OnConflictStrategy.ABORT) suspend fun insert(folder: FolderEntity): Long
    @Delete suspend fun delete(folder: FolderEntity)
    @Query("SELECT * FROM word_folder_cross_ref") suspend fun getAllRefs(): List<WordFolderCrossRef>
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun addRef(ref: WordFolderCrossRef)
    @Query("DELETE FROM word_folder_cross_ref WHERE wordId = :wordId") suspend fun clearWord(wordId: Long)
    @Query("DELETE FROM word_folder_cross_ref WHERE wordId = :wordId AND folderId = :folderId") suspend fun removeRef(wordId: Long, folderId: Long)
    @Query("SELECT wordId FROM word_folder_cross_ref WHERE folderId = :folderId") suspend fun wordIds(folderId: Long): List<Long>
}
