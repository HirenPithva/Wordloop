package com.wordloop.app.data.database.dao

import androidx.room.*
import com.wordloop.app.data.database.entities.FolderEntity
import com.wordloop.app.data.database.entities.WordFolderCrossRef
import kotlinx.coroutines.flow.Flow

@Dao
interface FolderDao {
    @Query("SELECT * FROM folders WHERE parentId IS NULL ORDER BY name COLLATE NOCASE")
    fun observeRoots(): Flow<List<FolderEntity>>
    @Query("SELECT * FROM folders WHERE parentId = :parentId ORDER BY name COLLATE NOCASE")
    fun observeChildren(parentId: Long): Flow<List<FolderEntity>>
    @Query("SELECT * FROM folders ORDER BY name COLLATE NOCASE")
    suspend fun getAll(): List<FolderEntity>
    @Query("SELECT * FROM folders WHERE id = :id") suspend fun get(id: Long): FolderEntity?
    @Query("SELECT COUNT(*) FROM folders WHERE name = :name AND ((parentId IS NULL AND :parentId IS NULL) OR parentId = :parentId)")
    suspend fun countSameName(name: String, parentId: Long?): Int
    @Insert suspend fun insert(folder: FolderEntity): Long
    @Delete suspend fun delete(folder: FolderEntity)
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun addWordFolder(ref: WordFolderCrossRef)
    @Query("DELETE FROM word_folder_cross_ref WHERE wordId = :wordId") suspend fun clearWordFolders(wordId: Long)
    @Query("SELECT folderId FROM word_folder_cross_ref WHERE wordId = :wordId") suspend fun getFolderIdsForWord(wordId: Long): List<Long>
    @Query("SELECT wordId FROM word_folder_cross_ref WHERE folderId = :folderId") suspend fun getWordIds(folderId: Long): List<Long>
}
