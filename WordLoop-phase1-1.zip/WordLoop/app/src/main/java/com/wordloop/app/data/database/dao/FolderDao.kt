package com.wordloop.app.data.database.dao

import androidx.room.*
import com.wordloop.app.data.database.entities.FolderEntity
import com.wordloop.app.data.database.entities.WordFolderCrossRef
import kotlinx.coroutines.flow.Flow

@Dao
interface FolderDao {
    @Query("SELECT * FROM folders ORDER BY name COLLATE NOCASE") fun observeAll(): Flow<List<FolderEntity>>
    @Query("SELECT * FROM folders ORDER BY name COLLATE NOCASE") suspend fun getAll(): List<FolderEntity>
    @Query("SELECT * FROM folders WHERE id = :id") suspend fun get(id: Long): FolderEntity?
    @Query("SELECT * FROM folders WHERE parentId IS :parentId ORDER BY name COLLATE NOCASE") suspend fun children(parentId: Long?): List<FolderEntity>
    @Insert suspend fun insert(folder: FolderEntity): Long
    @Update suspend fun update(folder: FolderEntity)
    @Delete suspend fun delete(folder: FolderEntity)
    @Query("DELETE FROM folders") suspend fun deleteAll()
    @Query("DELETE FROM word_folder_cross_ref WHERE folderId = :folderId") suspend fun clearFolderRefs(folderId: Long)

    @Query("SELECT folderId FROM word_folder_cross_ref WHERE wordId = :wordId") suspend fun folderIdsForWord(wordId: Long): List<Long>
    @Query("SELECT wordId FROM word_folder_cross_ref WHERE folderId = :folderId") suspend fun wordIdsInFolder(folderId: Long): List<Long>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun addWordFolder(ref: WordFolderCrossRef)
    @Query("DELETE FROM word_folder_cross_ref WHERE wordId = :wordId") suspend fun clearWordFolders(wordId: Long)
    @Query("SELECT * FROM word_folder_cross_ref") suspend fun getAllRefs(): List<WordFolderCrossRef>
    @Query("SELECT * FROM word_folder_cross_ref") fun observeAllRefs(): Flow<List<WordFolderCrossRef>>
}
