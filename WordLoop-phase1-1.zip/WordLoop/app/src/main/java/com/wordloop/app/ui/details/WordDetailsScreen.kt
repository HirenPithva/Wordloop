package com.wordloop.app.ui.details
import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.wordloop.app.domain.audio.AudioPlayer
import com.wordloop.app.domain.model.Word
import com.wordloop.app.domain.repository.WordRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import androidx.lifecycle.*
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

@HiltViewModel class WordDetailsViewModel @Inject constructor(private val repo:WordRepository):ViewModel(){
 var word by mutableStateOf<Word?>(null); private set
 fun load(id:Long)=viewModelScope.launch{word=repo.getWordById(id)}
 fun delete(onDone:()->Unit)=viewModelScope.launch{word?.let{repo.deleteWord(it)};onDone()}
}
@Composable fun WordDetailsScreen(id:Long,onEdit:()->Unit,onBack:()->Unit,vm:WordDetailsViewModel=hiltViewModel()){
 LaunchedEffect(id){vm.load(id)}; val w=vm.word; val context=LocalContext.current; val player=remember{AudioPlayer()}; var playing by remember{mutableStateOf(false)}
 DisposableEffect(Unit){onDispose{player.stop()}}
 Scaffold(topBar={TopAppBar(title={Text("Word Details")},navigationIcon={TextButton(onClick=onBack){Text("Back")}})}){p->Column(Modifier.padding(p).padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){if(w==null)Text("Word not found") else {Text(w.word,style=MaterialTheme.typography.headlineMedium);Text(w.meaning,style=MaterialTheme.typography.titleLarge);w.example?.let{Text("Example: $it")};Text("Reviews: ${w.reviewCount}");Text("Next review: ${if(w.isDue())"Due now" else w.nextReviewAt}");w.audioPath?.let{path->Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={playing=true;player.play(path){playing=false}}){Text(if(playing)"Playing…" else "Play audio")};OutlinedButton(onClick={player::stop}){Text("Stop")}}};Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick=onEdit){Text("Edit")};Button(onClick={ {vm.delete(onBack)} }){Text("Delete")}}}}}}
