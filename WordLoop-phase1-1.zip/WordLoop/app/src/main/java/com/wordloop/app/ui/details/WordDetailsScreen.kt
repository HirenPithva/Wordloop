package com.wordloop.app.ui.details

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.*
import com.wordloop.app.domain.audio.AudioPlayer
import com.wordloop.app.domain.model.Word
import com.wordloop.app.domain.repository.WordRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import java.io.File
import javax.inject.Inject
import java.time.Instant
import java.time.Duration

@HiltViewModel
class WordDetailsViewModel @Inject constructor(private val repo: WordRepository) : ViewModel() {
    var word by mutableStateOf<Word?>(null)
        private set
    fun load(id: Long) = viewModelScope.launch { word = repo.getWordById(id) }
    fun delete(onDone: () -> Unit) = viewModelScope.launch {
        word?.let {
            it.audioPaths.forEach { path -> File(path).delete() }
            if (it.audioPaths.isEmpty()) it.audioPath?.let { path -> File(path).delete() }
            repo.deleteWord(it)
        }
        onDone()
    }
}

private fun nextReviewText(next: Instant, now: Instant = Instant.now()): String {
    if (!next.isAfter(now)) return "Due now"
    val totalMinutes = Duration.between(now, next).toMinutes().coerceAtLeast(1)
    val days = totalMinutes / (24 * 60)
    val hours = (totalMinutes % (24 * 60)) / 60
    val minutes = totalMinutes % 60
    return buildList {
        if (days > 0) add("$days day${if (days == 1L) "" else "s"}")
        if (hours > 0) add("$hours hour${if (hours == 1L) "" else "s"}")
        if (days == 0L && hours == 0L) add("$minutes minute${if (minutes == 1L) "" else "s"}")
    }.joinToString(" ")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WordDetailsScreen(
    id: Long,
    onEdit: () -> Unit,
    onBack: () -> Unit,
    vm: WordDetailsViewModel = hiltViewModel()
) {
    LaunchedEffect(id) { vm.load(id) }
    val w = vm.word
    val player = remember { AudioPlayer() }
    var playingIndex by remember { mutableStateOf<Int?>(null) }
    var paused by remember { mutableStateOf(false) }
    var position by remember { mutableIntStateOf(0) }
    var duration by remember { mutableIntStateOf(0) }
    var showDeleteConfirmation by remember { mutableStateOf(false) }

    LaunchedEffect(playingIndex) { while (playingIndex != null && player.hasPlayer()) { position = player.updatePosition(); delay(250) } }
    DisposableEffect(Unit) { onDispose { player.stop() } }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Word Details") },
            navigationIcon = { TextButton(onClick = onBack) { Text("Back") } }
        )
    }) { p ->
        Column(
            Modifier.padding(p).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (w == null) {
                Text("Word not found")
            } else {
                Text(w.word, style = MaterialTheme.typography.headlineMedium)
                Text(w.meaning, style = MaterialTheme.typography.titleLarge)
                w.example?.let { Text("Example: $it") }
                Text("Reviews: ${w.reviewCount}")
                Text("Next review: ${nextReviewText(w.nextReviewAt)}")
                val audioPaths = if (w.audioPaths.isNotEmpty()) w.audioPaths else listOfNotNull(w.audioPath)
                audioPaths.forEachIndexed { index, audioPath ->
                    if (File(audioPath).exists()) {
                        Column {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = {
                                    if (playingIndex == index) { player.togglePause(); paused = !player.isPlaying }
                                    else { playingIndex = index; paused = false; position = 0; duration = 0; player.play(audioPath, onPrepared={duration=it}, onCompletion={playingIndex=null;position=0}, onError={playingIndex=null}) }
                                }) { Text(if (playingIndex == index && !paused) "Pause" else "Play Audio ${index + 1}") }
                                OutlinedButton(onClick = { player.stop(); playingIndex = null; paused=false; position=0 }) { Text("Stop") }
                            }
                            if (playingIndex == index) {
                                Slider(value=position.toFloat(), onValueChange={player.seekTo(it.toInt());position=it.toInt()}, valueRange=0f..duration.coerceAtLeast(1).toFloat())
                                Text("${formatMsDetails(position)} / ${formatMsDetails(duration)}", style=MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onEdit) { Text("Edit") }
                    Button(onClick = { showDeleteConfirmation = true }) { Text("Delete") }
                }
            }
        }
    }

    if (showDeleteConfirmation) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmation = false },
            title = { Text("Delete word?") },
            text = { Text("This will permanently delete the word and its recorded audio.") },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteConfirmation = false
                    vm.delete(onBack)
                }) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmation = false }) { Text("Cancel") }
            }
        )
    }
}

private fun formatMsDetails(ms:Int)=String.format("%d:%02d",ms/60000,(ms/1000)%60)
