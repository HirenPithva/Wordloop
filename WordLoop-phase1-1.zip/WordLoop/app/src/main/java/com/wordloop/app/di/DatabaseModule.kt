package com.wordloop.app.di

import android.content.Context
import androidx.room.Room
import com.wordloop.app.data.database.WordLoopDatabase
import com.wordloop.app.data.database.dao.WordDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): WordLoopDatabase =
        Room.databaseBuilder(context, WordLoopDatabase::class.java, "wordloop.db").build()

    @Provides
    fun provideWordDao(database: WordLoopDatabase): WordDao = database.wordDao()
}
