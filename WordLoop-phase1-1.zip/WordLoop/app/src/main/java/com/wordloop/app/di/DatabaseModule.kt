package com.wordloop.app.di

import android.content.Context
import androidx.room.Room
import com.wordloop.app.data.database.WordLoopDatabase
import com.wordloop.app.data.database.dao.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    @Provides @Singleton
    fun provideDatabase(@ApplicationContext context: Context): WordLoopDatabase =
        Room.databaseBuilder(context, WordLoopDatabase::class.java, "wordloop.db")
            .addMigrations(WordLoopDatabase.MIGRATION_1_2, WordLoopDatabase.MIGRATION_2_3, WordLoopDatabase.MIGRATION_3_4, WordLoopDatabase.MIGRATION_4_5).build()
    @Provides fun wordDao(db: WordLoopDatabase): WordDao = db.wordDao()
    @Provides fun historyDao(db: WordLoopDatabase): ReviewHistoryDao = db.reviewHistoryDao()
    @Provides fun dailyDao(db: WordLoopDatabase): DailyReviewDao = db.dailyReviewDao()
    @Provides fun scheduleDao(db: WordLoopDatabase): ReviewScheduleDao = db.reviewScheduleDao()
    @Provides fun settingsDao(db: WordLoopDatabase): AppSettingsDao = db.appSettingsDao()
}
