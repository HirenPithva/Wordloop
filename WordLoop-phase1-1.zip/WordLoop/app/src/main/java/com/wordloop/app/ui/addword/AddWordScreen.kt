package com.wordloop.app.ui.addword

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.wordloop.app.ui.folders.FolderTreeCheckboxes
import androidx.hilt.navigation.compose.hiltViewModel
import com.wordloop.app.ui.audio.AudioPlayerControl
import com.wordloop.app.ui.audio.AudioPlaybackCoordinator
import androidx.core.content.ContextCompat

/**
 * Add Word screen (spec Section 11): word, meaning, optional example, and an
 * optional voice recording. Meaning recall / sentence practice / AI feedback
 * belong to the Review screen, built in Phase 4.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddWordScreen(
    onWordSaved: () -> Unit,
    onCancel: () -> Unit,
    viewModel: AddWordViewModel = hiltViewModel()
) {
    val uiState = viewModel.uiState
    val folders by viewModel.folders.collectAsState()
    val coordinator = remember { AudioPlaybackCoordinator() }
    val context = LocalContext.current
    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { viewModel.addImportedAudio(context, it) }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) viewModel.startRecording() }

    fun onMicClick() {
        val hasPermission = ContextCompat.checkSelfPermission(
            context, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (hasPermission) {
            viewModel.startRecording()
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Add a word") })
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = uiState.word,
                onValueChange = viewModel::onWordChange,
                label = { Text("Word") },
                placeholder = { Text("Abundant") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = uiState.meaning,
                onValueChange = viewModel::onMeaningChange,
                label = { Text("Meaning") },
                placeholder = { Text("Existing in large quantities.") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = uiState.example,
                onValueChange = viewModel::onExampleChange,
                label = { Text("Example (optional)") },
                placeholder = { Text("There are abundant opportunities in this city.") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                modifier = Modifier.fillMaxWidth()
            )

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Audio files", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!uiState.isRecording) {
                        OutlinedButton(onClick = { onMicClick() }) { Text("🎤 Record") }
                        OutlinedButton(onClick = { audioPicker.launch(arrayOf("audio/*")) }) { Text("📁 Add audio") }
                    } else Button(onClick = { viewModel.stopRecording() }) { Text("⏹ Stop") }
                }
                uiState.audioPaths.forEachIndexed { index, path -> AudioPlayerControl(path, "Audio ${index + 1}", { viewModel.deleteRecording(index) }, coordinator) }
            }
            HorizontalDivider()
            Text("Folders", style = MaterialTheme.typography.titleMedium)
            Text("Select one or more folders. Child folders are indented below their parent.", style = MaterialTheme.typography.bodySmall)
            FolderTreeCheckboxes(
                folders = folders,
                selectedIds = uiState.folderIds.toSet(),
                onToggle = viewModel::toggleFolder,
                modifier = Modifier.heightIn(max = 320.dp)
            )

            if (uiState.error != null) {
                Text(
                    text = uiState.error,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) {
                    Text("Cancel")
                }
                Button(
                    onClick = { viewModel.saveWord(onWordSaved) },
                    enabled = !uiState.isSaving,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(if (uiState.isSaving) "Saving…" else "Save word")
                }
            }
        }
    }
}
