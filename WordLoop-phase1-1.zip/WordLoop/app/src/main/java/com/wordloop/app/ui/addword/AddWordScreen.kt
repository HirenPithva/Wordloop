package com.wordloop.app.ui.addword

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.core.content.ContextCompat

/**
 * Add Word screen (spec Section 11): word, meaning, optional example, and an
 * optional voice recording. Meaning recall / sentence practice / AI feedback
 * belong to the Review screen, built in Phase 4.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddWordScreen(
    onWordSaved: () -> Unit,
    onCancel: () -> Unit,
    viewModel: AddWordViewModel = hiltViewModel()
) {
    val uiState = viewModel.uiState
    val context = LocalContext.current
    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { viewModel.addImportedAudio(context, it) }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) viewModel.startRecording() }

    fun onMicClick() {
        val hasPermission = ContextCompat.checkSelfPermission(
            context, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (hasPermission) {
            viewModel.startRecording()
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Add a word") })
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = uiState.word,
                onValueChange = viewModel::onWordChange,
                label = { Text("Word") },
                placeholder = { Text("Abundant") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = uiState.meaning,
                onValueChange = viewModel::onMeaningChange,
                label = { Text("Meaning") },
                placeholder = { Text("Existing in large quantities.") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = uiState.example,
                onValueChange = viewModel::onExampleChange,
                label = { Text("Example (optional)") },
                placeholder = { Text("There are abundant opportunities in this city.") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                modifier = Modifier.fillMaxWidth()
            )

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Voice (optional)", style = MaterialTheme.typography.titleMedium)

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (!uiState.isRecording) {
                        OutlinedButton(onClick = { onMicClick() }) { Text("🎤 Add recording") }
                        OutlinedButton(onClick = { audioPicker.launch(arrayOf("audio/*")) }) { Text("📁 Add audio file") }
                    } else {
                        Button(onClick = { viewModel.stopRecording() }) { Text("⏹ Stop") }
                    }
                }
                uiState.audioPaths.forEachIndexed { index, _ ->
                    Column {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Audio ${index + 1}", modifier = Modifier.weight(1f))
                            Button(onClick = { viewModel.togglePause(index) }, enabled = !uiState.isRecording) { Text(if (viewModel.playingIndex == index && !viewModel.paused) "Pause" else "Play") }
                            TextButton(onClick = { viewModel.deleteRecording(index) }, enabled = !uiState.isRecording) { Text("Delete") }
                        }
                        if (viewModel.playingIndex == index) {
                            Slider(value = viewModel.playbackPosition.toFloat(), onValueChange = { viewModel.seek(it.toInt()) }, valueRange = 0f..viewModel.playbackDuration.coerceAtLeast(1).toFloat())
                            Text("${formatMs(viewModel.playbackPosition)} / ${formatMs(viewModel.playbackDuration)}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }

            val folders by viewModel.folders.collectAsState(initial = emptyList())
            Text("Folders", style = MaterialTheme.typography.titleMedium)
            folders.forEach { folder ->
                Row(Modifier.fillMaxWidth().padding(start = (folderDepth(folder.id, folders) * 16).dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(folder.name)
                    Checkbox(checked = folder.id in uiState.selectedFolderIds, onCheckedChange = { checked ->
                        viewModel.setFolderIds(if (checked) uiState.selectedFolderIds + folder.id else uiState.selectedFolderIds - folder.id)
                    })
                }
            }

            if (uiState.error != null) {
                Text(
                    text = uiState.error,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedButton(onClick = onCancel, modifier = Modifier.weight(1f)) {
                    Text("Cancel")
                }
                Button(
                    onClick = { viewModel.saveWord(onWordSaved) },
                    enabled = !uiState.isSaving,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(if (uiState.isSaving) "Saving…" else "Save word")
                }
            }
        }
    }
}

private fun folderDepth(id: Long, folders: List<com.wordloop.app.data.database.entities.FolderEntity>): Int { var d=0; var p=folders.firstOrNull{it.id==id}?.parentId; while(p!=null){d++;p=folders.firstOrNull{it.id==p}?.parentId}; return d }

private fun formatMs(ms:Int)=String.format("%d:%02d",ms/60000,(ms/1000)%60)
