package com.wordloop.app.data.database.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index

@Entity(
    tableName = "word_folder_cross_ref",
    primaryKeys = ["wordId", "folderId"],
    foreignKeys = [
        ForeignKey(entity = WordEntity::class, parentColumns = ["id"], childColumns = ["wordId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = FolderEntity::class, parentColumns = ["id"], childColumns = ["folderId"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index("folderId")]
)
data class WordFolderCrossRef(val wordId: Long, val folderId: Long)
