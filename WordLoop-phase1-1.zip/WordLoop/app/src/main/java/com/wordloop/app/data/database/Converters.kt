package com.wordloop.app.data.database

import androidx.room.TypeConverter
import java.time.Instant

/** Stores Instant as epoch millis (Long) — Room has no native Instant column type. */
class Converters {
    @TypeConverter
    fun fromInstant(instant: Instant?): Long? = instant?.toEpochMilli()

    @TypeConverter
    fun toInstant(epochMilli: Long?): Instant? = epochMilli?.let { Instant.ofEpochMilli(it) }
}

    @TypeConverter
    fun fromAudioPaths(paths: List<String>?): String =
        org.json.JSONArray().apply { paths.orEmpty().forEach { put(it) } }.toString()

    @TypeConverter
    fun toAudioPaths(value: String?): List<String> {
        if (value.isNullOrBlank()) return emptyList()
        return try {
            val json = org.json.JSONArray(value)
            List(json.length()) { index -> json.getString(index) }
        } catch (_: Exception) {
            emptyList()
        }
    }
