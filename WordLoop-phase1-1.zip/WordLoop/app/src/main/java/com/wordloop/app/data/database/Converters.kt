package com.wordloop.app.data.database

import androidx.room.TypeConverter
import java.time.Instant

/** Stores Instant as epoch millis (Long) — Room has no native Instant column type. */
class Converters {
    @TypeConverter
    fun fromInstant(instant: Instant?): Long? = instant?.toEpochMilli()

    @TypeConverter
    fun toInstant(epochMilli: Long?): Instant? = epochMilli?.let { Instant.ofEpochMilli(it) }
}
