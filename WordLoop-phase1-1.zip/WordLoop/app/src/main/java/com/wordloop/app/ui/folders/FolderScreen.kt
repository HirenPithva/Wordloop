package com.wordloop.app.ui.folders

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.wordloop.app.data.database.entities.FolderEntity

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FolderScreen(onAddFolder:()->Unit,onWordClick:(Long)->Unit,vm:FolderViewModel=hiltViewModel()){
    val folders by vm.folders.collectAsState()
    val words by vm.words.collectAsState()
    val selected=vm.selectedId
    var ids by remember(selected){mutableStateOf<Set<Long>?>(null)}
    LaunchedEffect(selected){ids=if(selected<0)null else vm.wordIds(selected)}
    val visible=if(selected<0) words else words.filter{it.id in (ids?:emptySet())}
    val path=ancestorChain(selected,folders)
    val rows: List<List<FolderEntity>> = if(selected<0) {
        listOf(folders.filter{it.parentId==null}.sortedBy{it.name.lowercase()})
    } else {
        buildList {
            path.forEachIndexed { index, folder ->
                add(if(index < path.lastIndex) listOf(folder) else folders.filter{it.parentId==folder.id}.sortedBy{it.name.lowercase()})
            }
        }
    }

    Scaffold(topBar={TopAppBar(title={Text("Folders")},actions={TextButton(onClick=onAddFolder){Text("Add folder")}})}){p->
        Column(Modifier.padding(p).fillMaxSize()) {
            rows.forEachIndexed { index, options ->
                Row(Modifier.fillMaxWidth().height(56.dp),verticalAlignment=Alignment.CenterVertically){
                    if(index==0){
                        FilterChip(selected=selected<0,onClick=vm::clearSelection,label={Text("All")},modifier=Modifier.padding(start=8.dp))
                    }
                    LazyRow(Modifier.weight(1f).padding(horizontal=8.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                        items(options,key={it.id}){f->
                            FilterChip(selected=selected==f.id,onClick={vm.select(f)},label={Text(f.name)})
                        }
                    }
                }
            }
            if(visible.isEmpty()) Text(if(selected<0) "No words yet." else "No words in this folder.",Modifier.padding(16.dp))
            else LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
                items(visible,key={it.id}){w->
                    Card(onClick={onWordClick(w.id)},modifier=Modifier.fillMaxWidth()){
                        Column(Modifier.padding(16.dp)){Text(w.word,style=MaterialTheme.typography.titleLarge);Text(w.meaning)}
                    }
                }
            }
        }
    }
}

private fun ancestorChain(id:Long,all:List<FolderEntity>):List<FolderEntity>{
    if(id<0)return emptyList()
    val out=mutableListOf<FolderEntity>()
    val seen=mutableSetOf<Long>()
    var cur=all.firstOrNull{it.id==id}
    while(cur!=null && seen.add(cur.id)){
        out.add(cur)
        cur=cur.parentId?.let{p->all.firstOrNull{it.id==p}}
    }
    return out.asReversed()
}
