package com.wordloop.app.ui.folders

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

@Composable
fun FolderScreen(vm: FolderViewModel = hiltViewModel()) {
    val roots by vm.roots.collectAsState(); val children by vm.children.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    LaunchedEffect(roots) { if (vm.selectedId == null) vm.select(null) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = vm.selectedId == null, onClick = { vm.select(null) }, label = { Text("All") })
            roots.forEach { f -> FilterChip(selected = vm.selectedId == f.id, onClick = { vm.select(f.id) }, label = { Text(f.name) }) }
        }
        if (vm.path.isNotEmpty()) Text(vm.path.joinToString(" / "), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(if (vm.selectedId == null) "All words" else "Folder", style = MaterialTheme.typography.titleLarge)
            Button(onClick = { showAdd = true }) { Text("Add folder") }
        }
        if (children.isNotEmpty()) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                children.forEach { f ->
                    FilterChip(selected = vm.selectedId == f.id, onClick = { vm.select(f.id) }, label = { Text(f.name) })
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Words in this folder will appear on the Home list when folder filtering is enabled.", style = MaterialTheme.typography.bodySmall)
    }
    if (showAdd) {
        var name by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { showAdd=false }, title={Text("Add folder")}, text={OutlinedTextField(name,{name=it},label={Text("Folder name")},singleLine=true)}, confirmButton={TextButton(onClick={if(vm.add(name)) showAdd=false}){Text("Save")}}, dismissButton={TextButton(onClick={showAdd=false}){Text("Cancel")}})
    }
}
