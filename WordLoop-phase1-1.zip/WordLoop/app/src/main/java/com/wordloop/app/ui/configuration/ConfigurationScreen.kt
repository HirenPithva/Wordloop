package com.wordloop.app.ui.configuration
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

@Composable fun ConfigurationScreen(vm:ConfigurationViewModel=hiltViewModel()){
 val saved by vm.schedule.collectAsState(); val goal by vm.goal.collectAsState(); var daily by remember(goal){mutableStateOf(goal.toString())}; var rows by remember(saved){mutableStateOf(saved.map{it.afterReviews.toString() to it.remindAfterHours.toString()}.ifEmpty{listOf("1" to "24")})}
 Scaffold(topBar={TopAppBar(title={Text("Configuration")})}){p-> LazyColumn(Modifier.padding(p).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Text("Review cycles",style=MaterialTheme.typography.titleLarge);Text("After a review, the highest matching threshold determines the next reminder.")}
 rows.forEachIndexed{ i,row-> item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(row.first,{v->rows=rows.toMutableList().also{it[i]=v to row.second}},label={Text("After reviews")},modifier=Modifier.weight(1f));OutlinedTextField(row.second,{v->rows=rows.toMutableList().also{it[i]=row.first to v}},label={Text("Remind after (hours)")},modifier=Modifier.weight(1f)); if(rows.size>1) TextButton(onClick={rows=rows.filterIndexed{j,_->j!=i}}){Text("Remove")}}}}
 item{OutlinedButton(onClick={rows=rows+ ("" to "")}){Text("Add review cycle")}}
 item{Text("Daily review goal",style=MaterialTheme.typography.titleLarge);OutlinedTextField(daily,{daily=it},label={Text("Words per day")})}
 item{Button(onClick={vm.save(rows,daily)}){Text("Save")}}
 item{Text("Saved cycles",style=MaterialTheme.typography.titleMedium)}; saved.forEach{item{Text("After ${it.afterReviews} reviews → ${formatHours(it.remindAfterHours)}")}}
 }} }
private fun formatHours(h:Long)=when{h%720==0L->"${h/720} month(s)";h%24==0L->"${h/24} day(s)";else->"${h} hours"}
