package com.wordloop.app.ui.configuration

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConfigurationScreen(vm: ConfigurationViewModel = hiltViewModel()) {
    val saved by vm.schedule.collectAsState()
    val goal by vm.goal.collectAsState()
    val defaultAfter by vm.defaultReviewAfterMinutes.collectAsState()
    var daily by remember(goal) { mutableStateOf(goal.toString()) }
    var defaultAfterText by remember(defaultAfter) { mutableStateOf(defaultAfter.toString()) }
    var rows by remember(saved) { mutableStateOf(saved.map { it.afterReviews.toString() to it.remindAfterMinutes.toString() }.ifEmpty { listOf("1" to "1440") }) }
    var message by remember { mutableStateOf<String?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) vm.export(uri) { ok, error -> message = if (ok) "Backup exported successfully." else "Export failed: ${error ?: "unknown error"}" }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.import(uri) { ok, error -> message = if (ok) "Backup imported successfully." else "Import failed: ${error ?: "unknown error"}" }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Configuration") }) }) { p ->
        LazyColumn(Modifier.padding(p).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Text("Default review", style = MaterialTheme.typography.titleLarge)
                Text("New words with 0 completed reviews use this interval before their first review.")
                OutlinedTextField(defaultAfterText, { defaultAfterText = it }, label = { Text("Review after (minutes)") }, modifier = Modifier.fillMaxWidth())
            }
            item {
                Text("Review cycles", style = MaterialTheme.typography.titleLarge)
                Text("After a completed review, the highest matching threshold determines the next reminder.")
            }
            rows.forEachIndexed { i, row ->
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(row.first, { v -> rows = rows.toMutableList().also { it[i] = v to row.second } }, label = { Text("After reviews") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(row.second, { v -> rows = rows.toMutableList().also { it[i] = row.first to v } }, label = { Text("Remind after (minutes)") }, modifier = Modifier.weight(1f))
                        if (rows.size > 1) TextButton(onClick = { rows = rows.filterIndexed { j, _ -> j != i } }) { Text("Remove") }
                    }
                }
            }
            item { OutlinedButton(onClick = { rows = rows + ("" to "") }) { Text("Add review cycle") } }
            item {
                Text("Daily review goal", style = MaterialTheme.typography.titleLarge)
                OutlinedTextField(daily, { daily = it }, label = { Text("Words per day") })
                Text("This controls which due words receive review notifications first. It is not a hard limit on reviewing.", style = MaterialTheme.typography.bodySmall)
            }
            item { Button(onClick = { vm.save(rows, daily, defaultAfterText) }) { Text("Save") } }
            item { Text("Saved cycles", style = MaterialTheme.typography.titleMedium) }
            saved.forEach { item { Text("After ${it.afterReviews} reviews → ${formatMinutes(it.remindAfterMinutes)}") } }
            item {
                HorizontalDivider()
                Text("Backup & restore", style = MaterialTheme.typography.titleLarge)
                Text("Export includes words, review schedules/history, daily review counts, settings, and audio files.")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { exportLauncher.launch("WordLoop-backup.wordloop") }) { Text("Export data") }
                    OutlinedButton(onClick = { importLauncher.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }) { Text("Import data") }
                }
                Text("Import adds the exported words and history to the current database. Backup settings are restored; existing words are not deleted.", style = MaterialTheme.typography.bodySmall)
                message?.let { Text(it, color = if (it.startsWith("Backup")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error) }
            }
        }
    }
}

private fun formatMinutes(m: Long) = when {
    m >= 43200 && m % 43200 == 0L -> "${m / 43200} month(s)"
    m >= 1440 && m % 1440 == 0L -> "${m / 1440} day(s)"
    m >= 60 && m % 60 == 0L -> "${m / 60} hour(s)"
    else -> "${m} minute(s)"
}
