package com.wordloop.app.ui.addword

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wordloop.app.domain.audio.AudioPlayer
import com.wordloop.app.domain.audio.AudioRecorder
import com.wordloop.app.domain.usecase.AddWordUseCase
import com.wordloop.app.data.database.dao.FolderDao
import com.wordloop.app.data.database.entities.WordFolderCrossRef
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.Job
import java.io.File
import javax.inject.Inject

data class AddWordUiState(
    val word: String = "",
    val meaning: String = "",
    val example: String = "",
    val audioPaths: List<String> = emptyList(),
    val isRecording: Boolean = false,
    val isPlaying: Boolean = false,
    val isSaving: Boolean = false,
    val error: String? = null,
    val selectedFolderIds: Set<Long> = emptySet()
)

@HiltViewModel
class AddWordViewModel @Inject constructor(
    @ApplicationContext appContext: Context,
    private val addWordUseCase: AddWordUseCase,
    private val folderDao: FolderDao
) : ViewModel() {

    private val audioRecorder = AudioRecorder(appContext)
    private val audioPlayer = AudioPlayer()
    private var playbackJob: Job? = null
    var playingIndex by mutableStateOf<Int?>(null); private set
    var playbackPosition by mutableIntStateOf(0); private set
    var playbackDuration by mutableIntStateOf(0); private set
    var paused by mutableStateOf(false); private set

    val folders = folderDao.observeAll()
    var uiState by mutableStateOf(AddWordUiState())
        private set

    fun onWordChange(value: String) {
        uiState = uiState.copy(word = value, error = null)
    }

    fun onMeaningChange(value: String) {
        uiState = uiState.copy(meaning = value, error = null)
    }

    fun setFolderIds(ids: Set<Long>) { uiState = uiState.copy(selectedFolderIds = ids) }

    fun onExampleChange(value: String) {
        uiState = uiState.copy(example = value)
    }

    fun startRecording() {
        val path = audioRecorder.startRecording()
        uiState = uiState.copy(isRecording = true, audioPaths = uiState.audioPaths + path)
    }

    fun stopRecording() {
        val path = audioRecorder.stopRecording()
        uiState = uiState.copy(isRecording = false, audioPaths = if (path != null) uiState.audioPaths.dropLast(1) + path else uiState.audioPaths)
    }

    fun playRecording(index: Int) {
        val path = uiState.audioPaths.getOrNull(index) ?: return
        playbackJob?.cancel(); playingIndex = index; paused = false; playbackPosition = 0; playbackDuration = 0
        uiState = uiState.copy(isPlaying = true)
        audioPlayer.play(path, onPrepared = { playbackDuration = it; startTicker() }, onCompletion = { stopPlaybackState() }, onError = { stopPlaybackState() })
    }
    fun togglePause(index: Int) { if (playingIndex != index) { playRecording(index); return }; audioPlayer.togglePause(); paused = !audioPlayer.isPlaying }
    fun seek(ms: Int) { audioPlayer.seekTo(ms); playbackPosition = ms }
    private fun startTicker() { playbackJob?.cancel(); playbackJob = viewModelScope.launch { while (playingIndex != null && audioPlayer.hasPlayer()) { playbackPosition = audioPlayer.updatePosition(); delay(250) } } }
    private fun stopPlaybackState() { playbackJob?.cancel(); playingIndex = null; paused = false; playbackPosition = 0; playbackDuration = 0; uiState = uiState.copy(isPlaying = false) }


    fun deleteRecording(index: Int) {
        if (playingIndex == index) audioPlayer.stop()
        uiState.audioPaths.getOrNull(index)?.let { File(it).delete() }
        uiState = uiState.copy(audioPaths = uiState.audioPaths.filterIndexed { i, _ -> i != index }, isPlaying = false); stopPlaybackState()
    }

    fun addImportedAudio(context: Context, uri: android.net.Uri) {
        viewModelScope.launch {
            runCatching {
                val mime = context.contentResolver.getType(uri).orEmpty()
                val ext = when (mime.lowercase()) {
                    "audio/mpeg", "audio/mp3" -> "mp3"
                    "audio/wav", "audio/x-wav" -> "wav"
                    "audio/ogg", "application/ogg" -> "ogg"
                    "audio/mp4", "audio/m4a" -> "m4a"
                    else -> "m4a"
                }
                val file = File(context.filesDir, "word_audio_${System.currentTimeMillis()}.$ext")
                context.contentResolver.openInputStream(uri)?.use { input -> file.outputStream().use { output -> input.copyTo(output) } }
                    ?: return@runCatching
                uiState = uiState.copy(audioPaths = uiState.audioPaths + file.absolutePath)
            }
        }
    }

    fun saveWord(onSaved: () -> Unit) {
        if (uiState.word.isBlank() || uiState.meaning.isBlank()) {
            uiState = uiState.copy(error = "Word and meaning are required.")
            return
        }
        viewModelScope.launch {
            uiState = uiState.copy(isSaving = true, error = null)
            val id = addWordUseCase(
                word = uiState.word,
                meaning = uiState.meaning,
                example = uiState.example,
                audioPath = uiState.audioPaths.firstOrNull(),
                audioPaths = uiState.audioPaths
            )
            uiState.selectedFolderIds.forEach { folderDao.addRef(WordFolderCrossRef(id, it)) }
            uiState = uiState.copy(isSaving = false)
            onSaved()
        }
    }

    override fun onCleared() {
        super.onCleared()
        audioPlayer.stop()
    }
}
