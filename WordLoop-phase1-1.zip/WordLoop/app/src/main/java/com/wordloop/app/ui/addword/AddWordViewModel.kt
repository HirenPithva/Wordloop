package com.wordloop.app.ui.addword

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wordloop.app.domain.audio.AudioPlayer
import com.wordloop.app.domain.audio.AudioRecorder
import com.wordloop.app.domain.usecase.AddWordUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

data class AddWordUiState(
    val word: String = "",
    val meaning: String = "",
    val example: String = "",
    val audioPath: String? = null,
    val isRecording: Boolean = false,
    val isPlaying: Boolean = false,
    val isSaving: Boolean = false,
    val error: String? = null
)

@HiltViewModel
class AddWordViewModel @Inject constructor(
    @ApplicationContext appContext: Context,
    private val addWordUseCase: AddWordUseCase
) : ViewModel() {

    private val audioRecorder = AudioRecorder(appContext)
    private val audioPlayer = AudioPlayer()

    var uiState by mutableStateOf(AddWordUiState())
        private set

    fun onWordChange(value: String) {
        uiState = uiState.copy(word = value, error = null)
    }

    fun onMeaningChange(value: String) {
        uiState = uiState.copy(meaning = value, error = null)
    }

    fun onExampleChange(value: String) {
        uiState = uiState.copy(example = value)
    }

    fun startRecording() {
        // Any previous take is discarded once a new recording starts.
        uiState.audioPath?.let { File(it).delete() }
        val path = audioRecorder.startRecording()
        uiState = uiState.copy(isRecording = true, audioPath = path)
    }

    fun stopRecording() {
        val path = audioRecorder.stopRecording()
        uiState = uiState.copy(isRecording = false, audioPath = path)
    }

    fun playRecording() {
        val path = uiState.audioPath ?: return
        uiState = uiState.copy(isPlaying = true)
        audioPlayer.play(path) {
            uiState = uiState.copy(isPlaying = false)
        }
    }

    fun deleteRecording() {
        uiState.audioPath?.let { File(it).delete() }
        uiState = uiState.copy(audioPath = null, isPlaying = false)
    }

    fun saveWord(onSaved: () -> Unit) {
        if (uiState.word.isBlank() || uiState.meaning.isBlank()) {
            uiState = uiState.copy(error = "Word and meaning are required.")
            return
        }
        viewModelScope.launch {
            uiState = uiState.copy(isSaving = true, error = null)
            addWordUseCase(
                word = uiState.word,
                meaning = uiState.meaning,
                example = uiState.example,
                audioPath = uiState.audioPath
            )
            uiState = uiState.copy(isSaving = false)
            onSaved()
        }
    }

    override fun onCleared() {
        super.onCleared()
        audioPlayer.stop()
    }
}
