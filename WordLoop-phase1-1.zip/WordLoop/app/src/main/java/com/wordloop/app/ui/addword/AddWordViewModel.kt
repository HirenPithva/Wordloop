package com.wordloop.app.ui.addword

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wordloop.app.domain.audio.AudioPlayer
import com.wordloop.app.domain.audio.AudioRecorder
import com.wordloop.app.domain.usecase.AddWordUseCase
import com.wordloop.app.data.database.dao.FolderDao
import com.wordloop.app.data.database.entities.WordFolderCrossRef
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

data class AddWordUiState(
    val word: String = "",
    val meaning: String = "",
    val example: String = "",
    val audioPaths: List<String> = emptyList(),
    val isRecording: Boolean = false,
    val isPlaying: Boolean = false,
    val isPaused: Boolean = false,
    val playingIndex: Int? = null,
    val positionMs: Int = 0,
    val durationMs: Int = 0,
    val isSaving: Boolean = false,
    val error: String? = null,
    val folders: List<com.wordloop.app.data.database.entities.FolderEntity> = emptyList(),
    val selectedFolderIds: Set<Long> = emptySet()
)

@HiltViewModel
class AddWordViewModel @Inject constructor(
    @ApplicationContext appContext: Context,
    private val addWordUseCase: AddWordUseCase,
    private val folderDao: FolderDao
) : ViewModel() {

    private val audioRecorder = AudioRecorder(appContext)
    private val audioPlayer = AudioPlayer()

    var uiState by mutableStateOf(AddWordUiState())
        private set

    init { viewModelScope.launch { uiState = uiState.copy(folders = folderDao.getAll()) } }

    fun onWordChange(value: String) {
        uiState = uiState.copy(word = value, error = null)
    }

    fun onMeaningChange(value: String) {
        uiState = uiState.copy(meaning = value, error = null)
    }

    fun onExampleChange(value: String) {
        uiState = uiState.copy(example = value)
    }

    fun startRecording() {
        val path = audioRecorder.startRecording()
        uiState = uiState.copy(isRecording = true, audioPaths = uiState.audioPaths + path)
    }

    fun stopRecording() {
        val path = audioRecorder.stopRecording()
        uiState = uiState.copy(isRecording = false, audioPaths = if (path != null) uiState.audioPaths.dropLast(1) + path else uiState.audioPaths)
    }

    fun playRecording(index: Int) {
        val path = uiState.audioPaths.getOrNull(index) ?: return
        uiState = uiState.copy(isPlaying = true, isPaused = false, playingIndex = index, positionMs = 0, durationMs = 0)
        audioPlayer.play(path) { uiState = uiState.copy(isPlaying = false, isPaused = false, playingIndex = null, positionMs = 0) }
        uiState = uiState.copy(durationMs = audioPlayer.duration())
    }

    fun togglePause() { if (audioPlayer.isPlaying()) { audioPlayer.pause(); uiState = uiState.copy(isPaused = true) } else if (uiState.isPlaying) { audioPlayer.resume(); uiState = uiState.copy(isPaused = false) } }
    fun updatePosition() { uiState = uiState.copy(positionMs = audioPlayer.currentPosition()) }
    fun seek(position: Int) { audioPlayer.seekTo(position); uiState = uiState.copy(positionMs = position) }

    fun deleteRecording(index: Int) {
        uiState.audioPaths.getOrNull(index)?.let { File(it).delete() }
        uiState = uiState.copy(audioPaths = uiState.audioPaths.filterIndexed { i, _ -> i != index }, isPlaying = false, isPaused = false, playingIndex = null, positionMs = 0, durationMs = 0)
    }

    fun addImportedAudio(context: Context, uri: android.net.Uri) {
        viewModelScope.launch {
            runCatching {
                val ext = context.contentResolver.getType(uri)?.substringAfterLast('/')?.lowercase()?.takeIf { it.matches(Regex("[a-z0-9]+")) } ?: "m4a"
                val file = File(context.filesDir, "word_audio_${System.currentTimeMillis()}.$ext")
                context.contentResolver.openInputStream(uri)?.use { input -> file.outputStream().use { output -> input.copyTo(output) } }
                    ?: return@runCatching
                uiState = uiState.copy(audioPaths = uiState.audioPaths + file.absolutePath)
            }
        }
    }

    fun toggleFolder(id: Long) { uiState = uiState.copy(selectedFolderIds = if (id in uiState.selectedFolderIds) uiState.selectedFolderIds - id else uiState.selectedFolderIds + id) }

    fun saveWord(onSaved: () -> Unit) {
        if (uiState.word.isBlank() || uiState.meaning.isBlank()) {
            uiState = uiState.copy(error = "Word and meaning are required.")
            return
        }
        viewModelScope.launch {
            uiState = uiState.copy(isSaving = true, error = null)
            val wordId = runCatching { addWordUseCase(
                word = uiState.word, meaning = uiState.meaning, example = uiState.example,
                audioPath = uiState.audioPaths.firstOrNull(), audioPaths = uiState.audioPaths
            ) }.getOrElse {
                uiState = uiState.copy(isSaving = false, error = it.message ?: "Unable to save word"); return@launch
            }
            uiState.selectedFolderIds.forEach { folderDao.addWordFolder(WordFolderCrossRef(wordId, it)) }
            uiState = uiState.copy(isSaving = false)
            onSaved()
        }
    }

    override fun onCleared() {
        super.onCleared()
        audioPlayer.stop()
    }
}
