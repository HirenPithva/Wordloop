package com.wordloop.app.ui.addword

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wordloop.app.domain.audio.AudioPlayer
import com.wordloop.app.domain.audio.AudioRecorder
import com.wordloop.app.domain.usecase.AddWordUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

data class AddWordUiState(
    val word: String = "",
    val meaning: String = "",
    val example: String = "",
    val audioPaths: List<String> = emptyList(),
    val isRecording: Boolean = false,
    val isPlaying: Boolean = false,
    val isSaving: Boolean = false,
    val error: String? = null
)

@HiltViewModel
class AddWordViewModel @Inject constructor(
    @ApplicationContext appContext: Context,
    private val addWordUseCase: AddWordUseCase
) : ViewModel() {

    private val audioRecorder = AudioRecorder(appContext)
    private val audioPlayer = AudioPlayer()

    var uiState by mutableStateOf(AddWordUiState())
        private set

    fun onWordChange(value: String) {
        uiState = uiState.copy(word = value, error = null)
    }

    fun onMeaningChange(value: String) {
        uiState = uiState.copy(meaning = value, error = null)
    }

    fun onExampleChange(value: String) {
        uiState = uiState.copy(example = value)
    }

    fun startRecording() {
        val path = audioRecorder.startRecording()
        uiState = uiState.copy(isRecording = true, audioPaths = uiState.audioPaths + path)
    }

    fun stopRecording() {
        val path = audioRecorder.stopRecording()
        uiState = uiState.copy(isRecording = false, audioPaths = if (path != null) uiState.audioPaths.dropLast(1) + path else uiState.audioPaths)
    }

    fun playRecording(index: Int) {
        val path = uiState.audioPaths.getOrNull(index) ?: return
        uiState = uiState.copy(isPlaying = true)
        audioPlayer.play(path) {
            uiState = uiState.copy(isPlaying = false)
        }
    }

    fun deleteRecording(index: Int) {
        uiState.audioPaths.getOrNull(index)?.let { File(it).delete() }
        uiState = uiState.copy(audioPaths = uiState.audioPaths.filterIndexed { i, _ -> i != index }, isPlaying = false)
    }

    fun addImportedAudio(context: Context, uri: android.net.Uri) {
        viewModelScope.launch {
            runCatching {
                val file = File(context.filesDir, "word_audio_${System.currentTimeMillis()}.m4a")
                context.contentResolver.openInputStream(uri)?.use { input -> file.outputStream().use { output -> input.copyTo(output) } }
                    ?: return@runCatching
                uiState = uiState.copy(audioPaths = uiState.audioPaths + file.absolutePath)
            }
        }
    }

    fun saveWord(onSaved: () -> Unit) {
        if (uiState.word.isBlank() || uiState.meaning.isBlank()) {
            uiState = uiState.copy(error = "Word and meaning are required.")
            return
        }
        viewModelScope.launch {
            uiState = uiState.copy(isSaving = true, error = null)
            addWordUseCase(
                word = uiState.word,
                meaning = uiState.meaning,
                example = uiState.example,
                audioPath = uiState.audioPaths.firstOrNull(),
                audioPaths = uiState.audioPaths
            )
            uiState = uiState.copy(isSaving = false)
            onSaved()
        }
    }

    override fun onCleared() {
        super.onCleared()
        audioPlayer.stop()
    }
}
