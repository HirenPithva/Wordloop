package com.wordloop.app.domain.usecase
object ReviewIntervalPolicy { fun select(reviewCount:Int, cycles:List<Pair<Int,Long>>):Long = cycles.filter{it.first<=reviewCount}.maxByOrNull{it.first}?.second ?: 1440L }
