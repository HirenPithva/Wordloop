package com.wordloop.app.domain.usecase
/** Returns the interval belonging to the highest configured threshold not above the completed review count. */
object ReviewIntervalPolicy { fun select(reviewCount:Int, cycles:List<Pair<Int,Long>>):Long = cycles.filter{it.first<=reviewCount}.maxByOrNull{it.first}?.second ?: 24L }
