package com.wordloop.app.ui.folders

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.wordloop.app.data.database.entities.FolderEntity

data class FolderTreeRow(val folder: FolderEntity, val depth: Int)

fun flattenFolderTree(folders: List<FolderEntity>): List<FolderTreeRow> {
    val byParent = folders.groupBy { it.parentId }
    val result = mutableListOf<FolderTreeRow>()
    fun add(parentId: Long?, depth: Int) {
        byParent[parentId].orEmpty().sortedBy { it.name.lowercase() }.forEach { folder ->
            result += FolderTreeRow(folder, depth)
            add(folder.id, depth + 1)
        }
    }
    add(null, 0)
    return result
}

@Composable
fun FolderTreeCheckboxes(
    folders: List<FolderEntity>,
    selectedIds: Set<Long>,
    onToggle: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val rows = flattenFolderTree(folders)
    LazyColumn(modifier = modifier, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        items(rows, key = { it.folder.id }) { row ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = (row.depth * 28).dp)
                    .heightIn(min = 48.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (row.depth > 0) "└─ ${row.folder.name}" else row.folder.name,
                    modifier = Modifier.weight(1f),
                    maxLines = 1
                )
                Checkbox(
                    checked = row.folder.id in selectedIds,
                    onCheckedChange = { onToggle(row.folder.id) }
                )
            }
        }
    }
}
