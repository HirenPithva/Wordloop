package com.wordloop.app.ui.navigation
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.wordloop.app.ui.addword.AddWordScreen
import com.wordloop.app.ui.vocabulary.VocabularyListScreen
import com.wordloop.app.ui.review.ReviewScreen
import com.wordloop.app.ui.configuration.ConfigurationScreen
import com.wordloop.app.ui.folders.FoldersScreen
import com.wordloop.app.ui.folders.AddFolderScreen
import com.wordloop.app.ui.details.*
sealed class Screen(val route:String){object Home:Screen("home");object Review:Screen("review");object Add:Screen("add");object Folders:Screen("folders");object AddFolder:Screen("add-folder");object Configuration:Screen("configuration");object Details:Screen("details/{id}"){fun route(id:Long)="details/$id"};object Edit:Screen("edit/{id}"){fun route(id:Long)="edit/$id"}}
@Composable fun WordLoopNavGraph(navController:NavHostController=rememberNavController()){
 val current=navController.currentBackStackEntryAsState().value?.destination?.route
 Scaffold(bottomBar={NavigationBar{listOf(Screen.Home to "Home",Screen.Review to "Review",Screen.Add to "Add",Screen.Folders to "Folders",Screen.Configuration to "Config").forEach{(s,l)->NavigationBarItem(selected=current?.startsWith(s.route)==true,onClick={navController.navigate(s.route){launchSingleTop=true;popUpTo(Screen.Home.route)}},icon={Text(l.take(1))},label={Text(l)})}}}){inner->NavHost(navController,Screen.Home.route,Modifier.padding(inner)){
  composable(Screen.Home.route){VocabularyListScreen({navController.navigate(Screen.Add.route)},{navController.navigate(Screen.Details.route(it))})}
  composable(Screen.Review.route){ReviewScreen({navController.navigate(Screen.Add.route)})}
  composable(Screen.Add.route){AddWordScreen({navController.popBackStack()},{navController.popBackStack()})}
  composable(Screen.Folders.route){FoldersScreen({navController.navigate(Screen.AddFolder.route)})};composable(Screen.AddFolder.route){AddFolderScreen({navController.popBackStack()},{navController.popBackStack()})};composable(Screen.Configuration.route){ConfigurationScreen()}
  composable(Screen.Details.route){b->val id=b.arguments?.getString("id")?.toLongOrNull()?:return@composable;WordDetailsScreen(id,{navController.navigate(Screen.Edit.route(id))},{navController.popBackStack()})}
  composable(Screen.Edit.route){b->val id=b.arguments?.getString("id")?.toLongOrNull()?:return@composable;EditWordScreen(id,{navController.popBackStack()},{navController.popBackStack()})}
 }}
}
