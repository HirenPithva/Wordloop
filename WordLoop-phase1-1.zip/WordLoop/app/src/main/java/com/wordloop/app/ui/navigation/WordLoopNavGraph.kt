package com.wordloop.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.wordloop.app.ui.addword.AddWordScreen
import com.wordloop.app.ui.vocabulary.VocabularyListScreen

sealed class Screen(val route: String) {
    data object VocabularyList : Screen("vocabulary_list")
    data object AddWord : Screen("add_word")
    // Screen.Dashboard, Screen.Review, Screen.WordDetails, Screen.Settings
    // join here as later phases add their screens.
}

@Composable
fun WordLoopNavGraph(navController: NavHostController = rememberNavController()) {
    NavHost(navController = navController, startDestination = Screen.VocabularyList.route) {
        composable(Screen.VocabularyList.route) {
            VocabularyListScreen(
                onAddWordClick = { navController.navigate(Screen.AddWord.route) }
            )
        }
        composable(Screen.AddWord.route) {
            AddWordScreen(
                onWordSaved = { navController.popBackStack() },
                onCancel = { navController.popBackStack() }
            )
        }
    }
}
