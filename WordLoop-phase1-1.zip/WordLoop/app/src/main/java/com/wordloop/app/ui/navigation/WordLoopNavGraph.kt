package com.wordloop.app.ui.navigation
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.wordloop.app.ui.addword.AddWordScreen
import com.wordloop.app.ui.vocabulary.VocabularyListScreen
import com.wordloop.app.ui.review.ReviewScreen
import com.wordloop.app.ui.configuration.ConfigurationScreen
import com.wordloop.app.ui.folders.*
import com.wordloop.app.ui.details.*
sealed class Screen(val route:String){object Home:Screen("home");object Review:Screen("review");object Add:Screen("add");object Folders:Screen("folders");object Configuration:Screen("configuration");object AddFolder:Screen("addFolder");object Details:Screen("details/{id}"){fun route(id:Long)="details/$id"};object Edit:Screen("edit/{id}"){fun route(id:Long)="edit/$id"}}
@Composable fun WordLoopNavGraph(navController:NavHostController=rememberNavController()){
 val current=navController.currentBackStackEntryAsState().value?.destination?.route
 Scaffold(bottomBar={NavigationBar{listOf(Screen.Home to "Home",Screen.Review to "Review",Screen.Add to "Add",Screen.Folders to "Folders",Screen.Configuration to "Configuration").forEach{(screen,label)->NavigationBarItem(selected=current?.startsWith(screen.route)==true,onClick={navController.navigate(screen.route){launchSingleTop=true;popUpTo(Screen.Home.route)}},icon={Text(label.take(1))},label={Text(label)})}}}){inner->
 NavHost(navController,Screen.Home.route,Modifier.padding(inner)){
  composable(Screen.Home.route){VocabularyListScreen({navController.navigate(Screen.Add.route)},{navController.navigate(Screen.Details.route(it))})}
  composable(Screen.Review.route){ReviewScreen({navController.navigate(Screen.Add.route)})}
  composable(Screen.Add.route){AddWordScreen({navController.popBackStack()},{navController.popBackStack()})}
  composable(Screen.Folders.route){FolderScreen({navController.navigate(Screen.AddFolder.route)},{navController.navigate(Screen.Details.route(it))})}
  composable(Screen.AddFolder.route){AddFolderScreen{navController.popBackStack()}}
  composable(Screen.Configuration.route){ConfigurationScreen()}
  composable(Screen.Details.route){back->val id=back.arguments?.getString("id")?.toLongOrNull()?:return@composable;WordDetailsScreen(id,{navController.navigate(Screen.Edit.route(id))},{navController.popBackStack()})}
  composable(Screen.Edit.route){back->val id=back.arguments?.getString("id")?.toLongOrNull()?:return@composable;EditWordScreen(id,{navController.popBackStack()},{navController.popBackStack()})}
 }
 }
}
