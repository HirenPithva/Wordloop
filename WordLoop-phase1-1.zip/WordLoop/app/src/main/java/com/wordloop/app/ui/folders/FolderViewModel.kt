package com.wordloop.app.ui.folders

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wordloop.app.data.database.dao.FolderDao
import com.wordloop.app.data.database.entities.FolderEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class FolderViewModel @Inject constructor(private val dao: FolderDao) : ViewModel() {
    val roots = dao.observeRoots().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    var selectedId by mutableStateOf<Long?>(null); private set
    var selectedName by mutableStateOf<String?>(null); private set
    var path by mutableStateOf<List<String>>(emptyList()); private set
    val children = MutableStateFlow<List<FolderEntity>>(emptyList())

    fun select(id: Long?) { selectedId = id; viewModelScope.launch {
        val f = id?.let { dao.get(it) }; selectedName = f?.name
        val chain = mutableListOf<String>(); var cur = f
        while (cur != null) { chain.add(0, cur.name); cur = cur.parentId?.let { dao.get(it) } }
        path = chain; children.value = if (id == null) roots.value else dao.observeChildren(id).first()
    }}
    fun add(raw: String): Boolean { val name = raw.trim(); if (name.isBlank() || name.equals("all", true)) return false
        var ok = false; viewModelScope.launch { if (dao.countSameName(name, selectedId) == 0) { dao.insert(FolderEntity(name=name,parentId=selectedId)); select(selectedId); ok = true } }; return true }
}
