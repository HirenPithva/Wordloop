package com.wordloop.app.ui.folders
import androidx.compose.runtime.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wordloop.app.data.database.dao.FolderDao
import com.wordloop.app.data.database.entities.FolderEntity
import com.wordloop.app.domain.repository.WordRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject
@HiltViewModel class FolderViewModel @Inject constructor(private val folderDao: FolderDao, private val wordRepository: WordRepository):ViewModel(){
 val folders=folderDao.observeAll().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
 val words=wordRepository.observeAllWords().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
 var selectedId by mutableLongStateOf(-1L); private set
 fun select(f:FolderEntity){selectedId=f.id}
 fun clearSelection(){selectedId=-1L}
 fun create(name:String,parentId:Long?,done:()->Unit)=viewModelScope.launch{
  val clean=name.trim()
  if(clean.isBlank() || clean.equals("All",true)) return@launch
  val duplicate=folders.value.any{it.parentId==parentId && it.name.equals(clean,true)}
  if(duplicate) return@launch
  runCatching{folderDao.insert(FolderEntity(name=clean,parentId=parentId))}.onSuccess{done()}
}
 suspend fun wordIds(folderId:Long)=folderDao.wordIds(folderId).toSet()
 fun children(parentId:Long?)=folders.value.filter{it.parentId==parentId}.sortedBy{it.name.lowercase()}
}
