package com.wordloop.app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/**
 * Application entry point. @HiltAndroidApp triggers Hilt's code generation
 * and creates the top-level dependency container that every other Hilt
 * container in the app (Activity, ViewModel, ...) attaches to.
 */
@HiltAndroidApp
class WordLoopApplication : Application()
