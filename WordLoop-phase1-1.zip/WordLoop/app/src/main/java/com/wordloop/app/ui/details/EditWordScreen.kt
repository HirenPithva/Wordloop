package com.wordloop.app.ui.details

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wordloop.app.domain.audio.AudioPlayer
import com.wordloop.app.domain.audio.AudioRecorder
import com.wordloop.app.domain.model.Word
import com.wordloop.app.domain.repository.WordRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

@HiltViewModel
class EditWordViewModel @Inject constructor(
    @ApplicationContext appContext: Context,
    private val repo: WordRepository
) : ViewModel() {
    var word by mutableStateOf<Word?>(null)
        private set
    var isRecording by mutableStateOf(false)
        private set
    var isPlaying by mutableStateOf(false)
        private set

    private val audioRecorder = AudioRecorder(appContext)
    private val audioPlayer = AudioPlayer()

    fun load(id: Long) = viewModelScope.launch {
        word = repo.getWordById(id)
    }

    fun startRecording() {
        if (isRecording) return
        val path = audioRecorder.startRecording()
        word = word?.copy(audioPaths = word!!.audioPaths + path, audioPath = word!!.audioPaths.firstOrNull() ?: path)
        isRecording = true
    }

    fun stopRecording() {
        val path = audioRecorder.stopRecording()
        word = word?.let { current ->
            if (path == null) current else current.copy(audioPaths = current.audioPaths.dropLast(1) + path, audioPath = current.audioPaths.dropLast(1).firstOrNull() ?: path)
        }
        isRecording = false
    }

    fun playAudio(index: Int) {
        val path = word?.audioPaths?.getOrNull(index) ?: word?.audioPath ?: return
        if (!File(path).exists()) return
        isPlaying = true
        audioPlayer.play(path) { isPlaying = false }
    }

    fun stopAudio() {
        audioPlayer.stop()
        isPlaying = false
    }

    fun removeAudio(index: Int) {
        stopAudio()
        word?.let { current ->
            val currentPaths = current.audioPaths.ifEmpty { listOfNotNull(current.audioPath) }
            currentPaths.getOrNull(index)?.let { File(it).delete() }
            val remaining = currentPaths.filterIndexed { i, _ -> i != index }
            word = current.copy(audioPaths = remaining, audioPath = remaining.firstOrNull())
        }
    }

    fun addImportedAudio(context: Context, uri: android.net.Uri) {
        viewModelScope.launch {
            runCatching {
                val file = File(context.filesDir, "word_audio_${System.currentTimeMillis()}.m4a")
                context.contentResolver.openInputStream(uri)?.use { input -> file.outputStream().use { output -> input.copyTo(output) } }
                    ?: return@runCatching
                word = word?.let { current -> current.copy(audioPaths = current.audioPaths + file.absolutePath, audioPath = current.audioPath ?: file.absolutePath) }
            }
        }
    }

    fun save(wordText: String, meaning: String, example: String, onDone: () -> Unit) =
        viewModelScope.launch {
            word?.let {
                repo.updateWord(
                    it.copy(
                        word = wordText.trim(),
                        meaning = meaning.trim(),
                        example = example.trim().ifBlank { null }
                    )
                )
            }
            onDone()
        }

    override fun onCleared() {
        audioPlayer.stop()
        if (isRecording) audioRecorder.cancelRecording()
        super.onCleared()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditWordScreen(
    id: Long,
    onSaved: () -> Unit,
    onBack: () -> Unit,
    vm: EditWordViewModel = hiltViewModel()
) {
    LaunchedEffect(id) { vm.load(id) }
    val w = vm.word
    val context = LocalContext.current
    var word by remember { mutableStateOf("") }
    var meaning by remember { mutableStateOf("") }
    var example by remember { mutableStateOf("") }
    var showAudioDeleteConfirmation by remember { mutableStateOf<Int?>(null) }

    LaunchedEffect(w?.id) {
        w?.let {
            word = it.word
            meaning = it.meaning
            example = it.example.orEmpty()
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) vm.startRecording()
    }

    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { vm.addImportedAudio(context, it) }
    }

    fun recordClick() {
        val granted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) vm.startRecording()
        else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Edit Word") })
    }) { p ->
        Column(
            Modifier.padding(p).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = word,
                onValueChange = { word = it },
                label = { Text("Word") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = meaning,
                onValueChange = { meaning = it },
                label = { Text("Meaning") },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = example,
                onValueChange = { example = it },
                label = { Text("Example") },
                modifier = Modifier.fillMaxWidth()
            )

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Audio (optional)", style = MaterialTheme.typography.titleMedium)
                if (w?.audioPaths.isNullOrEmpty() && w?.audioPath == null && !vm.isRecording) {
                    Text("No audio added")
                }
                if (!vm.isRecording) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { recordClick() }) { Text("🎤 Add recording") }
                        OutlinedButton(onClick = { audioPicker.launch(arrayOf("audio/*")) }) { Text("📁 Add audio file") }
                    }
                } else {
                    Button(onClick = { vm.stopRecording() }) { Text("⏹ Stop") }
                }
                val paths = w?.audioPaths.orEmpty().ifEmpty { listOfNotNull(w?.audioPath) }
                paths.forEachIndexed { index, path ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Audio ${index + 1}", modifier = Modifier.weight(1f))
                        OutlinedButton(onClick = { vm.playAudio(index) }, enabled = !vm.isPlaying && !vm.isRecording) { Text("▶ Play") }
                        TextButton(onClick = { showAudioDeleteConfirmation = index }, enabled = !vm.isRecording) { Text("Remove") }
                    }
                }
            }

            Button(
                onClick = {
                    if (word.isNotBlank() && meaning.isNotBlank()) {
                        vm.save(word, meaning, example, onSaved)
                    }
                },
                enabled = !vm.isRecording,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Save")
            }
            TextButton(onClick = onBack) { Text("Cancel") }
        }
    }

    showAudioDeleteConfirmation?.let { index ->
        AlertDialog(
            onDismissRequest = { showAudioDeleteConfirmation = null },
            title = { Text("Remove audio?") },
            text = { Text("This audio file will be removed from this word.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.removeAudio(index)
                    showAudioDeleteConfirmation = null
                }) { Text("Remove") }
            },
            dismissButton = {
                TextButton(onClick = { showAudioDeleteConfirmation = null }) { Text("Cancel") }
            }
        )
    }
}
