package com.wordloop.app.ui.details
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.*
import com.wordloop.app.domain.model.Word
import com.wordloop.app.domain.repository.WordRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel class EditWordViewModel @Inject constructor(private val repo:WordRepository):ViewModel(){
 var word by mutableStateOf<Word?>(null); private set
 fun load(id:Long)=viewModelScope.launch{word=repo.getWordById(id)}
 fun save(wordText:String,meaning:String,example:String,onDone:()->Unit)=viewModelScope.launch{word?.let{repo.updateWord(it.copy(word=wordText.trim(),meaning=meaning.trim(),example=example.trim().ifBlank{null}))};onDone()}
}
@Composable fun EditWordScreen(id:Long,onSaved:()->Unit,onBack:()->Unit,vm:EditWordViewModel=hiltViewModel()){
 LaunchedEffect(id){vm.load(id)}; val w=vm.word; var word by remember{mutableStateOf("")};var meaning by remember{mutableStateOf("")};var example by remember{mutableStateOf("")};LaunchedEffect(w){w?.let{word=it.word;meaning=it.meaning;example=it.example.orEmpty()}}
 Scaffold(topBar={TopAppBar(title={Text("Edit Word")})}){p->Column(Modifier.padding(p).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){OutlinedTextField(word,{word=it},label={Text("Word")},modifier=Modifier.fillMaxWidth());OutlinedTextField(meaning,{meaning=it},label={Text("Meaning")},modifier=Modifier.fillMaxWidth());OutlinedTextField(example,{example=it},label={Text("Example")},modifier=Modifier.fillMaxWidth());Button(onClick={if(word.isNotBlank()&&meaning.isNotBlank())vm.save(word,meaning,example,onSaved)},modifier=Modifier.fillMaxWidth()){Text("Save")};TextButton(onClick=onBack){Text("Cancel")}}}
}
