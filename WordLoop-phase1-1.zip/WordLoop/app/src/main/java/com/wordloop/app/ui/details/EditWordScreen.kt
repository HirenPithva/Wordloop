package com.wordloop.app.ui.details

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wordloop.app.data.database.entities.FolderEntity
import com.wordloop.app.domain.audio.AudioRecorder
import com.wordloop.app.domain.model.Word
import com.wordloop.app.domain.repository.FolderRepository
import com.wordloop.app.domain.repository.WordRepository
import com.wordloop.app.ui.audio.AudioPlayerControl
import com.wordloop.app.ui.audio.AudioPlaybackCoordinator
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

@HiltViewModel
class EditWordViewModel @Inject constructor(@ApplicationContext appContext: Context, private val repo: WordRepository, private val folderRepo: FolderRepository): ViewModel() {
    var word by mutableStateOf<Word?>(null); private set
    var isRecording by mutableStateOf(false); private set
    val folders=folderRepo.observeFolders().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
    private val recorder=AudioRecorder(appContext)
    fun load(id:Long)=viewModelScope.launch{word=repo.getWordById(id)}
    fun startRecording(){if(isRecording)return; val p=recorder.startRecording(); word=word?.copy(audioPaths=word!!.audioPaths+p,audioPath=word!!.audioPath?:p);isRecording=true}
    fun stopRecording(){val p=recorder.stopRecording(); word=word?.let{if(p==null)it else it.copy(audioPaths=it.audioPaths.dropLast(1)+p,audioPath=it.audioPath?:p)};isRecording=false}
    fun removeAudio(i:Int){word?.let{val paths=it.audioPaths.ifEmpty{listOfNotNull(it.audioPath)};paths.getOrNull(i)?.let{path->File(path).delete()};val r=paths.filterIndexed{j,_->j!=i};word=it.copy(audioPaths=r,audioPath=r.firstOrNull())}}
    fun addImportedAudio(context:Context,uri:android.net.Uri)=viewModelScope.launch{val file=File(context.filesDir,"word_audio_${System.currentTimeMillis()}.m4a");context.contentResolver.openInputStream(uri)?.use{input->file.outputStream().use{out->input.copyTo(out)}};word=word?.let{it.copy(audioPaths=it.audioPaths+file.absolutePath,audioPath=it.audioPath?:file.absolutePath)}}
    fun toggleFolder(id:Long){word=word?.copy(folderIds=if(id in word!!.folderIds)word!!.folderIds-id else word!!.folderIds+id)}
    fun save(text:String,meaning:String,example:String,onDone:()->Unit)=viewModelScope.launch{word?.let{repo.updateWord(it.copy(word=text.trim(),meaning=meaning.trim(),example=example.trim().ifBlank{null}))};onDone()}
    fun delete(onDone:()->Unit)=viewModelScope.launch{word?.let{repo.deleteWord(it)};onDone()}
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditWordScreen(id:Long,onSaved:()->Unit,onBack:()->Unit,vm:EditWordViewModel=hiltViewModel()){
    LaunchedEffect(id){vm.load(id)};val w=vm.word;val folders by vm.folders.collectAsState();val context=LocalContext.current
    var word by remember{mutableStateOf("")};var meaning by remember{mutableStateOf("")};var example by remember{mutableStateOf("")};var confirmDelete by remember{mutableStateOf(false)}
    LaunchedEffect(w?.id){w?.let{word=it.word;meaning=it.meaning;example=it.example.orEmpty()}}
    val coordinator = remember { AudioPlaybackCoordinator() }
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){it?.let{vm.addImportedAudio(context,it)}}
    val permission=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){if(it)vm.startRecording()}
    Scaffold(topBar={TopAppBar(title={Text("Edit Word")},navigationIcon={TextButton(onClick=onBack){Text("Back")}})}){p->
        Column(Modifier.padding(p).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
            OutlinedTextField(word,{word=it},label={Text("Word")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(meaning,{meaning=it},label={Text("Meaning")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(example,{example=it},label={Text("Example")},modifier=Modifier.fillMaxWidth())
            Text("Audio",style=MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){if(!vm.isRecording){OutlinedButton(onClick={if(ContextCompat.checkSelfPermission(context,Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)vm.startRecording() else permission.launch(Manifest.permission.RECORD_AUDIO)}){Text("🎤 Record")};OutlinedButton(onClick={picker.launch(arrayOf("audio/*"))}){Text("📁 Add audio")}}else Button(onClick={vm.stopRecording()}){Text("⏹ Stop")}}
            (w?.audioPaths?.ifEmpty{listOfNotNull(w.audioPath)}?:emptyList()).forEachIndexed{i,path->AudioPlayerControl(path,"Audio ${i+1}",{vm.removeAudio(i)},coordinator)}
            Text("Folders",style=MaterialTheme.typography.titleMedium)
            folders.forEach{f->Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Checkbox(checked=f.id in (w?.folderIds?:emptyList()),onCheckedChange={vm.toggleFolder(f.id)});Text(f.name)}}
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={vm.save(word,meaning,example,onSaved)}){Text("Save")};OutlinedButton(onClick={onBack}){Text("Cancel")};Button(onClick={confirmDelete=true}){Text("Delete")}}
        }
    }
    if(confirmDelete)AlertDialog(onDismissRequest={confirmDelete=false},title={Text("Delete word?")},text={Text("This permanently deletes the word and its audio." )},confirmButton={TextButton(onClick={vm.delete(onBack);confirmDelete=false}){Text("Delete")}},dismissButton={TextButton(onClick={confirmDelete=false}){Text("Cancel")}})
}
