package com.wordloop.app.domain.repository

import com.wordloop.app.domain.model.Word
import kotlinx.coroutines.flow.Flow
import java.time.Instant

interface WordRepository {

    /** All words, newest first. Backs the "My Words" list (Section 23). */
    fun observeAllWords(): Flow<List<Word>>

    fun observeWordCount(): Flow<Int>

    suspend fun getWordById(id: Long): Word?

    /** Returns the new word's generated id. */
    suspend fun addWord(word: Word): Long

    suspend fun updateWord(word: Word)

    suspend fun deleteWord(word: Word)

    /**
     * Words whose nextReviewAt has passed, oldest due (then oldest created)
     * first — the ordering the daily queue (Section 5) prioritizes from.
     * Wired up fully in Phase 2; present now so the schema/repository
     * contract is settled before the queue logic is built on top of it.
     */
    suspend fun getDueWords(now: Instant = Instant.now()): List<Word>
}
