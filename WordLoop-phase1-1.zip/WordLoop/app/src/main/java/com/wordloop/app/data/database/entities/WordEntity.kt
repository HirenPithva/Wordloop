package com.wordloop.app.data.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.time.Instant

/**
 * Room row for a vocabulary word (spec Section 12). isDue is intentionally
 * not a column — it's always derived from nextReviewAt at query/read time.
 */
@Entity(tableName = "words")
data class WordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val word: String,
    val meaning: String,
    val example: String?,
    val audioPath: String?,
    val audioPaths: List<String> = emptyList(),
    val createdAt: Instant,
    val lastReviewedAt: Instant?,
    val nextReviewAt: Instant,
    val reviewCount: Int,
    val currentIntervalHours: Long
)
