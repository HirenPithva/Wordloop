package com.wordloop.app.ui.review

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wordloop.app.domain.model.Word
import com.wordloop.app.domain.repository.ReviewRepository
import com.wordloop.app.domain.repository.WordRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.Instant
import javax.inject.Inject

data class ReviewUiState(val due: List<Word> = emptyList(), val index: Int = 0, val completedToday: Int = 0, val goal: Int = 10, val revealed: Boolean = false)
@HiltViewModel
class ReviewViewModel @Inject constructor(private val words: WordRepository, private val reviews: ReviewRepository) : ViewModel() {
    private val _state = MutableStateFlow(ReviewUiState()); val state: StateFlow<ReviewUiState> = _state.asStateFlow()
    init { refresh() }
    fun refresh() = viewModelScope.launch { _state.value = _state.value.copy(due = words.getDueWords(Instant.now()), completedToday = reviews.getTodayCount()) ; launch { reviews.observeDailyGoal().collect { _state.value = _state.value.copy(goal=it) } } }
    fun reveal() { _state.value = _state.value.copy(revealed=true) }
    fun complete(onDone: () -> Unit = {}) = viewModelScope.launch {
        val item = _state.value.due.getOrNull(_state.value.index) ?: return@launch
        reviews.completeReview(item.id)
        val next = _state.value.index + 1
        val count = reviews.getTodayCount()
        val due = words.getDueWords(Instant.now())
        _state.value = _state.value.copy(due=due, index=next.coerceAtMost(due.size), completedToday=count, revealed=false)
        onDone()
    }
    fun current(): Word? = _state.value.due.getOrNull(_state.value.index)
}
