package com.wordloop.app.ui.vocabulary

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.wordloop.app.domain.model.Word
import java.time.Instant
import java.time.temporal.ChronoUnit

/**
 * "My Words" (spec Section 23): every stored word with its review count and
 * current cycle. Due-today counts and the daily queue arrive in Phase 2.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VocabularyListScreen(
    onAddWordClick: () -> Unit,
    viewModel: VocabularyListViewModel = hiltViewModel()
) {
    val words by viewModel.words.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("My Words") })
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onAddWordClick) {
                Text("+", style = MaterialTheme.typography.headlineMedium)
            }
        }
    ) { padding ->
        if (words.isEmpty()) {
            EmptyState(modifier = Modifier.padding(padding), onAddWordClick = onAddWordClick)
        } else {
            LazyColumn(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(words, key = { it.id }) { word ->
                    WordCard(word)
                }
            }
        }
    }
}

@Composable
private fun WordCard(word: Word) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(word.word, style = MaterialTheme.typography.titleLarge)
            Text(
                word.meaning,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 4.dp)
            )
            Text(
                "Reviews: ${word.reviewCount}  ·  Cycle: ${cycleLabel(word.currentIntervalHours)}  ·  Next: ${nextReviewLabel(word)}",
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}

@Composable
private fun EmptyState(modifier: Modifier = Modifier, onAddWordClick: () -> Unit) {
    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(32.dp)
        ) {
            Text(
                "Your vocabulary list is empty.",
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center
            )
            Text(
                "Add your first English word and WordLoop will remind you when it's time to review it.",
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center
            )
            Button(onClick = onAddWordClick, modifier = Modifier.padding(top = 8.dp)) {
                Text("+ Add your first word")
            }
        }
    }
}

private fun cycleLabel(intervalHours: Long): String = when {
    intervalHours <= 24 -> "24h"
    intervalHours <= 72 -> "3-day"
    else -> "9-day"
}

private fun nextReviewLabel(word: Word): String {
    val now = Instant.now()
    if (word.isDue(now)) return "due now"
    val hoursUntil = ChronoUnit.HOURS.between(now, word.nextReviewAt)
    return when {
        hoursUntil < 24 -> "in ${hoursUntil}h"
        else -> "in ${hoursUntil / 24}d"
    }
}
