package com.wordloop.app.ui.vocabulary
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.wordloop.app.domain.model.Word
import java.time.Instant

@Composable fun VocabularyListScreen(onAddWordClick:()->Unit,onWordClick:(Long)->Unit,viewModel:VocabularyListViewModel=hiltViewModel()){
 val words by viewModel.words.collectAsState(); var query by remember{mutableStateOf("")}; val filtered=words.filter{it.word.contains(query,true)||it.meaning.contains(query,true)}
 Scaffold(topBar={TopAppBar(title={Text("Home")})},floatingActionButton={FloatingActionButton(onClick=onAddWordClick){Text("+")}}){p->Column(Modifier.padding(p).padding(16.dp)){OutlinedTextField(query,{query=it},label={Text("Search words")},singleLine=true,modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(12.dp));if(filtered.isEmpty())Text(if(words.isEmpty())"No words yet. Add your first word." else "No matching words.") else LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(filtered,key={it.id}){WordCard(it){onWordClick(it.id)}}}}}
}
@Composable private fun WordCard(word:Word,onClick:()->Unit){Card(onClick=onClick,modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text(word.word,style=MaterialTheme.typography.titleLarge);Text(word.meaning);Text("Reviews: ${word.reviewCount} • ${if(word.isDue(Instant.now()))"Due now" else "Next: ${word.nextReviewAt}"}",style=MaterialTheme.typography.labelMedium)}}}
