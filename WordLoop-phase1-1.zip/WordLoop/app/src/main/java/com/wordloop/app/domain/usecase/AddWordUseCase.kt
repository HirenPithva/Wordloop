package com.wordloop.app.domain.usecase

import com.wordloop.app.domain.model.Word
import com.wordloop.app.domain.repository.WordRepository
import com.wordloop.app.domain.repository.ReviewRepository
import java.time.Instant
import java.time.temporal.ChronoUnit
import javax.inject.Inject

/**
 * Adds a new word with reviewCount = 0. The initial review interval is
 * read from the user's configurable default-review-after setting (24 hours (1440 minutes)
 * by default). Review-cycle thresholds apply after completed reviews.
 */
class AddWordUseCase @Inject constructor(
    private val repository: WordRepository,
    private val reviewRepository: ReviewRepository
) {
    companion object {
        private const val FALLBACK_INITIAL_INTERVAL_MINUTES = 1440L
    }

    suspend operator fun invoke(
        word: String,
        meaning: String,
        example: String?,
        audioPath: String?,
        audioPaths: List<String> = emptyList()
    ): Long {
        require(word.isNotBlank()) { "Word must not be blank." }
        require(meaning.isNotBlank()) { "Meaning must not be blank." }

        val now = Instant.now()
        val initialIntervalMinutes = runCatching {
            reviewRepository.getDefaultReviewAfterMinutes().coerceAtLeast(1L)
        }.getOrDefault(FALLBACK_INITIAL_INTERVAL_MINUTES)
        val newWord = Word(
            word = word.trim(),
            meaning = meaning.trim(),
            example = example?.trim()?.takeIf { it.isNotEmpty() },
            audioPath = audioPaths.firstOrNull() ?: audioPath,
            audioPaths = if (audioPaths.isNotEmpty()) audioPaths else listOfNotNull(audioPath),
            createdAt = now,
            lastReviewedAt = null,
            nextReviewAt = now.plus(initialIntervalMinutes, ChronoUnit.MINUTES),
            reviewCount = 0,
            currentIntervalMinutes = initialIntervalMinutes
        )
        return repository.addWord(newWord)
    }
}
