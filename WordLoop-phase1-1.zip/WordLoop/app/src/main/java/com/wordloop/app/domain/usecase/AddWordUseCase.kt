package com.wordloop.app.domain.usecase

import com.wordloop.app.domain.model.Word
import com.wordloop.app.domain.repository.WordRepository
import java.time.Instant
import java.time.temporal.ChronoUnit
import javax.inject.Inject

/**
 * Adds a new word with the initial spaced-repetition state from the spec
 * (Section 2): reviewCount = 0, currentInterval = 24 hours, and
 * nextReviewAt = now + 24 hours. The 3-day / 9-day progression only starts
 * to apply once reviews are actually completed, which lands in Phase 2.
 */
class AddWordUseCase @Inject constructor(
    private val repository: WordRepository
) {
    companion object {
        private const val INITIAL_INTERVAL_HOURS = 24L
    }

    suspend operator fun invoke(
        word: String,
        meaning: String,
        example: String?,
        audioPath: String?
    ): Long {
        require(word.isNotBlank()) { "Word must not be blank." }
        require(meaning.isNotBlank()) { "Meaning must not be blank." }

        val now = Instant.now()
        val newWord = Word(
            word = word.trim(),
            meaning = meaning.trim(),
            example = example?.trim()?.takeIf { it.isNotEmpty() },
            audioPath = audioPath,
            createdAt = now,
            lastReviewedAt = null,
            nextReviewAt = now.plus(INITIAL_INTERVAL_HOURS, ChronoUnit.HOURS),
            reviewCount = 0,
            currentIntervalHours = INITIAL_INTERVAL_HOURS
        )
        return repository.addWord(newWord)
    }
}
