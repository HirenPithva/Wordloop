package com.wordloop.app.domain.audio

import android.media.MediaPlayer

/** Safe single-instance audio player. */
class AudioPlayer {
    private var player: MediaPlayer? = null

    fun play(filePath: String, onCompletion: () -> Unit = {}, onError: (Exception) -> Unit = {}) {
        stop()
        try {
            val mp = MediaPlayer()
            player = mp
            mp.setDataSource(filePath)
            mp.setOnCompletionListener { completed ->
                if (player === completed) {
                    player = null
                    completed.release()
                    onCompletion()
                } else {
                    completed.release()
                }
            }
            mp.setOnErrorListener { failed, _, _ ->
                if (player === failed) player = null
                try { failed.reset() } catch (_: Exception) {}
                try { failed.release() } catch (_: Exception) {}
                onError(IllegalStateException("Unable to play audio"))
                true
            }
            mp.prepare()
            mp.start()
        } catch (e: Exception) {
            player?.let { try { it.release() } catch (_: Exception) {} }
            player = null
            onError(e)
        }
    }

    fun pause() {
        val mp = player ?: return
        try { if (mp.isPlaying) mp.pause() } catch (_: IllegalStateException) {}
    }

    fun resume() {
        val mp = player ?: return
        try { if (!mp.isPlaying) mp.start() } catch (_: IllegalStateException) {}
    }

    fun seekTo(positionMs: Int) {
        val mp = player ?: return
        try { mp.seekTo(positionMs.coerceAtLeast(0)) } catch (_: IllegalStateException) {}
    }

    fun stop() {
        val mp = player ?: return
        player = null
        try { if (mp.isPlaying) mp.stop() } catch (_: IllegalStateException) {}
        try { mp.reset() } catch (_: IllegalStateException) {}
        try { mp.release() } catch (_: IllegalStateException) {}
    }

    fun isPlaying(): Boolean = try { player?.isPlaying == true } catch (_: IllegalStateException) { false }
}
