package com.wordloop.app.domain.audio

import android.media.MediaPlayer

/** Single shared player: only one file can play at a time, with pause/seek support. */
class AudioPlayer {
    private var player: MediaPlayer? = null
    private var currentPath: String? = null
    private var generation: Long = 0

    var isPlaying: Boolean = false
        private set
    var durationMs: Int = 0
        private set
    var positionMs: Int = 0
        private set

    fun play(filePath: String, onPrepared: (Int) -> Unit = {}, onCompletion: () -> Unit = {}, onError: () -> Unit = {}) {
        val token = ++generation
        stop(incrementGeneration = false)
        try {
            currentPath = filePath
            val mp = MediaPlayer()
            player = mp
            mp.setDataSource(filePath)
            mp.setOnPreparedListener { prepared ->
                if (token != generation || player !== prepared) { runCatching { prepared.release() }; return@setOnPreparedListener }
                durationMs = prepared.duration.coerceAtLeast(0)
                positionMs = 0
                prepared.start()
                isPlaying = true
                onPrepared(durationMs)
            }
            mp.setOnCompletionListener { completed ->
                if (token != generation || player !== completed) { runCatching { completed.release() }; return@setOnCompletionListener }
                positionMs = durationMs
                isPlaying = false
                runCatching { completed.release() }
                player = null
                currentPath = null
                onCompletion()
            }
            mp.setOnErrorListener { failed, _, _ ->
                if (token != generation || player !== failed) { runCatching { failed.release() }; return@setOnErrorListener true }
                isPlaying = false
                runCatching { failed.reset() }
                runCatching { failed.release() }
                player = null
                currentPath = null
                onError()
                true
            }
            mp.prepareAsync()
        } catch (_: Exception) {
            if (token == generation) {
                player?.let { runCatching { it.release() } }
                player = null
                currentPath = null
                isPlaying = false
                onError()
            }
        }
    }

    fun pause() { player?.let { if (it.isPlaying) { it.pause(); isPlaying = false } } }
    fun resume() { player?.let { if (!it.isPlaying) { runCatching { it.start(); isPlaying = true } } } }
    fun togglePause() { if (isPlaying) pause() else resume() }
    fun seekTo(ms: Int) { player?.let { val p = ms.coerceIn(0, durationMs.coerceAtLeast(0)); runCatching { it.seekTo(p); positionMs = p } } }
    fun updatePosition(): Int { positionMs = runCatching { player?.currentPosition ?: positionMs }.getOrDefault(positionMs); return positionMs }
    fun hasPlayer(): Boolean = player != null
    fun current(): String? = currentPath
    fun stop() = stop(true)
    private fun stop(incrementGeneration: Boolean) {
        if (incrementGeneration) generation++
        player?.let { runCatching { if (it.isPlaying) it.stop() }; runCatching { it.reset() }; runCatching { it.release() } }
        player = null; currentPath = null; isPlaying = false; positionMs = 0; durationMs = 0
    }
}
