package com.wordloop.app.domain.audio

import android.media.MediaPlayer

/** Thin wrapper around MediaPlayer for previewing a recorded word pronunciation. */
class AudioPlayer {

    private var player: MediaPlayer? = null

    fun play(filePath: String, onCompletion: () -> Unit = {}) {
        stop()
        try {
            val newPlayer = MediaPlayer().apply {
                setDataSource(filePath)
                setOnCompletionListener { completed ->
                    if (player === completed) {
                        player = null
                    }
                    runCatching { completed.release() }
                    onCompletion()
                }
                prepare()
                start()
            }
            player = newPlayer
        } catch (e: Exception) {
            player = null
            throw e
        }
    }

    fun stop() {
        val current = player
        player = null
        current?.let { p ->
            runCatching { if (p.isPlaying) p.stop() }
            runCatching { p.release() }
        }
    }
}
