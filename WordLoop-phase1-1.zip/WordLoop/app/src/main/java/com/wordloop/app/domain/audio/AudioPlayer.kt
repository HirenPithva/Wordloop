package com.wordloop.app.domain.audio

import android.media.MediaPlayer
import java.io.File

class AudioPlayer {
    private var player: MediaPlayer? = null
    private var generation = 0L

    fun play(filePath: String, onCompletion: () -> Unit = {}) {
        val token = ++generation
        stop()
        if (!File(filePath).isFile) return
        try {
            val mp = MediaPlayer()
            player = mp
            mp.setDataSource(filePath)
            mp.setOnCompletionListener {
                if (token == generation) {
                    runCatching { mp.release() }
                    if (player === mp) player = null
                    onCompletion()
                }
            }
            mp.setOnErrorListener { _, _, _ ->
                if (token == generation) {
                    runCatching { mp.reset(); mp.release() }
                    if (player === mp) player = null
                    onCompletion()
                }
                true
            }
            mp.prepare()
            if (token == generation && player === mp) mp.start() else runCatching { mp.release() }
        } catch (_: Exception) {
            if (player === mpSafe()) player = null
            onCompletion()
        }
    }

    private fun mpSafe(): MediaPlayer? = player
    fun pause() { runCatching { player?.takeIf { it.isPlaying }?.pause() } }
    fun resume() { runCatching { player?.takeIf { !it.isPlaying }?.start() } }
    fun seekTo(positionMs: Int) { runCatching { player?.seekTo(positionMs.coerceAtLeast(0)) } }
    fun currentPosition(): Int = runCatching { player?.currentPosition ?: 0 }.getOrDefault(0)
    fun duration(): Int = runCatching { player?.duration ?: 0 }.getOrDefault(0)
    fun isPlaying(): Boolean = runCatching { player?.isPlaying == true }.getOrDefault(false)

    fun stop() {
        generation++
        val old = player
        player = null
        runCatching { old?.stop() }
        runCatching { old?.reset() }
        runCatching { old?.release() }
    }
}
