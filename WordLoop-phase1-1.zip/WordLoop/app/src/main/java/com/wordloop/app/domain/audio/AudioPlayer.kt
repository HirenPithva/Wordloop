package com.wordloop.app.domain.audio

import android.media.MediaPlayer

/** Thin wrapper around MediaPlayer for previewing a recorded word pronunciation. */
class AudioPlayer {

    private var player: MediaPlayer? = null

    fun play(filePath: String, onCompletion: () -> Unit = {}) {
        stop()
        player = MediaPlayer().apply {
            setDataSource(filePath)
            setOnCompletionListener {
                onCompletion()
                release()
            }
            prepare()
            start()
        }
    }

    fun stop() {
        player?.apply {
            if (isPlaying) stop()
            release()
        }
        player = null
    }
}
