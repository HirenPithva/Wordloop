package com.wordloop.app.data.database.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import java.time.Instant

/**
 * One completed review attempt for a word (spec Section 13). Not yet
 * written to anywhere — the review-completion flow that populates this
 * table is built in Phase 2/4. Declared now so the schema is settled
 * up front, per the spec's "before coding, create the database schema" step.
 */
@Entity(
    tableName = "review_history",
    foreignKeys = [
        ForeignKey(
            entity = WordEntity::class,
            parentColumns = ["id"],
            childColumns = ["wordId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("wordId")]
)
data class ReviewHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val wordId: Long,
    val reviewedAt: Instant,
    val reviewNumber: Int,
    val intervalBeforeReviewMinutes: Long,
    val userMeaningAnswer: String,
    val userSentence: String,
    val meaningResult: Boolean,
    val sentenceResult: Boolean
)
