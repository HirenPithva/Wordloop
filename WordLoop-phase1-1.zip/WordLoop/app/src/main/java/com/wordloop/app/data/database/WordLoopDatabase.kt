package com.wordloop.app.data.database

import androidx.room.*
import androidx.sqlite.db.SupportSQLiteDatabase
import android.content.Context
import com.wordloop.app.data.database.dao.*
import com.wordloop.app.data.database.entities.*

@Database(
    entities = [WordEntity::class, ReviewHistoryEntity::class, DailyReviewEntity::class, ReviewScheduleEntity::class, AppSettingsEntity::class, FolderEntity::class, WordFolderCrossRef::class],
    version = 7,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class WordLoopDatabase : RoomDatabase() {
    abstract fun wordDao(): WordDao
    abstract fun reviewHistoryDao(): ReviewHistoryDao
    abstract fun dailyReviewDao(): DailyReviewDao
    abstract fun reviewScheduleDao(): ReviewScheduleDao
    abstract fun appSettingsDao(): AppSettingsDao
    abstract fun folderDao(): FolderDao

    companion object {
        val MIGRATION_1_2 = object : Migration(1, 2) { override fun migrate(db: SupportSQLiteDatabase) {} }
        val MIGRATION_2_3 = object : Migration(2, 3) { override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("CREATE TABLE IF NOT EXISTS review_schedule (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, afterReviews INTEGER NOT NULL, remindAfterHours INTEGER NOT NULL, remindAfterMinutes INTEGER NOT NULL DEFAULT 1440)")
            db.execSQL("CREATE TABLE IF NOT EXISTS app_settings (id INTEGER NOT NULL PRIMARY KEY, dailyGoal INTEGER NOT NULL, defaultReviewAfterHours INTEGER NOT NULL DEFAULT 24, defaultReviewAfterMinutes INTEGER NOT NULL DEFAULT 1440)")
            db.execSQL("INSERT OR IGNORE INTO app_settings(id,dailyGoal,defaultReviewAfterHours,defaultReviewAfterMinutes) VALUES(1,10,24,1440)")
        }}
        val MIGRATION_3_4 = object : Migration(3, 4) { override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("ALTER TABLE words ADD COLUMN audioPaths TEXT NOT NULL DEFAULT '[]'")
            db.execSQL("UPDATE words SET audioPaths = CASE WHEN audioPath IS NULL OR audioPath = '' THEN '[]' ELSE '[\"' || REPLACE(audioPath, '\"', '\\\"') || '\"]' END")
        }}
        val MIGRATION_4_5 = object : Migration(4, 5) { override fun migrate(db: SupportSQLiteDatabase) {
            // v5 historically added this field. Keep the migration only for databases that are actually v4.
            db.execSQL("ALTER TABLE app_settings ADD COLUMN defaultReviewAfterHours INTEGER NOT NULL DEFAULT 24")
        }}
        val MIGRATION_5_6 = object : Migration(5, 6) { override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("ALTER TABLE app_settings ADD COLUMN defaultReviewAfterMinutes INTEGER NOT NULL DEFAULT 1440")
            db.execSQL("ALTER TABLE review_schedule ADD COLUMN remindAfterMinutes INTEGER NOT NULL DEFAULT 1440")
            db.execSQL("UPDATE app_settings SET defaultReviewAfterMinutes = defaultReviewAfterHours * 60")
            db.execSQL("UPDATE review_schedule SET remindAfterMinutes = remindAfterHours * 60")
        }}
        val MIGRATION_6_7 = object : Migration(6, 7) { override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("CREATE TABLE IF NOT EXISTS folders (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, parentId INTEGER, FOREIGN KEY(parentId) REFERENCES folders(id) ON UPDATE NO ACTION ON DELETE CASCADE)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_folders_parentId ON folders(parentId)")
            db.execSQL("CREATE TABLE IF NOT EXISTS word_folder_cross_ref (wordId INTEGER NOT NULL, folderId INTEGER NOT NULL, PRIMARY KEY(wordId,folderId), FOREIGN KEY(wordId) REFERENCES words(id) ON UPDATE NO ACTION ON DELETE CASCADE, FOREIGN KEY(folderId) REFERENCES folders(id) ON UPDATE NO ACTION ON DELETE CASCADE)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_word_folder_cross_ref_folderId ON word_folder_cross_ref(folderId)")
        }}
        val CREATE_DEFAULT_DATA = object : Callback() { override fun onCreate(db: SupportSQLiteDatabase) {
            db.execSQL("INSERT OR IGNORE INTO app_settings(id,dailyGoal,defaultReviewAfterHours,defaultReviewAfterMinutes) VALUES(1,10,24,1440)")
            db.execSQL("INSERT INTO review_schedule(afterReviews,remindAfterHours,remindAfterMinutes) SELECT 1,24,1440 WHERE NOT EXISTS (SELECT 1 FROM review_schedule)")
            db.execSQL("INSERT INTO review_schedule(afterReviews,remindAfterHours,remindAfterMinutes) SELECT 10,72,4320 WHERE NOT EXISTS (SELECT 1 FROM review_schedule WHERE afterReviews=10)")
            db.execSQL("INSERT INTO review_schedule(afterReviews,remindAfterHours,remindAfterMinutes) SELECT 20,168,10080 WHERE NOT EXISTS (SELECT 1 FROM review_schedule WHERE afterReviews=20)")
        }}

        fun open(context: Context): WordLoopDatabase = Room.databaseBuilder(context, WordLoopDatabase::class.java, "wordloop.db")
            .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7)
            .addCallback(CREATE_DEFAULT_DATA).build()
    }
}
