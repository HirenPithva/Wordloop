package com.wordloop.app.data.database

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.room.RoomDatabase.Callback
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.room.TypeConverters
import android.content.Context
import com.wordloop.app.data.database.dao.*
import com.wordloop.app.data.database.entities.*

@Database(
    entities = [WordEntity::class, ReviewHistoryEntity::class, DailyReviewEntity::class, ReviewScheduleEntity::class, AppSettingsEntity::class],
    version = 5,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class WordLoopDatabase : RoomDatabase() {
    abstract fun wordDao(): WordDao
    abstract fun reviewHistoryDao(): ReviewHistoryDao
    abstract fun dailyReviewDao(): DailyReviewDao
    abstract fun reviewScheduleDao(): ReviewScheduleDao
    abstract fun appSettingsDao(): AppSettingsDao

    companion object {
        fun open(context: Context): WordLoopDatabase =
            Room.databaseBuilder(context, WordLoopDatabase::class.java, "wordloop.db")
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5)
                .addCallback(CREATE_DEFAULT_DATA)
                .build()

        val MIGRATION_1_2 = object : Migration(1, 2) { override fun migrate(db: SupportSQLiteDatabase) {} }

        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE words ADD COLUMN audioPaths TEXT NOT NULL DEFAULT '[]'")
                db.execSQL("UPDATE words SET audioPaths = CASE WHEN audioPath IS NULL OR audioPath = '' THEN '[]' ELSE '[\"' || REPLACE(audioPath, '\"', '\\\"') || '\"]' END")
            }
        }

        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE app_settings ADD COLUMN defaultReviewAfterHours INTEGER NOT NULL DEFAULT 24")
            }
        }
        val CREATE_DEFAULT_DATA = object : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                db.execSQL("INSERT OR IGNORE INTO app_settings(id, dailyGoal, defaultReviewAfterHours) VALUES(1, 10, 24)")
                db.execSQL("INSERT INTO review_schedule(afterReviews, remindAfterHours) SELECT 1, 24 WHERE NOT EXISTS (SELECT 1 FROM review_schedule)")
                db.execSQL("INSERT INTO review_schedule(afterReviews, remindAfterHours) SELECT 10, 72 WHERE NOT EXISTS (SELECT 1 FROM review_schedule WHERE afterReviews = 10)")
                db.execSQL("INSERT INTO review_schedule(afterReviews, remindAfterHours) SELECT 20, 168 WHERE NOT EXISTS (SELECT 1 FROM review_schedule WHERE afterReviews = 20)")
                db.execSQL("INSERT INTO review_schedule(afterReviews, remindAfterHours) SELECT 30, 336 WHERE NOT EXISTS (SELECT 1 FROM review_schedule WHERE afterReviews = 30)")
                db.execSQL("INSERT INTO review_schedule(afterReviews, remindAfterHours) SELECT 50, 720 WHERE NOT EXISTS (SELECT 1 FROM review_schedule WHERE afterReviews = 50)")
            }
        }
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS review_schedule (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, afterReviews INTEGER NOT NULL, remindAfterHours INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS app_settings (id INTEGER NOT NULL PRIMARY KEY, dailyGoal INTEGER NOT NULL, defaultReviewAfterHours INTEGER NOT NULL DEFAULT 24)")
                db.execSQL("INSERT OR IGNORE INTO app_settings(id, dailyGoal, defaultReviewAfterHours) VALUES(1, 10, 24)")
                db.execSQL("INSERT INTO review_schedule(afterReviews, remindAfterHours) SELECT 1, 24 WHERE NOT EXISTS (SELECT 1 FROM review_schedule)")
                db.execSQL("INSERT INTO review_schedule(afterReviews, remindAfterHours) SELECT 10, 72 WHERE NOT EXISTS (SELECT 1 FROM review_schedule WHERE afterReviews = 10)")
                db.execSQL("INSERT INTO review_schedule(afterReviews, remindAfterHours) SELECT 20, 168 WHERE NOT EXISTS (SELECT 1 FROM review_schedule WHERE afterReviews = 20)")
                db.execSQL("INSERT INTO review_schedule(afterReviews, remindAfterHours) SELECT 30, 336 WHERE NOT EXISTS (SELECT 1 FROM review_schedule WHERE afterReviews = 30)")
                db.execSQL("INSERT INTO review_schedule(afterReviews, remindAfterHours) SELECT 50, 720 WHERE NOT EXISTS (SELECT 1 FROM review_schedule WHERE afterReviews = 50)")
            }
        }
    }
}
