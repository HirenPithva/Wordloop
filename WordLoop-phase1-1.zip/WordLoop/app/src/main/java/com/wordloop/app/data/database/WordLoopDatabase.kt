package com.wordloop.app.data.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.room.RoomDatabase.Callback
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.room.TypeConverters
import com.wordloop.app.data.database.dao.*
import com.wordloop.app.data.database.entities.*

@Database(
    entities = [WordEntity::class, ReviewHistoryEntity::class, DailyReviewEntity::class, ReviewScheduleEntity::class, AppSettingsEntity::class],
    version = 3,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class WordLoopDatabase : RoomDatabase() {
    abstract fun wordDao(): WordDao
    abstract fun reviewHistoryDao(): ReviewHistoryDao
    abstract fun dailyReviewDao(): DailyReviewDao
    abstract fun reviewScheduleDao(): ReviewScheduleDao
    abstract fun appSettingsDao(): AppSettingsDao

    companion object {
        val MIGRATION_1_2 = object : Migration(1, 2) { override fun migrate(db: SupportSQLiteDatabase) {} }
        val CREATE_DEFAULT_DATA = object : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                db.execSQL("INSERT OR IGNORE INTO app_settings(id, dailyGoal) VALUES(1, 10)")
                db.execSQL("INSERT INTO review_schedule(afterReviews, remindAfterHours) SELECT 1, 24 WHERE NOT EXISTS (SELECT 1 FROM review_schedule)")
                db.execSQL("INSERT INTO review_schedule(afterReviews, remindAfterHours) SELECT 10, 72 WHERE NOT EXISTS (SELECT 1 FROM review_schedule WHERE afterReviews = 10)")
                db.execSQL("INSERT INTO review_schedule(afterReviews, remindAfterHours) SELECT 20, 168 WHERE NOT EXISTS (SELECT 1 FROM review_schedule WHERE afterReviews = 20)")
                db.execSQL("INSERT INTO review_schedule(afterReviews, remindAfterHours) SELECT 30, 336 WHERE NOT EXISTS (SELECT 1 FROM review_schedule WHERE afterReviews = 30)")
                db.execSQL("INSERT INTO review_schedule(afterReviews, remindAfterHours) SELECT 50, 720 WHERE NOT EXISTS (SELECT 1 FROM review_schedule WHERE afterReviews = 50)")
            }
        }
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS review_schedule (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, afterReviews INTEGER NOT NULL, remindAfterHours INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS app_settings (id INTEGER NOT NULL PRIMARY KEY, dailyGoal INTEGER NOT NULL)")
                db.execSQL("INSERT OR IGNORE INTO app_settings(id, dailyGoal) VALUES(1, 10)")
                db.execSQL("INSERT INTO review_schedule(afterReviews, remindAfterHours) SELECT 1, 24 WHERE NOT EXISTS (SELECT 1 FROM review_schedule)")
                db.execSQL("INSERT INTO review_schedule(afterReviews, remindAfterHours) SELECT 10, 72 WHERE NOT EXISTS (SELECT 1 FROM review_schedule WHERE afterReviews = 10)")
                db.execSQL("INSERT INTO review_schedule(afterReviews, remindAfterHours) SELECT 20, 168 WHERE NOT EXISTS (SELECT 1 FROM review_schedule WHERE afterReviews = 20)")
                db.execSQL("INSERT INTO review_schedule(afterReviews, remindAfterHours) SELECT 30, 336 WHERE NOT EXISTS (SELECT 1 FROM review_schedule WHERE afterReviews = 30)")
                db.execSQL("INSERT INTO review_schedule(afterReviews, remindAfterHours) SELECT 50, 720 WHERE NOT EXISTS (SELECT 1 FROM review_schedule WHERE afterReviews = 50)")
            }
        }
    }
}
