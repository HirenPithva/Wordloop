package com.wordloop.app.data.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.room.TypeConverters
import com.wordloop.app.data.database.dao.WordDao
import com.wordloop.app.data.database.entities.DailyReviewEntity
import com.wordloop.app.data.database.entities.ReviewHistoryEntity
import com.wordloop.app.data.database.entities.WordEntity

/**
 * All three tables from the spec's schema (Section 13) are declared here
 * from Phase 1 onward, even though review_history and daily_review have no
 * DAO yet — their DAOs land with the review-completion flow in Phase 2,
 * without needing a schema/version bump at that point.
 */
@Database(
    entities = [WordEntity::class, ReviewHistoryEntity::class, DailyReviewEntity::class],
    version = 2,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class WordLoopDatabase : RoomDatabase() {

    companion object {
        /**
         * Phase 1 already contains the review-related tables, so version 2
         * does not need to change their schema. This explicit migration is
         * intentionally non-destructive: existing words, review history,
         * daily-review data and other local database data are preserved when
         * the app is updated.
         */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // No schema changes. The version bump marks a safe upgrade
                // point for the review feature and avoids destructive reset.
            }
        }
    }

    abstract fun wordDao(): WordDao
}
