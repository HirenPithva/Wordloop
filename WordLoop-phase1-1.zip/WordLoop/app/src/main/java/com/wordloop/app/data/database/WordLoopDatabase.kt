package com.wordloop.app.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.wordloop.app.data.database.dao.*
import com.wordloop.app.data.database.entities.*

@Database(entities = [WordEntity::class, ReviewHistoryEntity::class, DailyReviewEntity::class, ReviewScheduleEntity::class, AppSettingsEntity::class, FolderEntity::class, WordFolderCrossRef::class], version = 7, exportSchema = true)
@TypeConverters(Converters::class)
abstract class WordLoopDatabase : RoomDatabase() {
    abstract fun wordDao(): WordDao
    abstract fun reviewHistoryDao(): ReviewHistoryDao
    abstract fun dailyReviewDao(): DailyReviewDao
    abstract fun reviewScheduleDao(): ReviewScheduleDao
    abstract fun appSettingsDao(): AppSettingsDao
    abstract fun folderDao(): FolderDao

    companion object {
        fun open(context: Context): WordLoopDatabase = Room.databaseBuilder(context, WordLoopDatabase::class.java, "wordloop.db")
            .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7).build()

        val MIGRATION_1_2 = object : Migration(1, 2) { override fun migrate(db: SupportSQLiteDatabase) {} }
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS review_schedule (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, afterReviews INTEGER NOT NULL, remindAfterHours INTEGER NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS app_settings (id INTEGER NOT NULL PRIMARY KEY, dailyGoal INTEGER NOT NULL, defaultReviewAfterHours INTEGER NOT NULL DEFAULT 24)")
                db.execSQL("INSERT OR IGNORE INTO app_settings(id, dailyGoal, defaultReviewAfterHours) VALUES(1, 10, 24)")
                db.execSQL("INSERT INTO review_schedule(afterReviews, remindAfterHours) SELECT 1, 24 WHERE NOT EXISTS (SELECT 1 FROM review_schedule)")
                db.execSQL("INSERT INTO review_schedule(afterReviews, remindAfterHours) SELECT 10, 72 WHERE NOT EXISTS (SELECT 1 FROM review_schedule WHERE afterReviews = 10)")
                db.execSQL("INSERT INTO review_schedule(afterReviews, remindAfterHours) SELECT 20, 168 WHERE NOT EXISTS (SELECT 1 FROM review_schedule WHERE afterReviews = 20)")
                db.execSQL("INSERT INTO review_schedule(afterReviews, remindAfterHours) SELECT 30, 336 WHERE NOT EXISTS (SELECT 1 FROM review_schedule WHERE afterReviews = 30)")
                db.execSQL("INSERT INTO review_schedule(afterReviews, remindAfterHours) SELECT 50, 720 WHERE NOT EXISTS (SELECT 1 FROM review_schedule WHERE afterReviews = 50)")
            }
        }
        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE words ADD COLUMN audioPaths TEXT NOT NULL DEFAULT '[]'")
                db.execSQL("UPDATE words SET audioPaths = CASE WHEN audioPath IS NULL OR audioPath = '' THEN '[]' ELSE '[\"' || REPLACE(audioPath, '\"', '\\\"') || '\"]' END")
            }
        }
        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Version 3 already creates defaultReviewAfterHours. Keep this migration
                // as a no-op so upgrades from 3/4 do not hit a duplicate-column error.
            }
        }
        val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Rebuild tables to replace legacy hour-based columns with minute-based columns.
                db.execSQL("PRAGMA foreign_keys=OFF")
                db.execSQL("CREATE TABLE words_new (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, word TEXT NOT NULL, meaning TEXT NOT NULL, example TEXT, audioPath TEXT, audioPaths TEXT NOT NULL, createdAt INTEGER NOT NULL, lastReviewedAt INTEGER, nextReviewAt INTEGER NOT NULL, reviewCount INTEGER NOT NULL, currentIntervalMinutes INTEGER NOT NULL)")
                db.execSQL("INSERT INTO words_new(id,word,meaning,example,audioPath,audioPaths,createdAt,lastReviewedAt,nextReviewAt,reviewCount,currentIntervalMinutes) SELECT id,word,meaning,example,audioPath,audioPaths,createdAt,lastReviewedAt,nextReviewAt,reviewCount,currentIntervalHours*60 FROM words")
                db.execSQL("DROP TABLE words")
                db.execSQL("ALTER TABLE words_new RENAME TO words")
                db.execSQL("CREATE TABLE review_history_new (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, wordId INTEGER NOT NULL, reviewedAt INTEGER NOT NULL, reviewNumber INTEGER NOT NULL, intervalBeforeReviewMinutes INTEGER NOT NULL, userMeaningAnswer TEXT NOT NULL, userSentence TEXT NOT NULL, meaningResult INTEGER NOT NULL, sentenceResult INTEGER NOT NULL, FOREIGN KEY(wordId) REFERENCES words(id) ON UPDATE NO ACTION ON DELETE CASCADE)")
                db.execSQL("INSERT INTO review_history_new(id,wordId,reviewedAt,reviewNumber,intervalBeforeReviewMinutes,userMeaningAnswer,userSentence,meaningResult,sentenceResult) SELECT id,wordId,reviewedAt,reviewNumber,intervalBeforeReviewHours*60,userMeaningAnswer,userSentence,meaningResult,sentenceResult FROM review_history")
                db.execSQL("DROP TABLE review_history")
                db.execSQL("ALTER TABLE review_history_new RENAME TO review_history")
                db.execSQL("CREATE INDEX index_review_history_wordId ON review_history(wordId)")
                db.execSQL("CREATE TABLE review_schedule_new (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, afterReviews INTEGER NOT NULL, remindAfterMinutes INTEGER NOT NULL)")
                db.execSQL("INSERT INTO review_schedule_new(id,afterReviews,remindAfterMinutes) SELECT id,afterReviews,remindAfterHours*60 FROM review_schedule")
                db.execSQL("DROP TABLE review_schedule")
                db.execSQL("ALTER TABLE review_schedule_new RENAME TO review_schedule")
                db.execSQL("CREATE TABLE app_settings_new (id INTEGER NOT NULL PRIMARY KEY, dailyGoal INTEGER NOT NULL, defaultReviewAfterMinutes INTEGER NOT NULL)")
                db.execSQL("INSERT INTO app_settings_new(id,dailyGoal,defaultReviewAfterMinutes) SELECT id,dailyGoal,defaultReviewAfterHours*60 FROM app_settings")
                db.execSQL("DROP TABLE app_settings")
                db.execSQL("ALTER TABLE app_settings_new RENAME TO app_settings")
                db.execSQL("CREATE TABLE folders (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, parentId INTEGER, FOREIGN KEY(parentId) REFERENCES folders(id) ON UPDATE NO ACTION ON DELETE CASCADE)")
                db.execSQL("CREATE UNIQUE INDEX index_folders_parentId_name ON folders(parentId,name)")
                db.execSQL("CREATE INDEX index_folders_parentId ON folders(parentId)")
                db.execSQL("CREATE TABLE word_folder_cross_ref (wordId INTEGER NOT NULL, folderId INTEGER NOT NULL, PRIMARY KEY(wordId,folderId), FOREIGN KEY(wordId) REFERENCES words(id) ON UPDATE NO ACTION ON DELETE CASCADE, FOREIGN KEY(folderId) REFERENCES folders(id) ON UPDATE NO ACTION ON DELETE CASCADE)")
                db.execSQL("CREATE INDEX index_word_folder_cross_ref_folderId ON word_folder_cross_ref(folderId)")
                db.execSQL("PRAGMA foreign_keys=ON")
            }
        }
        val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Schema-preserving release: runtime/audio/folder behavior fixes only.
            }
        }
    }
}
