package com.wordloop.app.data.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.wordloop.app.data.database.dao.WordDao
import com.wordloop.app.data.database.entities.DailyReviewEntity
import com.wordloop.app.data.database.entities.ReviewHistoryEntity
import com.wordloop.app.data.database.entities.WordEntity

/**
 * All three tables from the spec's schema (Section 13) are declared here
 * from Phase 1 onward, even though review_history and daily_review have no
 * DAO yet — their DAOs land with the review-completion flow in Phase 2,
 * without needing a schema/version bump at that point.
 */
@Database(
    entities = [WordEntity::class, ReviewHistoryEntity::class, DailyReviewEntity::class],
    version = 1,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class WordLoopDatabase : RoomDatabase() {
    abstract fun wordDao(): WordDao
}
