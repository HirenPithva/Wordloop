package com.wordloop.app.data.backup

import android.content.Context
import android.net.Uri
import androidx.room.withTransaction
import com.wordloop.app.data.database.WordLoopDatabase
import com.wordloop.app.data.database.entities.AppSettingsEntity
import com.wordloop.app.data.database.entities.DailyReviewEntity
import com.wordloop.app.data.database.entities.ReviewHistoryEntity
import com.wordloop.app.data.database.entities.ReviewScheduleEntity
import com.wordloop.app.data.database.entities.WordEntity
import com.wordloop.app.notifications.ReminderScheduler
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.Instant
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

class BackupManager @Inject constructor(@ApplicationContext private val context: Context) {
    companion object { private const val FORMAT_VERSION = 2 }

    suspend fun export(uri: Uri): Result<Unit> = runCatching {
        val db = WordLoopDatabase.open(context)
        try {
            val words = db.wordDao().getAllWordsOnce()
            val history = db.reviewHistoryDao().getAll()
            val daily = db.dailyReviewDao().getAll()
            val schedules = db.reviewScheduleDao().getAll()
            val settings = db.appSettingsDao().get()
            val folders = db.folderDao().getAll()
            val folderRefs = db.folderDao().getAllRefs()
            context.contentResolver.openOutputStream(uri)?.use { output ->
                ZipOutputStream(output).use { zip ->
                    val audioEntries = linkedMapOf<String, String>()
                    words.forEach { word ->
                        val paths = word.audioPaths.ifEmpty { listOfNotNull(word.audioPath) }
                        paths.forEachIndexed { index, path ->
                            val file = File(path)
                            if (file.exists() && file.isFile) {
                                val entry = "audio/${word.id}_$index_${file.name.replace(Regex("[^A-Za-z0-9._-]"), "_")}"
                                audioEntries["${word.id}:$index"] = entry
                                zip.putNextEntry(ZipEntry(entry))
                                file.inputStream().use { it.copyTo(zip) }
                                zip.closeEntry()
                            }
                        }
                    }
                    val root = JSONObject().put("formatVersion", FORMAT_VERSION).put("exportedAt", System.currentTimeMillis())
                    val wordsJson = JSONArray()
                    words.forEach { w ->
                        val audio = JSONArray()
                        val paths = w.audioPaths.ifEmpty { listOfNotNull(w.audioPath) }
                        paths.indices.forEach { index -> audioEntries["${w.id}:$index"]?.let(audio::put) }
                        wordsJson.put(JSONObject().put("id", w.id).put("word", w.word).put("meaning", w.meaning).put("example", w.example)
                            .put("createdAt", w.createdAt.toEpochMilli()).put("lastReviewedAt", w.lastReviewedAt?.toEpochMilli())
                            .put("nextReviewAt", w.nextReviewAt.toEpochMilli()).put("reviewCount", w.reviewCount)
                            .put("currentIntervalMinutes", w.currentIntervalMinutes).put("audioFiles", audio))
                    }
                    root.put("words", wordsJson)
                    val historyJson = JSONArray()
                    history.forEach { h -> historyJson.put(JSONObject().put("id", h.id).put("wordId", h.wordId).put("reviewedAt", h.reviewedAt.toEpochMilli()).put("reviewNumber", h.reviewNumber).put("intervalBeforeReviewMinutes", h.intervalBeforeReviewMinutes).put("userMeaningAnswer", h.userMeaningAnswer).put("userSentence", h.userSentence).put("meaningResult", h.meaningResult).put("sentenceResult", h.sentenceResult)) }
                    root.put("reviewHistory", historyJson)
                    val dailyJson = JSONArray(); daily.forEach { d -> dailyJson.put(JSONObject().put("date", d.date).put("reviewCount", d.reviewCount)) }; root.put("dailyReview", dailyJson)
                    val scheduleJson = JSONArray(); schedules.forEach { s -> scheduleJson.put(JSONObject().put("afterReviews", s.afterReviews).put("remindAfterMinutes", s.remindAfterMinutes)) }; root.put("reviewSchedule", scheduleJson)
                    settings?.let { root.put("appSettings", JSONObject().put("dailyGoal", it.dailyGoal).put("defaultReviewAfterMinutes", it.defaultReviewAfterMinutes)) }
                    val foldersJson = JSONArray(); folders.forEach { f -> foldersJson.put(JSONObject().put("id", f.id).put("name", f.name).put("parentId", f.parentId)) }; root.put("folders", foldersJson)
                    val refsJson = JSONArray(); folderRefs.forEach { r -> refsJson.put(JSONObject().put("wordId", r.wordId).put("folderId", r.folderId)) }; root.put("wordFolderRefs", refsJson)
                    zip.putNextEntry(ZipEntry("database.json")); zip.write(root.toString().toByteArray(Charsets.UTF_8)); zip.closeEntry()
                }
            } ?: error("Unable to open export destination")
        } finally { db.close() }
    }

    suspend fun import(uri: Uri): Result<Unit> = runCatching {
        val tempDir = File(context.cacheDir, "wordloop_import_${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            var json: JSONObject? = null
            context.contentResolver.openInputStream(uri)?.use { input ->
                ZipInputStream(input).use { zip ->
                    while (true) {
                        val entry = zip.nextEntry ?: break
                        if (entry.isDirectory) continue
                        if (entry.name == "database.json") {
                            json = JSONObject(zip.readBytes().toString(Charsets.UTF_8))
                        } else if (entry.name.startsWith("audio/") && !entry.name.contains("..")) {
                            val out = File(tempDir, entry.name.removePrefix("audio/").replace('/', '_'))
                            out.outputStream().use { zip.copyTo(it) }
                        }
                        zip.closeEntry()
                    }
                }
            } ?: error("Unable to open import file")
            val root = json ?: error("Invalid WordLoop backup: database.json is missing")
            val formatVersion = root.optInt("formatVersion", -1)
            require(formatVersion in 1..FORMAT_VERSION) { "Unsupported WordLoop backup format" }
            val db = WordLoopDatabase.open(context)
            try {
                db.withTransaction {
                    val idMap = mutableMapOf<Long, Long>()
                    val wordsJson = root.getJSONArray("words")
                    for (i in 0 until wordsJson.length()) {
                        val item = wordsJson.getJSONObject(i)
                        val importedPaths = mutableListOf<String>()
                        val audio = item.optJSONArray("audioFiles") ?: JSONArray()
                        for (a in 0 until audio.length()) {
                            val entryName = audio.getString(a)
                            val source = File(tempDir, entryName.removePrefix("audio/").replace('/', '_'))
                            if (source.exists()) {
                                val ext = source.extension.ifBlank { "m4a" }
                                val target = File(context.filesDir, "word_audio_import_${System.currentTimeMillis()}_${i}_$a.$ext")
                                source.copyTo(target, overwrite = true)
                                importedPaths += target.absolutePath
                            }
                        }
                        val oldId = item.getLong("id")
                        val newId = db.wordDao().insert(WordEntity(word = item.getString("word"), meaning = item.getString("meaning"), example = if (item.isNull("example")) null else item.getString("example"), audioPath = importedPaths.firstOrNull(), audioPaths = importedPaths, createdAt = Instant.ofEpochMilli(item.getLong("createdAt")), lastReviewedAt = if (item.isNull("lastReviewedAt")) null else Instant.ofEpochMilli(item.getLong("lastReviewedAt")), nextReviewAt = Instant.ofEpochMilli(item.getLong("nextReviewAt")), reviewCount = item.getInt("reviewCount"), currentIntervalMinutes = if (item.has("currentIntervalMinutes")) item.getLong("currentIntervalMinutes") else item.optLong("currentIntervalHours", 24L) * 60))
                        idMap[oldId] = newId
                    }
                    val folderIdMap = mutableMapOf<Long, Long>()
                    val foldersJson = root.optJSONArray("folders") ?: JSONArray()
                    val pendingFolders = (0 until foldersJson.length()).map { foldersJson.getJSONObject(it) }.toMutableList()
                    while (pendingFolders.isNotEmpty()) {
                        var progressed = false
                        val iterator = pendingFolders.iterator()
                        while (iterator.hasNext()) {
                            val f = iterator.next(); val oldParent = if (f.isNull("parentId")) null else f.getLong("parentId")
                            if (oldParent != null && !folderIdMap.containsKey(oldParent)) continue
                            val parentNew = oldParent?.let { folderIdMap[it] }
                            val existing = db.folderDao().getAll().firstOrNull { it.parentId == parentNew && it.name.equals(f.getString("name"), true) }
                            val newId = existing?.id ?: db.folderDao().insert(com.wordloop.app.data.database.entities.FolderEntity(name=f.getString("name"), parentId=parentNew))
                            folderIdMap[f.getLong("id")] = newId
                            iterator.remove(); progressed = true
                        }
                        if (!progressed) break
                    }
                    val refsJson = root.optJSONArray("wordFolderRefs") ?: JSONArray()
                    repeat(refsJson.length()) { idx ->
                        val r=refsJson.getJSONObject(idx); val newWord=idMap[r.getLong("wordId")]; val newFolder=folderIdMap[r.getLong("folderId")]; if(newWord!=null&&newFolder!=null) db.folderDao().addRef(com.wordloop.app.data.database.entities.WordFolderCrossRef(newWord,newFolder))
                    }

                    val historyJson = root.optJSONArray("reviewHistory") ?: JSONArray()
                    for (i in 0 until historyJson.length()) {
                        val h = historyJson.getJSONObject(i); val newWordId = idMap[h.getLong("wordId")] ?: continue
                        db.reviewHistoryDao().insert(ReviewHistoryEntity(wordId = newWordId, reviewedAt = Instant.ofEpochMilli(h.getLong("reviewedAt")), reviewNumber = h.getInt("reviewNumber"), intervalBeforeReviewMinutes = if (h.has("intervalBeforeReviewMinutes")) h.getLong("intervalBeforeReviewMinutes") else h.optLong("intervalBeforeReviewHours", 24L) * 60, userMeaningAnswer = h.optString("userMeaningAnswer", ""), userSentence = h.optString("userSentence", ""), meaningResult = h.optBoolean("meaningResult", false), sentenceResult = h.optBoolean("sentenceResult", false)))
                    }
                    val dailyJson = root.optJSONArray("dailyReview") ?: JSONArray()
                    for (i in 0 until dailyJson.length()) { val d = dailyJson.getJSONObject(i); val date = d.getString("date"); db.dailyReviewDao().save(DailyReviewEntity(date, (db.dailyReviewDao().count(date) ?: 0) + d.getInt("reviewCount"))) }
                    val scheduleJson = root.optJSONArray("reviewSchedule") ?: JSONArray()
                    val existing = db.reviewScheduleDao().getAll().map { it.afterReviews to it.remindAfterMinutes }.toMutableSet()
                    for (i in 0 until scheduleJson.length()) { val s = scheduleJson.getJSONObject(i); val pair = s.getInt("afterReviews") to if (s.has("remindAfterMinutes")) s.getLong("remindAfterMinutes") else s.optLong("remindAfterHours", 1440L) * 60; if (existing.add(pair)) db.reviewScheduleDao().insert(ReviewScheduleEntity(afterReviews = pair.first, remindAfterMinutes = pair.second)) }
                    root.optJSONObject("appSettings")?.let { s -> db.appSettingsDao().save(AppSettingsEntity(1, s.optInt("dailyGoal", 10).coerceAtLeast(1), s.optLong("defaultReviewAfterMinutes", s.optLong("defaultReviewAfterHours", 24L) * 60).coerceAtLeast(1L))) }
                }
            } finally { db.close() }
            ReminderScheduler(context).rescheduleUpcoming()
        } finally { tempDir.deleteRecursively() }
    }
}
