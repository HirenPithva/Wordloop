package com.wordloop.app.data.database.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.wordloop.app.data.database.entities.ReviewScheduleEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ReviewScheduleDao {
    @Query("SELECT * FROM review_schedule ORDER BY afterReviews ASC")
    fun observeAll(): Flow<List<ReviewScheduleEntity>>
    @Insert suspend fun insert(item: ReviewScheduleEntity): Long
    @Delete suspend fun delete(item: ReviewScheduleEntity)
    @Query("DELETE FROM review_schedule") suspend fun deleteAll()
    @Query("SELECT * FROM review_schedule WHERE afterReviews <= :reviewCount ORDER BY afterReviews DESC LIMIT 1")
    suspend fun findApplicable(reviewCount: Int): ReviewScheduleEntity?
}
