package com.wordloop.app.domain.usecase

import com.wordloop.app.domain.model.Word
import com.wordloop.app.domain.repository.WordRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.Instant
import java.time.temporal.ChronoUnit

/** In-memory fake — no Room/Android dependency, so this runs as a plain JVM test. */
private class FakeWordRepository : WordRepository {
    var savedWord: Word? = null

    override fun observeAllWords(): Flow<List<Word>> = flowOf(emptyList())
    override fun observeWordCount(): Flow<Int> = flowOf(0)
    override suspend fun getWordById(id: Long): Word? = null

    override suspend fun addWord(word: Word): Long {
        savedWord = word
        return 1L
    }

    override suspend fun updateWord(word: Word) {}
    override suspend fun deleteWord(word: Word) {}
    override suspend fun getDueWords(now: Instant): List<Word> = emptyList()
}

class AddWordUseCaseTest {

    @Test
    fun `new word starts at review count zero with a 24 hour next review`() = runTest {
        val fakeRepository = FakeWordRepository()
        val addWord = AddWordUseCase(fakeRepository)

        val before = Instant.now()
        addWord(
            word = "Abundant",
            meaning = "Existing in large quantities.",
            example = null,
            audioPath = null
        )
        val after = Instant.now()

        val saved = fakeRepository.savedWord
        assertNotNull("addWord() should have been called", saved)
        assertEquals(0, saved!!.reviewCount)
        assertEquals(24L, saved.currentIntervalHours)
        assertTrue(saved.nextReviewAt.isAfter(before.plus(23, ChronoUnit.HOURS)))
        assertTrue(saved.nextReviewAt.isBefore(after.plus(25, ChronoUnit.HOURS)))
    }

    @Test
    fun `blank word is rejected`() = runTest {
        val addWord = AddWordUseCase(FakeWordRepository())
        var threw = false
        try {
            addWord(word = "   ", meaning = "something", example = null, audioPath = null)
        } catch (e: IllegalArgumentException) {
            threw = true
        }
        assertTrue("Blank word should be rejected", threw)
    }
}
