# WordLoop — Phase 1

Status: **Phase 1 of 6** from the spec — project setup, Room persistence,
Add Word, Word List. Scheduling, notifications, review/AI, and polish are
still to come (Phases 2–6).

## Opening this project

This was written in a sandbox with no Android SDK, so it has **not** been
compiled or run. Open the `WordLoop/` folder directly in Android Studio
(Otter or newer) and let it sync — that's the first real compile.

A couple of things Android Studio will need to do on first open, since this
environment couldn't do them:
- **Gradle wrapper jar**: `gradle/wrapper/gradle-wrapper.properties` points
  at Gradle 9.4.1, but the actual `gradle-wrapper.jar` binary isn't included
  (no network access to fetch it here). Android Studio normally regenerates
  this automatically on first sync; if it doesn't, run `gradle wrapper` once
  you have any local Gradle install, or use *File ▸ Sync Project with
  Gradle Files* and let Studio offer to fix it.
- If Android Studio flags any dependency as outdated, it's fine to accept
  its suggested bump — the versions below were current as of research done
  while building this, not guaranteed to be the latest by the time you open it.

## Building an APK without installing anything locally

`.github/workflows/build-apk.yml` builds a debug APK on GitHub's own
servers (which have normal, unrestricted internet access) instead of
locally:

1. Create a free GitHub account if you don't have one, and a new
   repository (public or private both work).
2. Get this project's files into that repository — the easiest way with
   no command line is GitHub Desktop (a small installer, much lighter
   than Android Studio), or drag-and-drop the folder into the repo's page
   in a browser, or `git push` if you already use git.
3. Pushing to the `main` branch triggers the workflow automatically — open
   the repo's **Actions** tab to watch it run (a few minutes).
4. When it finishes, open that run and download the **wordloop-debug-apk**
   artifact — that zip contains `app-debug.apk`.
5. Copy the APK to your phone (email, Drive, USB, whatever's easiest) and
   tap it to install. Android will ask to allow installing from that
   source the first time — that's expected for an APK from outside the
   Play Store.

This wasn't run end-to-end (no network access from the sandbox that wrote
it), so if the Actions run fails, the log will point at exactly what's
missing — usually a one-line fix like a version bump.

## Stack & key versions

Kotlin 2.3.21 · AGP 9.2.1 · Gradle 9.4.1 · Compose BOM 2026.06.01 ·
Room 2.8.5 (KSP) · Hilt 2.57.1 (KSP, no kapt) · compileSdk/targetSdk 36 ·
minSdk 26 (Android 8.0, per the spec).

## Decisions worth knowing about

- **DI**: Hilt, fully on KSP (no kapt anywhere).
- **Dates**: `java.time.Instant`, stored in Room as epoch-millis `Long` via
  a `TypeConverter`. This needs no desugaring since minSdk 26 already has
  native `java.time`.
- **Schema**: all three tables from the spec (`words`, `review_history`,
  `daily_review`) are declared now so the schema is settled up front, but
  only `WordDao` is built out — the other two get their DAOs when Phase 2
  (review completion) and Phase 4 (daily counter) actually use them. No
  version bump needed for that later.
- **Voice recording**: implemented now (`AudioRecorder`/`AudioPlayer`,
  MediaRecorder/MediaPlayer) since the Add Word screen calls for it
  directly, even though the phase breakdown doesn't separately call it out.
- **Launcher icon**: a vector-only adaptive icon (background + a simple
  ring), so there are no binary image assets to swap in later — replace
  `drawable/ic_launcher_*.xml` whenever there's a real design.
- **Package**: `com.wordloop.app` — rename if you'd rather use something
  under your own domain.

## What's implemented

- Room database (`words`, `review_history`, `daily_review` tables; only
  `words` wired up) with a repository and use case behind it.
- New word initial state exactly per spec Section 2: `reviewCount = 0`,
  `currentInterval = 24h`, `nextReviewAt = now + 24h`. Covered by a unit
  test (`AddWordUseCaseTest`) that runs as a plain JVM test, no emulator
  needed — `./gradlew test` once this is open in Android Studio.
- Add Word screen: word / meaning / optional example, plus record / stop /
  play / delete for a voice note, with a runtime `RECORD_AUDIO` permission
  request.
- My Words list with an empty state, backed by a `Flow` from Room so it
  updates live as words are added.

## Explicitly not yet built (Phases 2–6)

- The 24h → 3-day → 9-day progression *after* a review (only the initial
  24h state exists right now), the 10-word daily cap, and the due-word
  priority queue.
- AlarmManager/BroadcastReceiver notifications and the boot receiver.
- The Review screen: meaning recall, AI evaluation, sentence practice,
  text-to-speech, speech-to-text.
- The ASP.NET Core backend and its two evaluation endpoints.
- Dashboard, Word Details, Review History, Settings screens.

Say the word and I'll carry on with Phase 2 (the scheduling engine and the
daily queue) next.
